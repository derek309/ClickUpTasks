<?php
/**
 * WebsitePusher Uninstall
 *
 * Runs when the plugin is deleted from WordPress.
 * Removes all options and cleans up backup files.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// The Brain Box's built-in copy of WebsitePusher shares the connection code,
// the history and the backups. Deleting this plugin on such a site must not
// take them with it, or the app loses its connection the moment it is deleted.
if ( function_exists( 'culc_wpusher_source' ) ) {
	return;
}

// Remove all plugin options
delete_option( 'wpusher_api_key' );
delete_option( 'wpusher_backup_retention' );
delete_option( 'wpusher_history' );

// Remove backup directory and all backups
$upload_dir = wp_upload_dir();
$backup_dir = trailingslashit( $upload_dir['basedir'] ) . 'websitepusher-backups';

if ( is_dir( $backup_dir ) ) {
	wpusher_delete_directory( $backup_dir );
}

/**
 * Recursively delete a directory.
 *
 * @param string $dir Directory path to delete.
 */
function wpusher_delete_directory( $dir ) {
	if ( ! is_dir( $dir ) ) {
		return;
	}
	$files = array_diff( scandir( $dir ), array( '.', '..' ) );
	foreach ( $files as $file ) {
		$path = trailingslashit( $dir ) . $file;
		if ( is_dir( $path ) ) {
			wpusher_delete_directory( $path );
		} else {
			if ( file_exists( $path ) ) {
				unlink( $path );
			}
		}
	}
	rmdir( $dir );
}
