<?php
/**
 * WPusher_Backup
 *
 * Creates, restores, and manages server-side backups.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPusher_Backup {

	/**
	 * Get the backup directory path.
	 *
	 * @return string
	 */
	public static function get_backup_dir() {
		$upload_dir = wp_upload_dir();
		return trailingslashit( $upload_dir['basedir'] ) . 'websitepusher-backups';
	}

	/**
	 * Ensure the backup directory exists and is protected.
	 */
	public static function ensure_backup_directory() {
		$dir = self::get_backup_dir();

		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		// Prevent direct web access.
		$htaccess = trailingslashit( $dir ) . '.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			file_put_contents( $htaccess, "Deny from all\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		$index = trailingslashit( $dir ) . 'index.php';
		if ( ! file_exists( $index ) ) {
			file_put_contents( $index, "<?php // Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}
	}

	/**
	 * Create a ZIP backup of a directory.
	 *
	 * @param  string $source_dir  Directory to back up.
	 * @param  string $label       Label for the backup filename.
	 * @return string|WP_Error     Path to the created backup ZIP.
	 */
	public static function create_backup( $source_dir, $label ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'no_zip', 'ZipArchive PHP extension is required.' );
		}

		if ( ! is_dir( $source_dir ) ) {
			return new WP_Error( 'not_found', "Source directory not found: {$source_dir}" );
		}

		self::ensure_backup_directory();

		$filename    = sanitize_file_name( "backup_{$label}_" . gmdate( 'Y-m-d_His' ) . '.zip' );
		$backup_path = trailingslashit( self::get_backup_dir() ) . $filename;

		$zip    = new ZipArchive();
		$opened = $zip->open( $backup_path, ZipArchive::CREATE | ZipArchive::OVERWRITE );

		if ( true !== $opened ) {
			return new WP_Error( 'zip_create', "Could not create backup ZIP (code: {$opened})." );
		}

		$source_dir = trailingslashit( realpath( $source_dir ) );
		$iterator   = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $source_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::LEAVES_ONLY
		);

		foreach ( $iterator as $file ) {
			if ( $file->isFile() ) {
				$relative = substr( $file->getRealPath(), strlen( $source_dir ) );
				$zip->addFile( $file->getRealPath(), $relative );
			}
		}

		$zip->close();

		if ( ! file_exists( $backup_path ) ) {
			return new WP_Error( 'zip_missing', 'Backup ZIP was not created.' );
		}

		return $backup_path;
	}

	/**
	 * Restore a backup ZIP to a target directory.
	 *
	 * @param  string $backup_path Path to the backup ZIP.
	 * @param  string $target_dir  Directory to restore into.
	 * @return true|WP_Error
	 */
	public static function restore_backup( $backup_path, $target_dir ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'no_zip', 'ZipArchive PHP extension is required.' );
		}

		if ( ! file_exists( $backup_path ) ) {
			return new WP_Error( 'not_found', "Backup not found: {$backup_path}" );
		}

		$zip    = new ZipArchive();
		$opened = $zip->open( $backup_path );

		if ( true !== $opened ) {
			return new WP_Error( 'zip_open', "Could not open backup ZIP (code: {$opened})." );
		}

		// Clear the target directory first.
		self::clear_directory( $target_dir );

		$result = $zip->extractTo( $target_dir );
		$zip->close();

		if ( ! $result ) {
			return new WP_Error( 'extract_failed', 'Could not extract backup.' );
		}

		return true;
	}

	/**
	 * Remove old backups beyond the retention count.
	 *
	 * @param int $keep Number of backups to keep.
	 */
	public static function cleanup_old_backups( $keep = 10 ) {
		$dir   = self::get_backup_dir();
		$files = glob( trailingslashit( $dir ) . '*.zip' );

		if ( ! $files || count( $files ) <= $keep ) {
			return;
		}

		// Sort oldest first.
		usort( $files, function( $a, $b ) {
			return filemtime( $a ) - filemtime( $b );
		} );

		$to_delete = array_slice( $files, 0, count( $files ) - $keep );

		foreach ( $to_delete as $file ) {
			if ( file_exists( $file ) ) {
				unlink( $file );
			}
		}
	}

	/**
	 * Clear all files from a directory without removing the directory itself.
	 *
	 * @param string $dir Directory to clear.
	 */
	private static function clear_directory( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ( $iterator as $item ) {
			if ( $item->isDir() ) {
				rmdir( $item->getRealPath() );
			} else {
				if ( file_exists( $item->getRealPath() ) ) {
					unlink( $item->getRealPath() );
				}
			}
		}
	}
}
