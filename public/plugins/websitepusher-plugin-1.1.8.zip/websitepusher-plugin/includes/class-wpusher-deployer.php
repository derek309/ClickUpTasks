<?php
/**
 * WPusher_Deployer
 *
 * Orchestrates the full deployment pipeline:
 *   dry_run()  — preview changes, no writes
 *   deploy()   — backup → extract → delete → health check → auto-rollback
 *   pull()     — package live theme/plugin as ZIP for download
 *   rollback() — restore most recent backup
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPusher_Deployer {

	/**
	 * Analyse a ZIP and return what would change without touching anything.
	 *
	 * @param  string $zip_path   Path to the ZIP file.
	 * @param  string $target_dir Absolute path to deploy into.
	 * @param  array  $deletions  Relative paths to delete.
	 * @return array|WP_Error
	 */
	public static function dry_run( $zip_path, $target_dir, $deletions = array() ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'no_zip', 'ZipArchive PHP extension is required.' );
		}

		$zip    = new ZipArchive();
		$opened = $zip->open( $zip_path );

		if ( true !== $opened ) {
			return new WP_Error( 'zip_open', "Could not open ZIP (code: {$opened})." );
		}

		$to_add    = array();
		$to_update = array();
		$blocked   = array();

		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$stat = $zip->statIndex( $i );
			$name = $stat['name'];

			if ( str_ends_with( $name, '/' ) ) {
				continue;
			}

			$valid = WPusher_Security::validate_zip_path( $name, $target_dir );
			if ( is_wp_error( $valid ) ) {
				$blocked[] = array(
					'file'   => $name,
					'reason' => $valid->get_error_message(),
				);
				continue;
			}

			$dest = trailingslashit( $target_dir ) . $name;
			if ( file_exists( $dest ) ) {
				$to_update[] = $name;
			} else {
				$to_add[] = $name;
			}
		}

		$zip->close();

		// Validate deletions.
		$valid_deletions = array();
		foreach ( $deletions as $del ) {
			$del  = str_replace( '\\', '/', sanitize_text_field( $del ) );
			$full = trailingslashit( $target_dir ) . $del;
			if ( file_exists( $full ) ) {
				$valid_deletions[] = $del;
			}
		}

		return array(
			'files_to_add'    => $to_add,
			'files_to_update' => $to_update,
			'files_to_delete' => $valid_deletions,
			'blocked'         => $blocked,
			'total_files'     => count( $to_add ) + count( $to_update ),
		);
	}

	/**
	 * Run a full deployment.
	 *
	 * @param  string $zip_path    Path to the ZIP file.
	 * @param  string $target_dir  Directory to deploy into.
	 * @param  string $target_slug Theme or plugin slug for labelling.
	 * @param  string $type        'theme' or 'plugin'.
	 * @param  array  $deletions   Relative paths to delete.
	 * @param  string $note        Deployment note from user.
	 * @return array|WP_Error
	 */
	public static function deploy( $zip_path, $target_dir, $target_slug, $type = 'theme', $deletions = array(), $note = '', $actor = '', $via = '' ) {
		// 1. Dry run to validate.
		$dry = self::dry_run( $zip_path, $target_dir, $deletions );
		if ( is_wp_error( $dry ) ) {
			return $dry;
		}

		if ( 0 === $dry['total_files'] && empty( $dry['files_to_delete'] ) && empty( $dry['blocked'] ) ) {
			return new WP_Error( 'empty', 'Nothing to deploy.' );
		}

		if ( 0 === $dry['total_files'] && ! empty( $dry['blocked'] ) ) {
			return new WP_Error( 'all_blocked', 'All files were blocked by security validation.', $dry['blocked'] );
		}

		// 2. Backup (skipped for media — uploads can be many gigabytes and images don't need rollback).
		$backup_path = null;
		if ( 'media' !== $type ) {
			$backup_path = WPusher_Backup::create_backup( $target_dir, $target_slug );
			if ( is_wp_error( $backup_path ) ) {
				return $backup_path;
			}
		}

		// 3. Extract files.
		$deployed = self::extract_files( $zip_path, $target_dir );
		if ( is_wp_error( $deployed ) ) {
			WPusher_History::add(
				array(
					'status'       => 'failed',
					'type'         => $type,
					'target'       => $target_slug,
					'backup_path'  => $backup_path,
					'note'         => $note,
					'message'      => 'Extraction failed: ' . $deployed->get_error_message(),
					'can_rollback' => ( null !== $backup_path ),
				)
			);
			return $deployed;
		}

		// 4. Process deletions.
		$deleted = array();
		foreach ( $dry['files_to_delete'] as $rel ) {
			$full = trailingslashit( $target_dir ) . $rel;
			if ( file_exists( $full ) ) {
				unlink( $full );
				$deleted[] = $rel;
			}
		}

		// 5. Health check (skipped for media — uploading images cannot cause PHP errors).
		$health = array( 'ok' => true, 'status_code' => 200, 'reason' => 'OK' );
		if ( 'media' !== $type ) {
			$health = self::health_check();

			if ( ! $health['ok'] ) {
				// Auto-rollback.
				$rollback = WPusher_Backup::restore_backup( $backup_path, $target_dir );
				$rb_msg   = is_wp_error( $rollback )
					? 'Auto-rollback FAILED: ' . $rollback->get_error_message()
					: 'Auto-rollback succeeded.';

				WPusher_History::add(
					array(
						'status'       => 'rolled_back',
						'type'         => $type,
						'target'       => $target_slug,
						'files'        => $deployed,
						'deleted'      => $deleted,
						'backup_path'  => $backup_path,
						'note'         => $note,
						'message'      => "Health check failed: {$health['reason']}. {$rb_msg}",
						'can_rollback' => false,
					)
				);

				return new WP_Error( 'health_failed', "Site error detected. {$rb_msg}", $health );
			}
		}

		// 6. Cleanup old backups.
		$retention = (int) get_option( 'wpusher_backup_retention', 10 );
		if ( $retention > 0 ) {
			WPusher_Backup::cleanup_old_backups( $retention );
		}

		// 7. Log success.
		$record_id = WPusher_History::add(
			array(
				'status'       => 'success',
				'type'         => $type,
				'target'       => $target_slug,
				'files'        => $deployed,
				'deleted'      => $deleted,
				'backup_path'  => $backup_path,
				'note'         => $note,
				'actor'        => $actor,
				'via'          => $via,
				'message'      => sprintf(
					'Deployed %d file(s)%s. %d blocked.',
					count( $deployed ),
					count( $deleted ) ? ', deleted ' . count( $deleted ) : '',
					count( $dry['blocked'] )
				),
				'can_rollback' => ( null !== $backup_path ),
			)
		);

		return array(
			'record_id'      => $record_id,
			'files_deployed' => $deployed,
			'files_deleted'  => $deleted,
			'files_blocked'  => $dry['blocked'],
			'backup_path'    => $backup_path,
			'health'         => $health,
		);
	}

	/**
	 * Extract security-approved files from ZIP into target directory.
	 *
	 * @param  string $zip_path   Path to the ZIP file.
	 * @param  string $target_dir Directory to extract into.
	 * @return array|WP_Error     List of deployed files or error.
	 */
	private static function extract_files( $zip_path, $target_dir ) {
		$zip    = new ZipArchive();
		$opened = $zip->open( $zip_path );

		if ( true !== $opened ) {
			return new WP_Error( 'zip_open', "Could not open ZIP (code: {$opened})." );
		}

		$deployed   = array();
		$target_dir = trailingslashit( realpath( $target_dir ) );

		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$stat = $zip->statIndex( $i );
			$name = $stat['name'];

			if ( str_ends_with( $name, '/' ) ) {
				continue;
			}

			$valid = WPusher_Security::validate_zip_path( $name, $target_dir );
			if ( is_wp_error( $valid ) ) {
				continue;
			}

			$dest     = $target_dir . $name;
			$dest_dir = dirname( $dest );

			if ( ! is_dir( $dest_dir ) ) {
				wp_mkdir_p( $dest_dir );
			}

			$contents = $zip->getFromIndex( $i );

			if ( false === $contents ) {
				$zip->close();
				return new WP_Error( 'read_failed', "Could not read: {$name}" );
			}

			if ( false === file_put_contents( $dest, $contents ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
				$zip->close();
				return new WP_Error( 'write_failed', "Could not write: {$name}" );
			}

			$deployed[] = $name;
		}

		$zip->close();
		return $deployed;
	}

	/**
	 * Package the live theme or plugin as a ZIP for the desktop app to download.
	 *
	 * @param  string $source_dir Directory to package.
	 * @param  string $label      Label for the ZIP filename.
	 * @return string|WP_Error    Path to the created ZIP.
	 */
	public static function package_for_pull( $source_dir, $label ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'no_zip', 'ZipArchive PHP extension is required.' );
		}

		if ( ! is_dir( $source_dir ) ) {
			return new WP_Error( 'not_found', "Directory not found: {$source_dir}" );
		}

		$tmp_path = get_temp_dir() . 'wpusher_pull_' . sanitize_key( $label ) . '_' . time() . '.zip';

		$zip    = new ZipArchive();
		$opened = $zip->open( $tmp_path, ZipArchive::CREATE | ZipArchive::OVERWRITE );

		if ( true !== $opened ) {
			return new WP_Error( 'zip_create', "Could not create pull ZIP (code: {$opened})." );
		}

		$source_dir = trailingslashit( realpath( $source_dir ) );
		$iterator   = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $source_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::LEAVES_ONLY
		);

		foreach ( $iterator as $file ) {
			if ( $file->isFile() ) {
				$relative = substr( $file->getRealPath(), strlen( $source_dir ) );
				$valid    = WPusher_Security::validate_zip_path( $relative, $source_dir );
				if ( ! is_wp_error( $valid ) ) {
					$zip->addFile( $file->getRealPath(), $relative );
				}
			}
		}

		$zip->close();

		if ( ! file_exists( $tmp_path ) ) {
			return new WP_Error( 'zip_missing', 'Pull ZIP was not created.' );
		}

		return $tmp_path;
	}

	/**
	 * Signature map of everything in a directory: "size:sha1" keyed by the path
	 * relative to that directory.
	 *
	 * The client holds a baseline of the same shape, recorded when it last
	 * pushed. Comparing the two is how it notices that somebody else changed a
	 * file in the meantime, before it overwrites their work.
	 *
	 * @param  string $source_dir Directory to walk.
	 * @param  int    $limit      Stop after this many files.
	 * @return array|WP_Error
	 */
	public static function signatures( $source_dir, $limit = 5000 ) {
		if ( ! is_dir( $source_dir ) ) {
			return new WP_Error( 'not_found', "Directory not found: {$source_dir}" );
		}

		$real = realpath( $source_dir );
		if ( false === $real ) {
			return new WP_Error( 'not_found', "Directory not found: {$source_dir}" );
		}
		$real = trailingslashit( $real );

		$out       = array();
		$truncated = false;
		$iterator  = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $real, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::LEAVES_ONLY
		);

		foreach ( $iterator as $file ) {
			if ( ! $file->isFile() ) {
				continue;
			}

			if ( count( $out ) >= $limit ) {
				$truncated = true;
				break;
			}

			$path     = $file->getRealPath();
			$relative = substr( $path, strlen( $real ) );
			$valid    = WPusher_Security::validate_zip_path( $relative, $real );
			if ( is_wp_error( $valid ) ) {
				continue;
			}

			$sha = sha1_file( $path );
			if ( false === $sha ) {
				continue;
			}

			$out[ $relative ] = $file->getSize() . ':' . $sha;
		}

		return array(
			'files'     => $out,
			'count'     => count( $out ),
			'truncated' => $truncated,
		);
	}

	/**
	 * Roll back to the most recent rollback-capable backup.
	 *
	 * @param  string $target_dir Directory to restore into.
	 * @return array|WP_Error
	 */
	public static function rollback( $target_dir ) {
		$record = WPusher_History::get_latest_rollbackable();

		if ( ! $record ) {
			return new WP_Error( 'no_backup', 'No rollback-capable backup found.' );
		}

		$result = WPusher_Backup::restore_backup( $record['backup_path'], $target_dir );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		WPusher_History::update( $record['id'], array( 'can_rollback' => false ) );

		WPusher_History::add(
			array(
				'status'       => 'rolled_back',
				'type'         => $record['type'] ?? 'theme',
				'target'       => $record['target'] ?? '',
				'backup_path'  => $record['backup_path'],
				'note'         => 'Manual rollback to: ' . WPusher_History::format_date( $record['timestamp'] ),
				'can_rollback' => false,
			)
		);

		return array(
			'restored_from' => $record['backup_path'],
			'original_date' => $record['timestamp'],
		);
	}

	/**
	 * Roll back to a specific backup by record ID.
	 *
	 * @param string $record_id   History record ID.
	 * @param string $backup_path Path to the backup ZIP.
	 * @param string $target_dir  Directory to restore into.
	 * @return array|WP_Error
	 */
	public static function rollback_to( $record_id, $backup_path, $target_dir ) {
		if ( ! file_exists( $backup_path ) ) {
			return new WP_Error( 'not_found', 'Backup file not found.' );
		}

		$result = WPusher_Backup::restore_backup( $backup_path, $target_dir );
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		WPusher_History::update( $record_id, array( 'can_rollback' => false ) );

		WPusher_History::add(
			array(
				'status'       => 'rolled_back',
				'type'         => 'theme',
				'target'       => get_stylesheet(),
				'backup_path'  => $backup_path,
				'note'         => 'Manual rollback',
				'can_rollback' => false,
			)
		);

		return array( 'restored_from' => $backup_path );
	}

	/**
	 * HTTP health check on the site homepage.
	 *
	 * @return array { ok: bool, status_code: int, reason: string }
	 */
	public static function health_check() {
		$response = wp_remote_get(
			home_url( '/' ),
			array(
				'timeout'   => 15,
				'sslverify' => false,
				'headers'   => array( 'Cache-Control' => 'no-cache' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'ok'          => false,
				'status_code' => 0,
				'reason'      => 'Request failed: ' . $response->get_error_message(),
			);
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );

		$error_patterns = array(
			'Fatal error',
			'Parse error',
			'Uncaught Error',
			'Call to undefined',
			'WordPress database error',
		);

		$base = '';
		foreach ( $error_patterns as $pattern ) {
			if ( str_contains( $body, $pattern ) ) {
				$base = "PHP error detected: \"{$pattern}\"";
				break;
			}
		}

		if ( '' === $base && ( $code < 200 || $code >= 400 ) ) {
			$base = "HTTP {$code}";
		}

		if ( '' === $base ) {
			return array(
				'ok'          => true,
				'status_code' => $code,
				'reason'      => 'OK',
			);
		}

		// On a production site display_errors is usually off, so the page body is
		// just a blank 500 with no message. Pull the actual fatal from the server
		// log so the desktop app can show what really broke.
		$fatal  = self::read_recent_fatal();
		$reason = $fatal ? "{$base}: {$fatal}" : $base;

		return array(
			'ok'          => false,
			'status_code' => $code,
			'reason'      => $reason,
		);
	}

	/**
	 * Read the most recent PHP fatal/parse error from the server's log files.
	 * Read-only and failure-tolerant — returns '' if nothing is found.
	 *
	 * @return string The latest fatal line (timestamp stripped, truncated), or ''.
	 */
	private static function read_recent_fatal() {
		$candidates = array();
		if ( defined( 'WP_CONTENT_DIR' ) ) {
			$candidates[] = WP_CONTENT_DIR . '/debug.log';
			$candidates[] = WP_CONTENT_DIR . '/error_log';
		}
		$ini = ini_get( 'error_log' );
		if ( $ini ) {
			$candidates[] = $ini;
		}
		if ( defined( 'ABSPATH' ) ) {
			$candidates[] = ABSPATH . 'error_log';
		}

		foreach ( $candidates as $path ) {
			if ( ! $path || ! @is_readable( $path ) ) {
				continue;
			}
			$size = @filesize( $path );
			if ( ! $size ) {
				continue;
			}
			$fh = @fopen( $path, 'rb' );
			if ( ! $fh ) {
				continue;
			}
			$read = (int) min( $size, 65536 ); // last 64 KB is plenty.
			@fseek( $fh, -$read, SEEK_END );
			$tail = @fread( $fh, $read );
			@fclose( $fh );
			if ( ! $tail ) {
				continue;
			}

			$lines = preg_split( '/\r\n|\r|\n/', $tail );
			for ( $i = count( $lines ) - 1; $i >= 0; $i-- ) {
				if ( preg_match( '/PHP (Fatal error|Parse error|Uncaught)/i', $lines[ $i ] ) ) {
					$line = trim( $lines[ $i ] );
					$line = preg_replace( '/^\[[^\]]*\]\s*/', '', $line ); // strip leading timestamp.
					if ( strlen( $line ) > 300 ) {
						$line = substr( $line, 0, 300 ) . '…';
					}
					return $line;
				}
			}
		}

		return '';
	}
}
