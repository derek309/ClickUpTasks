<?php
/**
 * WPusher_Security
 *
 * All security decisions in one place:
 * - Allowed/blocked file extensions
 * - Path traversal prevention
 * - API key verification (timing-safe)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPusher_Security {

	const ALLOWED_EXTENSIONS = array(
		'php', 'css', 'js', 'json', 'html', 'htm',
		'txt', 'md', 'svg', 'png', 'jpg', 'jpeg',
		'webp', 'gif', 'ico', 'woff', 'woff2', 'ttf',
		'eot', 'otf', 'scss', 'map', 'xml', 'mo', 'po',
		'pot', 'lock', 'gitignore', 'env.example',
	);

	const BLOCKED_EXTENSIONS = array(
		'exe', 'sh', 'bash', 'bat', 'cmd', 'ps1',
		'phar', 'py', 'rb', 'pl', 'cgi', 'perl',
		'asp', 'aspx', 'jsp', 'so', 'dll', 'bin',
	);

	/**
	 * Verify API key using timing-safe comparison.
	 *
	 * @param WP_REST_Request $request The REST request.
	 * @return bool
	 */
	public static function verify_api_key( WP_REST_Request $request ) {
		$supplied = $request->get_header( 'X-WPusher-API-Key' );
		// Backwards compatibility with older app versions.
		if ( empty( $supplied ) ) {
			$supplied = $request->get_header( 'X-TP-API-Key' );
		}

		$stored = self::get_api_key();

		if ( empty( $supplied ) || empty( $stored ) ) {
			return false;
		}

		return hash_equals( $stored, $supplied );
	}

	/**
	 * Resolve the active connection code.
	 *
	 * A WPUSHER_API_KEY constant (defined in wp-config.php) always wins over the
	 * stored option. The constant lives outside the database, so it is immune to
	 * full-site copies (local → staging → live) that carry wp_options along and
	 * would otherwise overwrite each environment's key. Define the SAME constant
	 * in every environment's wp-config.php and one connection code works everywhere.
	 *
	 * @return string
	 */
	public static function get_api_key() {
		if ( defined( 'WPUSHER_API_KEY' ) && WPUSHER_API_KEY ) {
			return (string) WPUSHER_API_KEY;
		}
		return (string) get_option( 'wpusher_api_key', '' );
	}

	/**
	 * Whether the connection code is pinned by a wp-config constant.
	 *
	 * @return bool
	 */
	public static function is_api_key_locked() {
		return defined( 'WPUSHER_API_KEY' ) && WPUSHER_API_KEY;
	}

	/**
	 * Validate a path from a ZIP file.
	 * Blocks traversal, null bytes, absolute paths, and dangerous extensions.
	 *
	 * @param  string $zip_path   Path as it appears in the ZIP.
	 * @param  string $target_dir Absolute path to the target directory.
	 * @return true|WP_Error
	 */
	public static function validate_zip_path( $zip_path, $target_dir ) {
		$zip_path = str_replace( '\\', '/', $zip_path );

		if ( str_starts_with( $zip_path, '/' ) ) {
			return new WP_Error( 'absolute_path', "Blocked absolute path: {$zip_path}" );
		}

		if ( str_contains( $zip_path, '../' ) || str_contains( $zip_path, "..\\" ) ) {
			return new WP_Error( 'traversal', "Blocked path traversal: {$zip_path}" );
		}

		if ( str_contains( $zip_path, "\0" ) ) {
			return new WP_Error( 'null_byte', "Null byte in path: {$zip_path}" );
		}

		// Skip directory entries.
		if ( str_ends_with( $zip_path, '/' ) ) {
			return true;
		}

		$ext = strtolower( pathinfo( $zip_path, PATHINFO_EXTENSION ) );

		// Extensionless files are allowed.
		if ( empty( $ext ) ) {
			return true;
		}

		if ( in_array( $ext, self::BLOCKED_EXTENSIONS, true ) ) {
			return new WP_Error( 'blocked_ext', "Blocked file type (.{$ext}): {$zip_path}" );
		}

		if ( ! in_array( $ext, self::ALLOWED_EXTENSIONS, true ) ) {
			return new WP_Error( 'unknown_ext', "File type not allowed (.{$ext}): {$zip_path}" );
		}

		// Final real-path check — confirm destination stays inside target dir.
		$real_target = realpath( $target_dir );
		if ( $real_target ) {
			$dest = self::normalize_path( $real_target . DIRECTORY_SEPARATOR . $zip_path );
			if ( ! str_starts_with( $dest, $real_target . DIRECTORY_SEPARATOR ) ) {
				return new WP_Error( 'outside_target', "Path escapes target directory: {$zip_path}" );
			}
		}

		return true;
	}

	/**
	 * Normalize a path without requiring it to exist on disk.
	 *
	 * @param string $path The path to normalize.
	 * @return string
	 */
	public static function normalize_path( $path ) {
		$sep    = DIRECTORY_SEPARATOR;
		$parts  = explode( $sep, str_replace( '/', $sep, $path ) );
		$result = array();

		foreach ( $parts as $part ) {
			if ( '' === $part || '.' === $part ) {
				continue;
			}
			if ( '..' === $part ) {
				array_pop( $result );
				continue;
			}
			$result[] = $part;
		}

		return ( str_starts_with( $path, '/' ) ? '/' : '' ) . implode( $sep, $result );
	}

	/**
	 * Regenerate and save the API key.
	 *
	 * @return string The new API key.
	 */
	public static function regenerate_api_key() {
		$key = wp_generate_password( 48, false );
		update_option( 'wpusher_api_key', $key );
		return $key;
	}
}
