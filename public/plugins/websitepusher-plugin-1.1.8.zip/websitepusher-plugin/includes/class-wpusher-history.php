<?php
/**
 * WPusher_History
 *
 * Stores and retrieves deployment history in wp_options.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPusher_History {

	const OPTION_KEY = 'wpusher_history';
	const MAX_ITEMS  = 50;

	/**
	 * Add a history record.
	 *
	 * @param  array $data Record data.
	 * @return string      Record ID.
	 */
	public static function add( array $data ) {
		$records   = self::get_all();
		$record_id = 'wpusher_' . uniqid();

		$record = array_merge(
			array(
				'id'           => $record_id,
				'timestamp'    => gmdate( 'Y-m-d H:i:s' ),
				'status'       => 'success',
				'type'         => 'theme',
				'target'       => '',
				'files'        => array(),
				'deleted'      => array(),
				'backup_path'  => '',
				'note'         => '',
				'message'      => '',
				'can_rollback' => false,
				// Who ran this deploy. The API key identifies the site, not the
				// person, so the client tells us: 'actor' is their licence email
				// and 'via' is app or claude. Empty for deploys from clients too
				// old to send them.
				'actor'        => '',
				'via'          => '',
			),
			$data,
			array( 'id' => $record_id )
		);

		array_unshift( $records, $record );

		// Keep only the most recent records.
		$records = array_slice( $records, 0, self::MAX_ITEMS );

		update_option( self::OPTION_KEY, $records );

		return $record_id;
	}

	/**
	 * Update a specific record.
	 *
	 * @param string $id      Record ID.
	 * @param array  $updates Fields to update.
	 */
	public static function update( $id, array $updates ) {
		$records = self::get_all();

		foreach ( $records as &$record ) {
			if ( $record['id'] === $id ) {
				$record = array_merge( $record, $updates );
				break;
			}
		}

		update_option( self::OPTION_KEY, $records );
	}

	/**
	 * Get all history records.
	 *
	 * @return array
	 */
	public static function get_all() {
		$records = get_option( self::OPTION_KEY, array() );
		return is_array( $records ) ? $records : array();
	}

	/**
	 * Get the most recent record that can be rolled back.
	 *
	 * @return array|null
	 */
	public static function get_latest_rollbackable() {
		foreach ( self::get_all() as $record ) {
			if ( ! empty( $record['can_rollback'] ) && ! empty( $record['backup_path'] ) && file_exists( $record['backup_path'] ) ) {
				return $record;
			}
		}
		return null;
	}

	/**
	 * Format a timestamp for display.
	 *
	 * @param  string $timestamp MySQL datetime string.
	 * @return string
	 */
	public static function format_date( $timestamp ) {
		$time = strtotime( $timestamp );
		if ( ! $time ) {
			return $timestamp;
		}
		return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $time );
	}
}
