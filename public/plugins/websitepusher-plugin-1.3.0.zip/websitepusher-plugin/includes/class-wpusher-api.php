<?php
/**
 * WPusher_API
 *
 * REST API endpoints for the WebsitePusher desktop app.
 *
 * All endpoints require the X-WPusher-API-Key header.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPusher_API {

	private static $instance = null;

	/**
	 * Get the singleton instance.
	 *
	 * @return WPusher_API
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register REST API routes.
	 */
	public function register_routes() {
		$ns   = 'websitepusher/v1';
		$auth = array( $this, 'check_auth' );

		register_rest_route( $ns, '/status',          array( 'methods' => 'GET',  'callback' => array( $this, 'status' ),          'permission_callback' => $auth ) );
		register_rest_route( $ns, '/dry-run',         array( 'methods' => 'POST', 'callback' => array( $this, 'dry_run' ),         'permission_callback' => $auth ) );
		register_rest_route( $ns, '/deploy',          array( 'methods' => 'POST', 'callback' => array( $this, 'deploy' ),          'permission_callback' => $auth ) );
		register_rest_route( $ns, '/pull',            array( 'methods' => 'GET',  'callback' => array( $this, 'pull' ),            'permission_callback' => $auth ) );
		register_rest_route( $ns, '/rollback',        array( 'methods' => 'POST', 'callback' => array( $this, 'rollback' ),        'permission_callback' => $auth ) );
		register_rest_route( $ns, '/rollback-to',     array( 'methods' => 'POST', 'callback' => array( $this, 'rollback_to' ),     'permission_callback' => $auth ) );
		register_rest_route( $ns, '/history',         array( 'methods' => 'GET',  'callback' => array( $this, 'history' ),         'permission_callback' => $auth ) );
		register_rest_route( $ns, '/media-inventory', array( 'methods' => 'GET',  'callback' => array( $this, 'media_inventory' ), 'permission_callback' => $auth ) );
		register_rest_route( $ns, '/file',            array( 'methods' => 'GET',  'callback' => array( $this, 'get_file' ),        'permission_callback' => $auth ) );
		register_rest_route( $ns, '/signatures',      array( 'methods' => 'GET',  'callback' => array( $this, 'signatures' ),      'permission_callback' => $auth ) );

		// Full-site pull: files, then the database in chunks.
		WPusher_SitePull::register_routes( $ns, $auth );

		// Who is working on the site, and where its code lives.
		WPusher_Team::register_routes( $ns, $auth );

		// Backwards compatibility with older app versions using the old namespace.
		$old_ns = 'theme-pusher/v1';
		register_rest_route( $old_ns, '/status',  array( 'methods' => 'GET',  'callback' => array( $this, 'status' ),  'permission_callback' => $auth ) );
		register_rest_route( $old_ns, '/deploy',  array( 'methods' => 'POST', 'callback' => array( $this, 'deploy' ),  'permission_callback' => $auth ) );
		register_rest_route( $old_ns, '/dry-run', array( 'methods' => 'POST', 'callback' => array( $this, 'dry_run' ), 'permission_callback' => $auth ) );
		register_rest_route( $old_ns, '/pull',    array( 'methods' => 'GET',  'callback' => array( $this, 'pull' ),    'permission_callback' => $auth ) );
		register_rest_route( $old_ns, '/rollback',array( 'methods' => 'POST', 'callback' => array( $this, 'rollback' ),'permission_callback' => $auth ) );
	}

	/**
	 * Check API key authentication.
	 *
	 * @param WP_REST_Request $request The request.
	 * @return true|WP_Error
	 */
	public function check_auth( WP_REST_Request $request ) {
		if ( ! WPusher_Security::verify_api_key( $request ) ) {
			return new WP_Error(
				'unauthorized',
				'Invalid or missing API key. Send it in the X-WPusher-API-Key header.',
				array( 'status' => 401 )
			);
		}
		return true;
	}

	/**
	 * GET /status — return site and theme info.
	 *
	 * @return WP_REST_Response
	 */
	public function status() {
		$theme = wp_get_theme();
		return new WP_REST_Response(
			array(
				'plugin_version' => WPUSHER_VERSION,
				'site_url'       => get_site_url(),
				'theme_name'     => $theme->get( 'Name' ),
				'theme_slug'     => get_stylesheet(),
				'theme_dir'      => get_stylesheet_directory(),
				'is_child_theme' => (bool) $theme->parent(),
				'parent_theme'   => $theme->parent() ? $theme->parent()->get( 'Name' ) : null,
				'wp_version'     => get_bloginfo( 'version' ),
				'php_version'    => PHP_VERSION,
				'team'           => WPusher_Team::info(),
			),
			200
		);
	}

	/**
	 * POST /dry-run — preview what would change.
	 *
	 * @param WP_REST_Request $request The request.
	 * @return WP_REST_Response
	 */
	public function dry_run( WP_REST_Request $request ) {
		$zip = $this->get_uploaded_zip( $request );
		if ( is_wp_error( $zip ) ) {
			return $this->error_response( $zip );
		}

		$target    = $this->get_target_dir( $request );
		$deletions = $request->get_param( 'deletions' ) ?? array();
		$result    = WPusher_Deployer::dry_run( $zip, $target, (array) $deletions );

		if ( file_exists( $zip ) ) {
			unlink( $zip );
		}

		if ( is_wp_error( $result ) ) {
			return $this->error_response( $result );
		}

		return new WP_REST_Response( array_merge( $result, array( 'mode' => 'dry_run' ) ), 200 );
	}

	/**
	 * POST /deploy — deploy files to the live site.
	 *
	 * @param WP_REST_Request $request The request.
	 * @return WP_REST_Response
	 */
	public function deploy( WP_REST_Request $request ) {
		// Reject unknown types so old plugin versions can't be tricked into dumping
		// files into the theme folder when the app sends type=media to a host that
		// hasn't been updated yet.
		$req_type = sanitize_key( $request->get_param( 'type' ) ?: 'theme' );
		if ( ! in_array( $req_type, array( 'theme', 'plugin', 'media' ), true ) ) {
			return new WP_REST_Response( array( 'success' => false, 'message' => 'Unsupported deploy type. Update the WebsitePusher plugin on this site.' ), 400 );
		}

		$zip = $this->get_uploaded_zip( $request );
		if ( is_wp_error( $zip ) ) {
			return $this->error_response( $zip );
		}

		$type      = sanitize_key( $request->get_param( 'type' ) ?: 'theme' );
		$note      = sanitize_text_field( $request->get_param( 'note' ) ?: '' );
		// Who is pushing. Clients older than 1.1.5 don't send these; the record
		// simply carries empty strings and the app falls back to "unknown".
		$actor     = sanitize_text_field( $request->get_param( 'actor' ) ?: '' );
		$via       = sanitize_key( $request->get_param( 'via' ) ?: '' );
		if ( ! in_array( $via, array( 'app', 'claude', '' ), true ) ) {
			$via = '';
		}
		$deletions = (array) ( $request->get_param( 'deletions' ) ?? array() );
		$target    = $this->get_target_dir( $request );
		$slug      = 'plugin' === $type
			? sanitize_key( $request->get_param( 'plugin_slug' ) ?: 'plugin' )
			: get_stylesheet();

		$result = WPusher_Deployer::deploy( $zip, $target, $slug, $type, $deletions, $note, $actor, $via );

		if ( file_exists( $zip ) ) {
			unlink( $zip );
		}

		if ( is_wp_error( $result ) ) {
			return $this->error_response( $result, 422 );
		}

		return new WP_REST_Response( array_merge( $result, array( 'status' => 'success' ) ), 200 );
	}

	/**
	 * GET /pull — stream the live theme as a ZIP download.
	 *
	 * @param WP_REST_Request $request The request.
	 * @return WP_REST_Response|void
	 */
	public function pull( WP_REST_Request $request ) {
		$type   = sanitize_key( $request->get_param( 'type' ) ?: 'theme' );
		$target = $this->get_target_dir( $request );
		$label  = 'plugin' === $type
			? sanitize_key( $request->get_param( 'plugin_slug' ) ?: 'plugin' )
			: get_stylesheet();

		$zip_path = WPusher_Deployer::package_for_pull( $target, $label );
		if ( is_wp_error( $zip_path ) ) {
			return $this->error_response( $zip_path );
		}

		$filename = "pull_{$label}_" . gmdate( 'Y-m-d' ) . '.zip';

		// Stream the file directly to avoid loading it into memory.
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $filename ) . '"' );
		header( 'Content-Length: ' . filesize( $zip_path ) );
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		readfile( $zip_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile

		if ( file_exists( $zip_path ) ) {
			unlink( $zip_path );
		}

		// Use wp_die with no message to cleanly terminate after streaming.
		wp_die();
	}

	/**
	 * POST /rollback — restore the most recent backup.
	 *
	 * @param WP_REST_Request $request The request.
	 * @return WP_REST_Response
	 */
	public function rollback( WP_REST_Request $request ) {
		$target = $this->get_target_dir( $request );
		$result = WPusher_Deployer::rollback( $target );

		if ( is_wp_error( $result ) ) {
			return $this->error_response( $result );
		}

		return new WP_REST_Response( array_merge( $result, array( 'status' => 'rolled_back' ) ), 200 );
	}

	/**
	 * POST /rollback-to — restore a specific backup.
	 *
	 * @param WP_REST_Request $request The request.
	 * @return WP_REST_Response
	 */
	public function rollback_to( WP_REST_Request $request ) {
		$record_id   = sanitize_text_field( $request->get_param( 'record_id' ) ?: '' );
		$backup_path = sanitize_text_field( $request->get_param( 'backup_path' ) ?: '' );
		$target      = $this->get_target_dir( $request );

		// Security: backup must be inside our backup directory.
		$backup_dir = realpath( WPusher_Backup::get_backup_dir() );
		$real_path  = realpath( $backup_path );

		if ( ! $real_path || ! $backup_dir || ! str_starts_with( $real_path, $backup_dir ) ) {
			return $this->error_response( new WP_Error( 'invalid_path', 'Invalid backup path.', array( 'status' => 400 ) ) );
		}

		$result = WPusher_Deployer::rollback_to( $record_id, $backup_path, $target );

		if ( is_wp_error( $result ) ) {
			return $this->error_response( $result );
		}

		return new WP_REST_Response( array_merge( $result, array( 'status' => 'rolled_back' ) ), 200 );
	}

	/**
	 * GET /media-inventory — count and size of media files.
	 *
	 * @return WP_REST_Response
	 */
	public function media_inventory() {
		$upload_dir = wp_upload_dir();
		$base_dir   = $upload_dir['basedir'];
		$total      = 0;
		$size       = 0;

		$media_extensions = array(
			'jpg', 'jpeg', 'png', 'gif', 'webp',
			'svg', 'ico', 'mp4', 'mov', 'pdf',
		);

		if ( is_dir( $base_dir ) ) {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveDirectoryIterator( $base_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
				RecursiveIteratorIterator::LEAVES_ONLY
			);

			foreach ( $iterator as $file ) {
				if ( $file->isFile() ) {
					$ext = strtolower( pathinfo( $file->getFilename(), PATHINFO_EXTENSION ) );
					if ( in_array( $ext, $media_extensions, true ) ) {
						++$total;
						$size += $file->getSize();
					}
				}
			}
		}

		return new WP_REST_Response(
			array(
				'total' => $total,
				'size'  => $size,
			),
			200
		);
	}

	/**
	 * GET /signatures — what is on the site right now, as "size:sha1" per file.
	 *
	 * The client compares this against the baseline it recorded at its own last
	 * push. A file whose live signature no longer matches that baseline was
	 * changed by somebody else, and pushing over it would silently discard
	 * their work. One request covers the whole folder so the check costs the
	 * same whether the push is one file or fifty.
	 *
	 * @param  WP_REST_Request $request The request.
	 * @return WP_REST_Response
	 */
	public function signatures( WP_REST_Request $request ) {
		$type = sanitize_key( $request->get_param( 'type' ) ?: 'theme' );
		if ( ! in_array( $type, array( 'theme', 'plugin', 'media' ), true ) ) {
			return new WP_REST_Response(
				array( 'message' => 'Unsupported type.' ),
				400
			);
		}

		$limit  = (int) ( $request->get_param( 'limit' ) ?: 5000 );
		$limit  = max( 1, min( 20000, $limit ) );
		$result = WPusher_Deployer::signatures( $this->get_target_dir( $request ), $limit );

		if ( is_wp_error( $result ) ) {
			return $this->error_response( $result );
		}

		return new WP_REST_Response( $result, 200 );
	}

	/**
	 * GET /file — return the live contents of one file inside the deploy target.
	 *
	 * This is what lets the app and Claude show a real diff ("here is what is
	 * live, here is what you're about to push") instead of just a file name.
	 * Read-only, and confined to the same directory a deploy would write to.
	 *
	 * Binary files and anything oversized come back with a signature but no
	 * content — the caller only ever needs bytes it can actually diff.
	 *
	 * @param WP_REST_Request $request The request.
	 * @return WP_REST_Response
	 */
	public function get_file( WP_REST_Request $request ) {
		$max    = 2 * 1024 * 1024; // 2 MB — past this a line diff is useless anyway.
		$target = $this->get_target_dir( $request );
		$rel    = (string) $request->get_param( 'path' );
		$abs    = $this->resolve_inside( $target, $rel );

		if ( is_wp_error( $abs ) ) {
			return $this->error_response( $abs );
		}

		// A path that isn't there yet is a normal answer, not an error: it means
		// the file is new and the whole local copy is the diff.
		if ( ! file_exists( $abs ) || ! is_file( $abs ) ) {
			return new WP_REST_Response(
				array(
					'path'   => $rel,
					'exists' => false,
				),
				200
			);
		}

		$size = filesize( $abs );
		$out  = array(
			'path'   => $rel,
			'exists' => true,
			'size'   => $size,
			'sha1'   => sha1_file( $abs ),
		);

		if ( $size > $max ) {
			$out['too_large'] = true;
			return new WP_REST_Response( $out, 200 );
		}

		$contents = file_get_contents( $abs ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( false === $contents ) {
			return $this->error_response( new WP_Error( 'unreadable', 'File exists but could not be read.', array( 'status' => 500 ) ) );
		}

		// Null bytes or invalid UTF-8 mean there is nothing to show line by line.
		if ( false !== strpos( $contents, "\0" ) || ! mb_check_encoding( $contents, 'UTF-8' ) ) {
			$out['binary'] = true;
			return new WP_REST_Response( $out, 200 );
		}

		$out['content'] = $contents;
		return new WP_REST_Response( $out, 200 );
	}

	/**
	 * Resolve a caller-supplied relative path against a directory, refusing
	 * anything that escapes it (../, absolute paths, symlinks pointing out).
	 *
	 * @param string $dir Directory the path must stay inside.
	 * @param string $rel Relative path from the caller.
	 * @return string|WP_Error Absolute path, or an error.
	 */
	private function resolve_inside( $dir, $rel ) {
		$bad = new WP_Error( 'invalid_path', 'Invalid file path.', array( 'status' => 400 ) );

		if ( '' === $rel || false !== strpos( $rel, "\0" ) ) {
			return $bad;
		}
		// Absolute paths and Windows drive letters are never relative to $dir.
		if ( '/' === $rel[0] || '\\' === $rel[0] || preg_match( '#^[A-Za-z]:#', $rel ) ) {
			return $bad;
		}

		$base = realpath( $dir );
		if ( ! $base ) {
			return new WP_Error( 'no_target', 'Deploy target directory not found.', array( 'status' => 404 ) );
		}

		$abs = realpath( $base . '/' . $rel );
		if ( ! $abs ) {
			// Doesn't exist — normalise by hand so a new file still answers
			// "not there", while ../ still gets caught.
			$parts = array();
			foreach ( explode( '/', str_replace( '\\', '/', $rel ) ) as $part ) {
				if ( '' === $part || '.' === $part ) {
					continue;
				}
				if ( '..' === $part ) {
					if ( ! array_pop( $parts ) ) {
						return $bad;
					}
					continue;
				}
				$parts[] = $part;
			}
			return $base . '/' . implode( '/', $parts );
		}

		if ( ! str_starts_with( $abs, $base . '/' ) ) {
			return $bad;
		}

		return $abs;
	}

	/**
	 * GET /history — return deployment history.
	 *
	 * @return WP_REST_Response
	 */
	public function history() {
		return new WP_REST_Response( WPusher_History::get_all(), 200 );
	}

	/**
	 * Get target directory based on request type param.
	 *
	 * @param WP_REST_Request $request The request.
	 * @return string
	 */
	private function get_target_dir( WP_REST_Request $request ) {
		$type = sanitize_key( $request->get_param( 'type' ) ?: 'theme' );

		if ( 'plugin' === $type ) {
			$slug = sanitize_key( $request->get_param( 'plugin_slug' ) ?: '' );
			if ( $slug ) {
				return WP_PLUGIN_DIR . '/' . $slug;
			}
		}

		if ( 'media' === $type ) {
			$uploads = wp_get_upload_dir();
			return $uploads['basedir'];
		}

		return get_stylesheet_directory();
	}

	/**
	 * Move uploaded ZIP to a safe temp location and return the path.
	 *
	 * @param WP_REST_Request $request The request.
	 * @return string|WP_Error
	 */
	private function get_uploaded_zip( WP_REST_Request $request ) {
		$files = $request->get_file_params();

		if ( empty( $files['zip_file'] ) ) {
			return new WP_Error(
				'no_file',
				'No file uploaded. Send ZIP as multipart with field name "zip_file".',
				array( 'status' => 400 )
			);
		}

		$file = $files['zip_file'];

		if ( ! empty( $file['error'] ) ) {
			return new WP_Error(
				'upload_error',
				'Upload error code: ' . $file['error'],
				array( 'status' => 400 )
			);
		}

		// Validate MIME type.
		$finfo = new finfo( FILEINFO_MIME_TYPE );
		$mime  = $finfo->file( $file['tmp_name'] );

		$allowed_mimes = array(
			'application/zip',
			'application/x-zip-compressed',
			'application/octet-stream',
		);

		if ( ! in_array( $mime, $allowed_mimes, true ) ) {
			return new WP_Error(
				'invalid_mime',
				"Not a ZIP file (detected: {$mime}).",
				array( 'status' => 400 )
			);
		}

		$tmp = get_temp_dir() . 'wpusher_upload_' . uniqid() . '.zip';

		if ( ! move_uploaded_file( $file['tmp_name'], $tmp ) ) {
			return new WP_Error(
				'move_failed',
				'Could not move uploaded file.',
				array( 'status' => 500 )
			);
		}

		return $tmp;
	}

	/**
	 * Build an error REST response from a WP_Error.
	 *
	 * @param WP_Error $error   The error.
	 * @param int      $default Default HTTP status code.
	 * @return WP_REST_Response
	 */
	private function error_response( WP_Error $error, $default = 400 ) {
		$data   = $error->get_error_data();
		$status = isset( $data['status'] ) ? (int) $data['status'] : $default;

		return new WP_REST_Response(
			array(
				'error'   => $error->get_error_code(),
				'message' => $error->get_error_message(),
				'data'    => $data,
			),
			$status
		);
	}
}
