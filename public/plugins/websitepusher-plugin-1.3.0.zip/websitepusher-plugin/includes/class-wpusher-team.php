<?php
/**
 * WPusher_Team
 *
 * What the team shares about one website, kept on the website itself so every
 * teammate's app reads the same answer with no server of our own in between:
 *
 *   - who is working on it right now (a check-out), and
 *   - where its code lives on GitHub.
 *
 *   GET  /team           { github_repo, checkout }
 *   POST /team/checkout  { who, machine, note, force } → 409 if someone else has it
 *   POST /team/checkin   { who, force }                → 409 if someone else has it
 *   POST /team/github    { repo }                      → "" clears it
 *   POST /team/rotate-key                               → { api_key } a new connection code
 *
 * A check-out is a courtesy flag, not a lock the server enforces on pushes:
 * the app warns before pushing to a site someone else has, and anyone can
 * take a forgotten check-out over with force.
 *
 * The Brain Box sets the repo while the site is being built, through
 * WPusher_Team::set_github_repo(), so it's there before anyone asks.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPusher_Team {

	const OPT_CHECKOUT = 'wpusher_checkout';
	const OPT_GITHUB   = 'wpusher_github_repo';

	/**
	 * Register the routes. Called from WPusher_API::register_routes().
	 *
	 * @param string   $ns   REST namespace.
	 * @param callable $auth Permission callback.
	 */
	public static function register_routes( $ns, $auth ) {
		register_rest_route( $ns, '/team',          array( 'methods' => 'GET',  'callback' => array( __CLASS__, 'get' ),      'permission_callback' => $auth ) );
		register_rest_route( $ns, '/team/checkout', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'checkout' ), 'permission_callback' => $auth ) );
		register_rest_route( $ns, '/team/checkin',  array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'checkin' ),  'permission_callback' => $auth ) );
		register_rest_route( $ns, '/team/github',   array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'github' ),   'permission_callback' => $auth ) );
		register_rest_route( $ns, '/team/rotate-key', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rotate_key' ), 'permission_callback' => $auth ) );
	}

	/**
	 * Everything the app shows about the team for this site.
	 *
	 * @return array{github_repo:string,checkout:array|null}
	 */
	public static function info() {
		return array(
			'github_repo' => self::get_github_repo(),
			'checkout'    => self::get_checkout(),
		);
	}

	/**
	 * GET /team.
	 *
	 * @return WP_REST_Response
	 */
	public static function get() {
		return new WP_REST_Response( self::info(), 200 );
	}

	/**
	 * POST /team/checkout — mark the site as being worked on by `who`.
	 * Taking it again when you already have it just refreshes the note.
	 *
	 * @param WP_REST_Request $request The request.
	 * @return WP_REST_Response
	 */
	public static function checkout( WP_REST_Request $request ) {
		$who = sanitize_text_field( (string) $request->get_param( 'who' ) );
		if ( '' === $who ) {
			return new WP_REST_Response( array( 'message' => 'Say who is checking the site out.' ), 400 );
		}

		$current = self::get_checkout();
		if ( $current && ! self::same_person( $current['who'], $who ) && ! $request->get_param( 'force' ) ) {
			return new WP_REST_Response(
				array(
					'error'    => 'checked_out',
					'message'  => 'Someone else is working on this website.',
					'checkout' => $current,
				),
				409
			);
		}

		$checkout = array(
			'who'     => $who,
			'machine' => sanitize_text_field( (string) $request->get_param( 'machine' ) ),
			'note'    => sanitize_text_field( (string) $request->get_param( 'note' ) ),
			'since'   => $current && self::same_person( $current['who'], $who ) ? $current['since'] : gmdate( 'c' ),
		);
		if ( $current && ! self::same_person( $current['who'], $who ) ) {
			$checkout['took_over_from'] = $current['who'];
		}
		update_option( self::OPT_CHECKOUT, $checkout, false );

		return new WP_REST_Response( self::info(), 200 );
	}

	/**
	 * POST /team/checkin — the site is free again.
	 *
	 * @param WP_REST_Request $request The request.
	 * @return WP_REST_Response
	 */
	public static function checkin( WP_REST_Request $request ) {
		$who     = sanitize_text_field( (string) $request->get_param( 'who' ) );
		$current = self::get_checkout();

		if ( $current && ! self::same_person( $current['who'], $who ) && ! $request->get_param( 'force' ) ) {
			return new WP_REST_Response(
				array(
					'error'    => 'checked_out',
					'message'  => 'Someone else is working on this website.',
					'checkout' => $current,
				),
				409
			);
		}

		delete_option( self::OPT_CHECKOUT );
		return new WP_REST_Response( self::info(), 200 );
	}

	/**
	 * POST /team/github — save (or clear) the site's GitHub repository.
	 *
	 * @param WP_REST_Request $request The request.
	 * @return WP_REST_Response
	 */
	public static function github( WP_REST_Request $request ) {
		$saved = self::set_github_repo( (string) $request->get_param( 'repo' ) );
		if ( is_wp_error( $saved ) ) {
			return new WP_REST_Response( array( 'message' => $saved->get_error_message() ), 400 );
		}
		return new WP_REST_Response( self::info(), 200 );
	}

	/**
	 * POST /team/rotate-key — replace the connection code and return the new
	 * one. When a teammate stops having a website shared with them, the app
	 * calls this so the code they hold stops working, and hands the new code
	 * to everyone who still has the site. Answered with the old code, so only
	 * someone who already has access can do it. A code pinned in wp-config.php
	 * (WPUSHER_API_KEY) can't be changed from here, and says so.
	 *
	 * @return WP_REST_Response
	 */
	public static function rotate_key() {
		if ( WPusher_Security::is_api_key_locked() ) {
			return new WP_REST_Response(
				array(
					'error'   => 'locked',
					'message' => 'This website\'s connection code is set in wp-config.php (WPUSHER_API_KEY), so it can only be changed there.',
				),
				409
			);
		}
		return new WP_REST_Response( array( 'api_key' => WPusher_Security::regenerate_api_key() ), 200 );
	}

	// ── For other code (the Brain Box) ──────────────────────────────────────

	/**
	 * Save the site's GitHub repository. Accepts "owner/name", an https or ssh
	 * GitHub URL, with or without .git; stores https://github.com/owner/name.
	 * An empty string clears it.
	 *
	 * @param string $repo Repository as typed.
	 * @return string|WP_Error The stored URL ('' when cleared), or an error.
	 */
	public static function set_github_repo( $repo ) {
		$repo = trim( $repo );
		if ( '' === $repo ) {
			delete_option( self::OPT_GITHUB );
			return '';
		}
		$url = self::normalize_github( $repo );
		if ( ! $url ) {
			return new WP_Error( 'bad_repo', 'That doesn\'t look like a GitHub repository. Use github.com/owner/name.' );
		}
		update_option( self::OPT_GITHUB, $url, false );
		return $url;
	}

	/**
	 * The stored repository URL, or ''.
	 *
	 * @return string
	 */
	public static function get_github_repo() {
		return (string) get_option( self::OPT_GITHUB, '' );
	}

	/**
	 * The current check-out, or null when the site is free.
	 *
	 * @return array|null
	 */
	public static function get_checkout() {
		$c = get_option( self::OPT_CHECKOUT, null );
		return is_array( $c ) && ! empty( $c['who'] ) ? $c : null;
	}

	/**
	 * The GitHub repository this site's own folder points at, if it is a git
	 * checkout: normally only on the copy a site is built on. Looks from the
	 * active theme outwards, so a theme with its own repository wins over one
	 * for the whole site folder. Reads .git/config; never runs git.
	 *
	 * @return string https://github.com/owner/name, or ''.
	 */
	public static function detect_local_repo() {
		// The real folder: on Local the theme is often a symlink into a repository
		// kept somewhere else, and its own parents are the site, not the repo.
		$dir = realpath( get_stylesheet_directory() );
		for ( $i = 0; $i < 6 && $dir && dirname( $dir ) !== $dir; $i++, $dir = dirname( $dir ) ) {
			$git = $dir . '/.git';
			if ( is_file( $git ) ) {
				// A worktree or submodule: ".git" is a file saying where the real one is.
				$line = (string) file_get_contents( $git ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
				if ( ! preg_match( '/^gitdir:\s*(.+)$/m', $line, $m ) ) {
					continue;
				}
				$git = trim( $m[1] );
				$git = preg_match( '#^(/|[A-Za-z]:)#', $git ) ? $git : $dir . '/' . $git;
				// A worktree's own folder has no config; the shared one is two up.
				if ( ! is_file( $git . '/config' ) && is_file( dirname( $git, 2 ) . '/config' ) ) {
					$git = dirname( $git, 2 );
				}
			}
			if ( ! is_file( $git . '/config' ) ) {
				continue;
			}
			$config = (string) file_get_contents( $git . '/config' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			if ( preg_match( '/\[remote "origin"\][^\[]*?^\s*url\s*=\s*(\S+)/ms', $config, $m ) ) {
				return (string) self::normalize_github( $m[1] );
			}
			return ''; // the nearest repository has no GitHub remote; don't look past it
		}
		return '';
	}

	/**
	 * owner/name, https://github.com/owner/name(.git), git@github.com:owner/name(.git)
	 * → https://github.com/owner/name. Anything else → null.
	 *
	 * @param string $repo Input.
	 * @return string|null
	 */
	public static function normalize_github( $repo ) {
		$repo = trim( $repo );
		$pats = array(
			'#^(?:https?://)?(?:www\.)?github\.com/([A-Za-z0-9-]+)/([A-Za-z0-9._-]+?)(?:\.git)?/?$#',
			'#^git@github\.com:([A-Za-z0-9-]+)/([A-Za-z0-9._-]+?)(?:\.git)?$#',
			'#^([A-Za-z0-9-]+)/([A-Za-z0-9._-]+?)(?:\.git)?$#',
		);
		foreach ( $pats as $p ) {
			if ( preg_match( $p, $repo, $m ) ) {
				return 'https://github.com/' . $m[1] . '/' . $m[2];
			}
		}
		return null;
	}

	/**
	 * Teammates are identified by their WebsitePusher sign-in email.
	 *
	 * @param string $a One.
	 * @param string $b Other.
	 * @return bool
	 */
	private static function same_person( $a, $b ) {
		return strtolower( trim( $a ) ) === strtolower( trim( $b ) );
	}
}
