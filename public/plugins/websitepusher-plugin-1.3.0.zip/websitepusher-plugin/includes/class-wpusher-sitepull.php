<?php
/**
 * WPusher_SitePull
 *
 * Full-site pull: everything a teammate needs to rebuild this website on their
 * own machine. The app drives it in small requests so no single call has to
 * package a whole site before shared hosting times it out:
 *
 *   GET  /site/manifest   what is here: versions, URLs, table list and sizes
 *   GET  /site/files      every file under wp-content, with size and mtime
 *   POST /site/files-zip  a ZIP of the paths asked for (the app batches them)
 *   GET  /site/db-table   one chunk of one table as SQL, URLs already swapped
 *
 * Same X-WPusher-API-Key as every other route. That key can already deploy PHP
 * into the theme, so reading the database doesn't widen what it can do.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPusher_SitePull {

	/**
	 * Folders under wp-content that are never worth copying: caches, backup
	 * archives (often bigger than the site) and our own push backups.
	 */
	const SKIP_DIRS = array(
		'cache', 'upgrade', 'upgrade-temp-backup', 'ai1wm-backups', 'updraft',
		'backups-dup-lite', 'backups-dup-pro', 'backup-db', 'backupwordpress',
		'wflogs', 'et-cache', 'litespeed', 'w3tc-config', 'wpvivid_staging',
		'uploads/websitepusher-backups', 'uploads/wpforms/cache', 'uploads/cache',
		'uploads/backwpup', 'uploads/sucuri', 'uploads/wp-file-manager-pro/fm_backup',
	);

	/**
	 * Host-specific code that breaks a site anywhere but on that host: cache
	 * drop-ins wired to the host's object cache, and the host's own mu-plugins.
	 */
	const SKIP_FILES = array(
		'object-cache.php', 'advanced-cache.php', 'db.php', 'db-error.php',
		'mu-plugins/mu-plugin.php', 'mu-plugins/wpengine-common', 'mu-plugins/wpe-',
		'mu-plugins/kinsta-mu-plugins', 'mu-plugins/sso.php',
		'mu-plugins/wpcomsh', 'mu-plugins/wpcomsh-loader.php',
		'mu-plugins/0-worker.php', 'mu-plugins/endurance-', 'mu-plugins/sg-',
		'mu-plugins/pantheon', 'mu-plugins/wp-stack-cache.php', 'mu-plugins/flywheel',
	);

	/**
	 * Tables whose rows are logs or caches: the table is created locally but
	 * comes down empty. Matched against the name with the prefix removed.
	 */
	const SKIP_DATA = array(
		'/^wf/i', '/^actionscheduler_logs$/', '/^redirection_404$/', '/^wsal_/',
		'/^simple_history/', '/^itsec_log/', '/^aiowps_/', '/^wc_sessions$/',
		'/^woocommerce_sessions$/', '/^litespeed_/', '/^ewwwio_images$/',
	);

	/** Upper bound on one /files-zip request, so it finishes inside a host timeout. */
	const ZIP_MAX_BYTES = 64 * 1024 * 1024;

	/**
	 * Register the routes. Called from WPusher_API::register_routes().
	 *
	 * @param string   $ns   REST namespace.
	 * @param callable $auth Permission callback.
	 */
	public static function register_routes( $ns, $auth ) {
		register_rest_route( $ns, '/site/manifest',  array( 'methods' => 'GET',  'callback' => array( __CLASS__, 'manifest' ),  'permission_callback' => $auth ) );
		register_rest_route( $ns, '/site/files',     array( 'methods' => 'GET',  'callback' => array( __CLASS__, 'files' ),     'permission_callback' => $auth ) );
		register_rest_route( $ns, '/site/files-zip', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'files_zip' ), 'permission_callback' => $auth ) );
		register_rest_route( $ns, '/site/db-table',  array( 'methods' => 'GET',  'callback' => array( __CLASS__, 'db_table' ),  'permission_callback' => $auth ) );
	}

	// ── Manifest ────────────────────────────────────────────────────────────

	/**
	 * GET /site/manifest — enough for the app to plan the pull and to tell the
	 * person how big it is before anything downloads.
	 *
	 * @return WP_REST_Response
	 */
	public static function manifest() {
		global $wpdb;

		$tables = array();
		$rows   = $wpdb->get_results( $wpdb->prepare( 'SHOW TABLE STATUS WHERE Name LIKE %s', $wpdb->esc_like( $wpdb->prefix ) . '%' ), ARRAY_A );
		foreach ( (array) $rows as $r ) {
			$tables[] = array(
				'name'      => $r['Name'],
				'rows'      => (int) $r['Rows'],
				'bytes'     => (int) $r['Data_length'] + (int) $r['Index_length'],
				'skip_data' => self::skip_data( $r['Name'] ),
			);
		}

		return new WP_REST_Response(
			array(
				'plugin_version' => WPUSHER_VERSION,
				'wp_version'     => get_bloginfo( 'version' ),
				'php_version'    => PHP_VERSION,
				'db_version'     => $wpdb->db_version(),
				'db_server'      => $wpdb->get_var( 'SELECT VERSION()' ),
				'table_prefix'   => $wpdb->prefix,
				'home'           => get_option( 'home' ),
				'siteurl'        => get_option( 'siteurl' ),
				'multisite'      => is_multisite(),
				'stylesheet'     => get_stylesheet(),
				'template'       => get_template(),
				'active_plugins' => array_values( (array) get_option( 'active_plugins', array() ) ),
				'tables'         => $tables,
			),
			200
		);
	}

	// ── Files ───────────────────────────────────────────────────────────────

	/**
	 * GET /site/files — every pullable file under wp-content. The app compares
	 * size and mtime with its own copy, so a second pull only fetches what moved.
	 *
	 * @return WP_REST_Response
	 */
	public static function files() {
		@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		$base  = self::content_root();
		$files = array();
		$bytes = 0;

		$dir_it = new RecursiveDirectoryIterator( $base, FilesystemIterator::SKIP_DOTS );
		$filter = new RecursiveCallbackFilterIterator(
			$dir_it,
			function ( $current ) use ( $base ) {
				$rel = self::rel( $base, $current->getPathname() );
				if ( self::is_skipped( $rel ) ) {
					return false;
				}
				// A symlink out of wp-content is the host's shared code, not this site's.
				if ( $current->isLink() ) {
					$real = realpath( $current->getPathname() );
					if ( ! $real || ! str_starts_with( $real, $base . '/' ) ) {
						return false;
					}
				}
				return true;
			}
		);

		foreach ( new RecursiveIteratorIterator( $filter ) as $file ) {
			if ( ! $file->isFile() || ! $file->isReadable() ) {
				continue;
			}
			$size    = $file->getSize();
			$files[] = array( self::rel( $base, $file->getPathname() ), $size, $file->getMTime() );
			$bytes  += $size;
		}

		return new WP_REST_Response(
			array(
				'count' => count( $files ),
				'bytes' => $bytes,
				// Compact rows ([path, size, mtime]) — a big site has 50k+ files.
				'files' => $files,
			),
			200
		);
	}

	/**
	 * POST /site/files-zip — stream a ZIP of the requested wp-content paths.
	 * Body: { "paths": ["themes/x/style.css", ...] }. Paths outside wp-content,
	 * or on the skip lists, are dropped rather than failing the batch.
	 *
	 * @param WP_REST_Request $request The request.
	 * @return WP_REST_Response|void
	 */
	public static function files_zip( WP_REST_Request $request ) {
		@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_REST_Response( array( 'message' => 'This server has no ZIP support (PHP zip extension).' ), 500 );
		}

		$paths = (array) $request->get_param( 'paths' );
		$base  = self::content_root();
		$tmp   = get_temp_dir() . 'wpusher_sitepull_' . wp_generate_password( 12, false ) . '.zip';
		$zip   = new ZipArchive();

		if ( true !== $zip->open( $tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE ) ) {
			return new WP_REST_Response( array( 'message' => 'Could not create a ZIP in the temp folder.' ), 500 );
		}

		$added = 0;
		$total = 0;
		foreach ( $paths as $rel ) {
			$rel = ltrim( str_replace( '\\', '/', (string) $rel ), '/' );
			if ( '' === $rel || str_contains( $rel, "\0" ) || self::is_skipped( $rel ) ) {
				continue;
			}
			$abs = realpath( $base . '/' . $rel );
			if ( ! $abs || ! str_starts_with( $abs, $base . '/' ) || ! is_file( $abs ) || ! is_readable( $abs ) ) {
				continue;
			}
			$size = filesize( $abs );
			// Always take at least one file, so a single huge file still comes down.
			if ( $added && $total + $size > self::ZIP_MAX_BYTES ) {
				break;
			}
			$zip->addFile( $abs, $rel );
			// Already-compressed media gains nothing from deflate; store it.
			if ( preg_match( '/\.(jpe?g|png|gif|webp|avif|mp4|mov|webm|zip|gz|woff2?|pdf|mp3)$/i', $rel ) ) {
				$zip->setCompressionName( $rel, ZipArchive::CM_STORE );
			}
			$total += $size;
			++$added;
		}

		$zip->close();

		if ( ! $added ) {
			if ( file_exists( $tmp ) ) {
				unlink( $tmp );
			}
			return new WP_REST_Response( array( 'message' => 'None of the requested files could be read.' ), 404 );
		}

		header( 'Content-Type: application/zip' );
		header( 'Content-Length: ' . filesize( $tmp ) );
		header( 'X-WPusher-Files: ' . $added );
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		readfile( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
		unlink( $tmp );
		exit;
	}

	// ── Database ────────────────────────────────────────────────────────────

	/**
	 * GET /site/db-table?table=wp_posts&cursor=&limit=500&from[]=…&to[]=…
	 *
	 * One chunk of one table as plain SQL, one statement per line. The first
	 * chunk (empty cursor) also carries DROP + CREATE. Rows walk by primary key
	 * where there is a single-column one, so chunk 400 costs the same as chunk 1;
	 * other tables fall back to LIMIT/OFFSET. Every from[i] string in a value is
	 * swapped for to[i], serialized data included, so the SQL imports as-is.
	 *
	 * Response headers: X-WPusher-Next-Cursor (empty when the table is done)
	 * and X-WPusher-Rows (rows in this chunk).
	 *
	 * @param WP_REST_Request $request The request.
	 * @return WP_REST_Response|void
	 */
	public static function db_table( WP_REST_Request $request ) {
		global $wpdb;
		@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		$table = (string) $request->get_param( 'table' );
		$known = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $wpdb->prefix ) . '%' ) );
		if ( ! in_array( $table, $known, true ) ) {
			return new WP_REST_Response( array( 'message' => 'Unknown table.' ), 404 );
		}

		$chunk = self::table_sql(
			$table,
			(string) $request->get_param( 'cursor' ),
			max( 1, min( 5000, (int) ( $request->get_param( 'limit' ) ?: 500 ) ) ),
			self::replace_pairs(
				array_values( array_map( 'strval', (array) $request->get_param( 'from' ) ) ),
				array_values( array_map( 'strval', (array) $request->get_param( 'to' ) ) )
			)
		);

		header( 'Content-Type: application/sql; charset=utf-8' );
		header( 'X-WPusher-Next-Cursor: ' . $chunk['next'] );
		header( 'X-WPusher-Rows: ' . $chunk['rows'] );
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		echo $chunk['sql']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	/**
	 * Build one chunk of a table's SQL. Kept apart from the HTTP handler so it
	 * can be exercised without a request.
	 *
	 * @param string               $table  Table name (already checked to exist).
	 * @param string               $cursor '' for the first chunk.
	 * @param int                  $limit  Rows per chunk.
	 * @param array<string,string> $pairs  From → to, from replace_pairs().
	 * @return array{sql:string,next:string,rows:int}
	 */
	public static function table_sql( $table, $cursor, $limit, array $pairs ) {
		global $wpdb;

		$q_table = '`' . str_replace( '`', '``', $table ) . '`';

		$columns = $wpdb->get_results( "SHOW COLUMNS FROM {$q_table}", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$binary  = array();
		$pk      = array();
		foreach ( $columns as $i => $c ) {
			if ( preg_match( '/blob|binary/i', $c['Type'] ) ) {
				$binary[ $i ] = true;
			}
			if ( 'PRI' === $c['Key'] ) {
				$pk[] = array( 'name' => $c['Field'], 'numeric' => (bool) preg_match( '/int/i', $c['Type'] ) );
			}
		}
		$keyset = 1 === count( $pk ) && $pk[0]['numeric'];

		$out = array();
		if ( '' === $cursor ) {
			$create = $wpdb->get_row( "SHOW CREATE TABLE {$q_table}", ARRAY_N ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$out[]  = "DROP TABLE IF EXISTS {$q_table};";
			$out[]  = str_replace( array( "\r", "\n" ), ' ', $create[1] ) . ';';
		}

		$rows = array();
		if ( ! self::skip_data( $table ) ) {
			if ( $keyset ) {
				$q_pk  = '`' . str_replace( '`', '``', $pk[0]['name'] ) . '`';
				$after = '' === $cursor ? null : (int) $cursor;
				$sql   = null === $after
					? "SELECT * FROM {$q_table} ORDER BY {$q_pk} LIMIT %d"
					: "SELECT * FROM {$q_table} WHERE {$q_pk} > %d ORDER BY {$q_pk} LIMIT %d";
				$rows  = null === $after
					? $wpdb->get_results( $wpdb->prepare( $sql, $limit ), ARRAY_N ) // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
					: $wpdb->get_results( $wpdb->prepare( $sql, $after, $limit ), ARRAY_N ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			} else {
				$offset = (int) $cursor;
				$rows   = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$q_table} LIMIT %d OFFSET %d", $limit, $offset ), ARRAY_N ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			}
		}

		if ( $rows ) {
			$cols  = implode( ',', array_map( fn( $c ) => '`' . str_replace( '`', '``', $c['Field'] ) . '`', $columns ) );
			$batch = array();
			foreach ( $rows as $row ) {
				$vals = array();
				foreach ( $row as $i => $v ) {
					if ( null === $v ) {
						$vals[] = 'NULL';
					} elseif ( isset( $binary[ $i ] ) ) {
						$vals[] = '' === $v ? "''" : '0x' . bin2hex( $v );
					} else {
						$vals[] = "'" . self::esc( $pairs ? self::replace_value( $v, $pairs ) : $v ) . "'";
					}
				}
				$batch[] = '(' . implode( ',', $vals ) . ')';
				// Keep each INSERT well under a default max_allowed_packet.
				if ( count( $batch ) >= 50 ) {
					$out[] = "INSERT INTO {$q_table} ({$cols}) VALUES " . implode( ',', $batch ) . ';';
					$batch = array();
				}
			}
			if ( $batch ) {
				$out[] = "INSERT INTO {$q_table} ({$cols}) VALUES " . implode( ',', $batch ) . ';';
			}
		}

		$next = '';
		if ( count( $rows ) === $limit ) {
			if ( $keyset ) {
				$pk_index = array_search( $pk[0]['name'], array_column( $columns, 'Field' ), true );
				$next     = (string) $rows[ count( $rows ) - 1 ][ $pk_index ];
			} else {
				$next = (string) ( (int) $cursor + $limit );
			}
		}

		return array(
			'sql'  => $out ? implode( "\n", $out ) . "\n" : '',
			'next' => $next,
			'rows' => count( $rows ),
		);
	}

	// ── URL replacement ─────────────────────────────────────────────────────

	/**
	 * Expand each from→to into the forms a URL takes inside the database:
	 * as written, JSON-escaped (Elementor and blocks store "https:\/\/…"), and
	 * URL-encoded. Longest first, so https://a.com/x wins over https://a.com.
	 *
	 * @param string[] $from Strings to find.
	 * @param string[] $to   Replacements, same order.
	 * @return array<string,string>
	 */
	public static function replace_pairs( array $from, array $to ) {
		$pairs = array();
		foreach ( $from as $i => $f ) {
			if ( '' === $f || ! isset( $to[ $i ] ) || $f === $to[ $i ] ) {
				continue;
			}
			$t                                  = $to[ $i ];
			$pairs[ $f ]                        = $t;
			$pairs[ str_replace( '/', '\/', $f ) ] = str_replace( '/', '\/', $t );
			$pairs[ rawurlencode( $f ) ]        = rawurlencode( $t );
		}
		uksort( $pairs, fn( $a, $b ) => strlen( $b ) - strlen( $a ) );
		return $pairs;
	}

	/**
	 * Swap strings in one column value. Serialized PHP is rewritten token by
	 * token so every s:N: length stays right, and nothing is unserialized,
	 * which means objects of classes this request never loaded survive intact.
	 *
	 * @param string               $value Column value.
	 * @param array<string,string> $pairs From → to.
	 * @return string
	 */
	public static function replace_value( $value, array $pairs ) {
		$hit = false;
		foreach ( $pairs as $f => $t ) {
			if ( str_contains( $value, $f ) ) {
				$hit = true;
				break;
			}
		}
		if ( ! $hit ) {
			return $value;
		}
		if ( is_serialized( $value ) ) {
			$fixed = self::replace_serialized( $value, $pairs );
			if ( null !== $fixed ) {
				return $fixed;
			}
		}
		return strtr( $value, $pairs );
	}

	/**
	 * Walk a serialized string, replacing inside string tokens and recomputing
	 * their lengths. Strings that are themselves serialized (double-serialized
	 * options are common) are handled recursively. Returns null if the data
	 * doesn't parse, so the caller can fall back to a plain swap.
	 *
	 * @param string               $s     Serialized data.
	 * @param array<string,string> $pairs From → to.
	 * @return string|null
	 */
	private static function replace_serialized( $s, array $pairs ) {
		$out = '';
		$len = strlen( $s );
		$i   = 0;
		while ( $i < $len ) {
			$c = $s[ $i ];
			if ( ( 's' === $c || 'O' === $c || 'C' === $c ) && preg_match( '/\G[sOC]:(\d+):"/', $s, $m, 0, $i ) ) {
				$n     = (int) $m[1];
				$start = $i + strlen( $m[0] );
				if ( $start + $n + 1 > $len || '"' !== $s[ $start + $n ] ) {
					return null;
				}
				$str = substr( $s, $start, $n );
				if ( 's' === $c ) {
					$str  = self::replace_value( $str, $pairs );
					$out .= 's:' . strlen( $str ) . ':"' . $str . '"';
				} else {
					// Class name: copy as-is.
					$out .= $m[0] . $str . '"';
				}
				$i = $start + $n + 1;
				continue;
			}
			$out .= $c;
			++$i;
		}
		return $out;
	}

	// ── Helpers ─────────────────────────────────────────────────────────────

	/**
	 * Escape a value for a single-quoted MySQL string literal.
	 *
	 * @param string $v Value.
	 * @return string
	 */
	private static function esc( $v ) {
		return strtr(
			$v,
			array(
				'\\'   => '\\\\',
				"\0"   => '\\0',
				"\n"   => '\\n',
				"\r"   => '\\r',
				"'"    => "\\'",
				'"'    => '\\"',
				"\x1a" => '\\Z',
			)
		);
	}

	/**
	 * Whether a table's rows are left behind (logs, sessions, caches).
	 *
	 * @param string $table Full table name.
	 * @return bool
	 */
	private static function skip_data( $table ) {
		global $wpdb;
		$bare = str_starts_with( $table, $wpdb->prefix ) ? substr( $table, strlen( $wpdb->prefix ) ) : $table;
		foreach ( self::SKIP_DATA as $re ) {
			if ( preg_match( $re, $bare ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Real path of wp-content, without a trailing slash.
	 *
	 * @return string
	 */
	private static function content_root() {
		return untrailingslashit( str_replace( '\\', '/', realpath( WP_CONTENT_DIR ) ) );
	}

	/**
	 * Path relative to wp-content, forward slashes.
	 *
	 * @param string $base wp-content real path.
	 * @param string $abs  Absolute path.
	 * @return string
	 */
	private static function rel( $base, $abs ) {
		return ltrim( substr( str_replace( '\\', '/', $abs ), strlen( $base ) ), '/' );
	}

	/**
	 * Whether a wp-content-relative path is on a skip list.
	 *
	 * @param string $rel Relative path.
	 * @return bool
	 */
	private static function is_skipped( $rel ) {
		foreach ( self::SKIP_DIRS as $d ) {
			if ( $rel === $d || str_starts_with( $rel, $d . '/' ) ) {
				return true;
			}
		}
		foreach ( self::SKIP_FILES as $f ) {
			if ( str_starts_with( $rel, $f ) ) {
				return true;
			}
		}
		return false;
	}
}
