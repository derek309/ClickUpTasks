=== WebsitePusher ===
Contributors: websitepusher
Tags: deploy, local development, theme, workflow, backup
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 1.0.0
Requires PHP: 8.0
License: GPL-2.0-or-later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Push your local WordPress changes live safely — automatic backups, instant undo, and plain-English controls built for non-developers.

== Description ==

You built your website locally. Now how do you get it live without breaking anything?

WebsitePusher is the easiest way to deploy your locally-built WordPress website to your live site. It's built for non-developers — people who use Local WP, MAMP, or similar tools to build their WordPress sites, then need a simple, safe way to push those changes online.

**No FTP. No file managers. No manually uploading files. Just click Go Live.**

= How it works =

1. Install this plugin on your live WordPress website
2. Download the free WebsitePusher desktop app for Mac at websitepusher.com
3. Connect your local site to your live site in a few clicks
4. Make changes locally — when you're ready, click Go Live

= Every time you Go Live, WebsitePusher automatically: =

* Creates a full backup of your live theme before touching anything
* Validates every file for security threats before deploying
* Runs a health check on your site after deployment
* Auto-rolls back if a PHP error or site failure is detected

**If anything looks wrong, one click undoes the entire update.**

= Features =

* Works with any WordPress host — SiteGround, Kinsta, WP Engine, Bluehost, Namecheap, GoDaddy, Flywheel, and more
* Staging site support — push to staging first, review, then go live with a toggle
* The whole app changes color so you always know if you're on staging (amber) or live (green)
* No database changes — only deploys theme and plugin files
* Plain English throughout — no technical jargon
* Automatic safety copy before every deploy
* Instant undo — restores your previous version with one click
* Deployment notes — add a note to each update so you remember what changed
* Deployment history — see every update with timestamps
* Works with child themes — auto-detects your active theme
* Built-in connection code authentication — timing-safe, cryptographically secure

= Who is this for? =

WebsitePusher is built for:

* Non-developers building their own WordPress sites locally
* Freelancers and small agencies who use Local WP to build client sites
* Anyone using AI tools like Claude Code or Cursor to build WordPress themes
* Anyone who has ever thought "I built something great locally — how do I get it online safely?"

= Getting Started =

**Step 1 — Install this plugin on your live website**

In your WordPress admin go to Plugins → Add New → Upload Plugin. Upload the WebsitePusher plugin ZIP and click Activate.

**Step 2 — Copy your connection details**

Go to WebsitePusher in your WordPress left menu. You'll see:

* Your website address — copy this
* Your connection code — copy this (click Show to reveal it)

**Step 3 — Download the desktop app**

Download the free WebsitePusher app for Mac from websitepusher.com. Open it and follow the setup steps — it will ask for your website address and connection code.

**Step 4 — Select your local website folder**

In the desktop app, browse to the wp-content folder inside your local WordPress site. WebsitePusher automatically finds your active theme.

**Step 5 — You're ready**

The desktop app will show you how many files have changed since your last update. Add an optional note about what you changed, then click Go Live.

= Going Live — Step by Step =

1. Make your changes in Local WP using Claude Code, Cursor, or any editor
2. Open WebsitePusher — it automatically detects what files changed
3. Review what's changing — click "See what changed" to see the full list
4. Uncheck any files you don't want to include (optional)
5. Add a note about this update — e.g. "Updated the homepage hero" (optional)
6. Click Go Live
7. WebsitePusher creates a safety copy of your current live site
8. Your changes are deployed and a health check runs automatically
9. If anything goes wrong, it auto-rolls back. If everything looks good — you're live!

= Using Staging Sites =

A staging site is a private copy of your website where you can test changes before real visitors see them. Many hosting companies offer this for free — check your hosting dashboard.

**To use staging with WebsitePusher:**

1. Install the WebsitePusher plugin on both your live site and your staging site
2. In the desktop app, edit your website and add your staging URL
3. A Staging/Live toggle appears automatically
4. When the toggle shows Staging, the whole app turns amber — you cannot accidentally push to your live site
5. Push to staging, review your changes, then switch to Live and push again

= Undoing an Update =

If something doesn't look right after you go live:

1. In the desktop app, click "Undo last update" in the recent updates section
2. Or in WordPress go to WebsitePusher in your menu — click "Undo last update"
3. Your website is instantly restored to the previous version

= Troubleshooting =

**Can't connect to my website**

* Check your website address starts with https://
* Make sure your connection code is copied correctly from WordPress → WebsitePusher
* Make sure the WebsitePusher plugin is active in WordPress
* Try the "Test connection" button in the desktop app's site settings

**Go Live failed**

* Check your website is online and accessible
* Make sure the WebsitePusher plugin is still active in WordPress
* Your website was NOT changed — WebsitePusher only deploys after passing all checks

**Showing too many changes**

* If you see hundreds of unexpected files, click "See what changed" then "Mark everything as up to date"
* This resets the baseline — WebsitePusher will only track new changes from that point

**Need more help?**

Email us at support@websitepusher.com — we respond to every message.

== Installation ==

= Automatic Installation =

1. Go to your WordPress admin → Plugins → Add New
2. Search for "WebsitePusher"
3. Click Install Now, then Activate
4. Go to WebsitePusher in your WordPress left menu

= Manual Installation =

1. Download the WebsitePusher plugin ZIP
2. Go to your WordPress admin → Plugins → Add New → Upload Plugin
3. Upload the ZIP file and click Install Now
4. Click Activate Plugin
5. Go to WebsitePusher in your WordPress left menu

= After Installation =

1. Copy your website address and connection code from the WebsitePusher page
2. Download the WebsitePusher desktop app at websitepusher.com
3. Open the app and follow the guided setup

== Frequently Asked Questions ==

= Does this work with my host? =

Yes. WebsitePusher works with any WordPress host — SiteGround, Kinsta, WP Engine, Bluehost, Flywheel, Namecheap, GoDaddy, Cloudways, DigitalOcean, and more. As long as WordPress is installed and the plugin is active, it works.

= Do I need to know how to code? =

No. WebsitePusher is built specifically for non-developers. Everything is in plain English. You don't need to know what FTP is, what a terminal is, or anything technical.

= Will it change my database or content? =

No. WebsitePusher only deploys files — your theme, plugins, and optionally media uploads. It never touches your WordPress database, posts, pages, settings, or users.

= What happens if something goes wrong after I push? =

Before every update, WebsitePusher creates a full backup of your live theme. After deploying, it runs a health check on your site homepage. If it detects a PHP fatal error or site failure, it automatically restores the backup. You can also manually undo the last update with one click from either the desktop app or the WordPress plugin page.

= Do I need the desktop app? =

Yes. The WordPress plugin is the bridge between the desktop app and your live site — it receives and validates deployments on the server side. The desktop app is what you use on your Mac to detect local changes and push them live. The desktop app is free at websitepusher.com.

= Does it support staging sites? =

Yes. Install the plugin on both your live and staging WordPress installations. In the desktop app you can add both URLs and use the toggle to switch between them. The whole app changes color — amber for staging, green for live — so you always know which environment you're pushing to.

= Is my connection code secure? =

Yes. Your connection code is a 48-character cryptographically random string, stored securely in your WordPress database. All API calls are authenticated using timing-safe comparison (hash_equals) to prevent timing attacks. The connection code is never exposed in URLs.

= What files does it deploy? =

By default, WebsitePusher deploys your active theme files. You can also enable deployment of custom plugins in the desktop app settings. It never deploys WordPress core files, wp-config.php, or anything outside wp-content.

= Does it work with child themes? =

Yes. WebsitePusher automatically detects if you're using a child theme and deploys accordingly.

= Does it work with WordPress Multisite? =

Not currently. Multisite support is on the roadmap.

= What PHP version do I need? =

PHP 8.0 or higher. Most hosts run PHP 8.0+ by default. You can check your PHP version in WordPress → Tools → Site Health.

= Where are my backups stored? =

Backups are stored in a protected folder inside your WordPress uploads directory. The folder has an .htaccess file that blocks direct web access. You can control how many backups to keep in the Advanced Settings on the WebsitePusher plugin page.

= Is the plugin free? =

Yes, the plugin is completely free. The desktop app has a free tier (1 website) and paid plans for more websites at websitepusher.com.

= I need help — how do I contact support? =

Email us at support@websitepusher.com — we respond to every message. You can also visit websitepusher.com for documentation and guides.

== Screenshots ==

1. The WebsitePusher plugin page in WordPress — your website address and connection code are right there, ready to copy into the desktop app
2. The WebsitePusher desktop app — showing changes ready to go live with a note field and the Go Live button
3. The staging/live toggle — the whole app turns amber for staging and green for live so you always know which environment you're in
4. The site dropdown — each site shows its environment with full color coding
5. The undo card — appears after a successful deploy so you can restore your previous version with one click

== Changelog ==

= 1.3.0 =
* Shows who on your team is working on this website, so two people don't change the same site at once. The WebsitePusher app checks a site out when someone starts and frees it when they're done.
* Remembers where the website's code lives on GitHub, so every teammate's app can find it.
* When a website stops being shared with a teammate, the app can give it a new connection code, so the old one stops working.

= 1.2.0 =
* Full-site pull: the app can now copy the whole website down, database included, so a teammate can set up a working local copy in one step. Website addresses in the database are switched to the local address on the way, without breaking saved settings.
* Caches, backup archives and hosting-company code are left out of a full-site pull, and log tables come down empty.

= 1.1.8 =
* The menu icon shows in its own blue, green and white again. WordPress was repainting it in one colour, which left a blank square.

= 1.1.7 =
* Updates itself: from this version on, new versions show on the Plugins screen and install with one click, like a plugin from the WordPress directory.
* Works beside the ClickUpLocal Brain Box, which now carries this same receiver: on a Brain Box site this plugin takes over when active, and deleting it keeps the connection code, history and backups the Brain Box's copy shares.
* Every text size on the settings page is 16px or larger, and messages use a colon where they had a dash.

= 1.1.6 =
* New read-only endpoint so the app and Claude can show what a deploy would
  actually change, line by line, instead of just listing file names
* Reads are confined to the same folder a deploy writes to; binary and
  oversized files return a signature only
* New read-only endpoint that reports a signature for every file the site
  currently holds, so the app can warn you before a push would overwrite a
  change somebody else made since you last synced
* Deploy records now name who ran the deploy, so a site shared by several
  people has one log that says who did what

= 1.0.0 =
* Initial release
* Three-step setup — copy your website address, copy your connection code, download the app
* Automatic backup before every deploy
* File-by-file security validation (path traversal, extension filtering, MIME type checks)
* Health check and auto-rollback on failure
* Staging and live site support via the desktop app toggle
* Plain-English admin page
* Timing-safe connection code authentication
* Deployment history stored in WordPress
* One-click undo from the plugin page or desktop app
* Backwards compatible with older app versions

== Upgrade Notice ==

= 1.0.0 =
Initial release — no upgrade needed.

== Important Notes ==

**Use at your own risk.** WebsitePusher creates automatic safety copies before every update and runs a health check after every deployment. However, you are solely responsible for your website and its content. We are not liable for any data loss, website downtime, or damage that may occur. Always maintain your own independent backups through your hosting provider in addition to WebsitePusher's automatic safety copies.

== Support ==

For help, documentation, and guides visit websitepusher.com.

To report a bug or get direct support, email support@websitepusher.com.
