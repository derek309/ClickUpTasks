<?php
/**
 * Plugin Name:       WebsitePusher
 * Plugin URI:        https://websitepusher.com
 * Description:       Push your local WordPress changes to your live site safely. Automatic backups before every update, instant undo, and plain-English controls built for non-developers.
 * Version:           1.3.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            WebsitePusher
 * Author URI:        https://websitepusher.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       websitepusher
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// The ClickUpLocal Brain Box plugin carries this same receiver. On a site where
// it has already loaded it (the request that activates this plugin, the only
// time both are in play), stand aside rather than declare its classes twice.
// From the next request this plugin loads first and the Brain Box's copy steps
// down instead.
if ( defined( 'WPUSHER_VERSION' ) ) {
	return;
}

define( 'WPUSHER_VERSION',     '1.3.0' );
define( 'WPUSHER_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'WPUSHER_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'WPUSHER_PLUGIN_FILE', __FILE__ );

require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-security.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-backup.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-history.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-deployer.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-admin.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-api.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-sitepull.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-team.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-cul-updater.php';

// Updates from the Plugins screen, the same as a directory plugin, so a new
// version reaches every site on its own instead of a zip uploaded by hand per
// site (Derek, 2026-10-07: every site was stuck on an older version). The
// Brain Box's built-in copy never reaches this line: it has its own updates.
CUL_Updater::boot( array(
	'slug'     => 'websitepusher-plugin',
	'file'     => __FILE__,
	'version'  => WPUSHER_VERSION,
	'manifest' => 'https://clickuptasks.vercel.app/plugins/websitepusher-plugin.json',
) );

/**
 * Initialize the plugin after all plugins are loaded.
 */
function wpusher_init() {
	WPusher_Admin::get_instance();
	WPusher_API::get_instance();
}
add_action( 'plugins_loaded', 'wpusher_init' );

/**
 * Plugin activation.
 */
function wpusher_activate() {
	if ( ! get_option( 'wpusher_api_key' ) ) {
		update_option( 'wpusher_api_key', wp_generate_password( 48, false ) );
	}
	if ( ! get_option( 'wpusher_backup_retention' ) ) {
		update_option( 'wpusher_backup_retention', 10 );
	}
	WPusher_Backup::ensure_backup_directory();
}
register_activation_hook( __FILE__, 'wpusher_activate' );
