<?php
/**
 * Plugin Name:       WebsitePusher
 * Plugin URI:        https://websitepusher.com
 * Description:       Push your local WordPress changes to your live site safely. Automatic backups before every update, instant undo, and plain-English controls built for non-developers.
 * Version:           1.6.2
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            WebsitePusher
 * Author URI:        https://websitepusher.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       websitepusher
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// The ClickUpLocal Brain Box plugin carries this same receiver. On a site where
// it has already loaded it (the request that activates this plugin, the only
// time both are in play), stand aside rather than declare its classes twice.
// From the next request this plugin loads first and the Brain Box's copy steps
// down instead.
if ( defined( 'WPUSHER_VERSION' ) ) {
	return;
}

define( 'WPUSHER_VERSION',     '1.6.2' );
define( 'WPUSHER_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'WPUSHER_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'WPUSHER_PLUGIN_FILE', __FILE__ );

require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-security.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-backup.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-history.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-deployer.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-admin.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-api.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-sitepull.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-team.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-content.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-wpusher-release.php';
require_once WPUSHER_PLUGIN_DIR . 'includes/class-cul-updater.php';

// Updates from the Plugins screen, the same as a directory plugin, so a new
// version reaches every site on its own instead of a zip uploaded by hand per
// site (Derek, 2026-10-07: every site was stuck on an older version). The
// Brain Box's built-in copy never reaches this line: it has its own updates.
CUL_Updater::boot( array(
	'slug'     => 'websitepusher-plugin',
	'file'     => __FILE__,
	'version'  => WPUSHER_VERSION,
	'manifest' => 'https://clickuptasks.vercel.app/plugins/websitepusher-plugin.json',
) );

/**
 * Whether this is a copy of a live site that the app pulled onto a computer.
 *
 * The app marks it (wpusher_pulled_copy) after importing the live database,
 * which carries the live site's keys and its queued posts and blasts. The mark
 * names the address it was pulled to and counts only there, so a copy that is
 * later moved to a real host with a migration plugin doesn't silence that site.
 */
function wpusher_is_pulled_copy() {
	$mark = json_decode( (string) get_option( 'wpusher_pulled_copy', '' ), true );
	if ( ! is_array( $mark ) || empty( $mark['home'] ) ) {
		return false;
	}
	$here = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	return '' !== $here && strtolower( (string) wp_parse_url( $mark['home'], PHP_URL_HOST ) ) === $here;
}

// The app also turns WordPress's scheduled jobs off in wp-config.php. This is
// for a copy where it couldn't: page loads on it must not run the live site's
// due jobs. Early enough, because WordPress checks it on wp_loaded.
if ( wpusher_is_pulled_copy() && ! defined( 'DISABLE_WP_CRON' ) ) {
	define( 'DISABLE_WP_CRON', true );
}

function wpusher_pulled_copy_notice() {
	if ( ! current_user_can( 'manage_options' ) || ! wpusher_is_pulled_copy() ) {
		return;
	}
	$mark = json_decode( (string) get_option( 'wpusher_pulled_copy', '' ), true );
	$from = (string) wp_parse_url( (string) ( $mark['from'] ?? '' ), PHP_URL_HOST );
	$when = ! empty( $mark['at'] ) ? wp_date( get_option( 'date_format' ), strtotime( $mark['at'] ) ) : '';
	printf(
		'<div class="notice notice-info"><p>%s</p></div>',
		esc_html( sprintf(
			'This is a copy of %1$s, pulled by WebsitePusher%2$s. Scheduled jobs are off here, so it won\'t run the live site\'s queued posts and sends a second time.',
			$from ? $from : 'the live site',
			$when ? ' on ' . $when : ''
		) )
	);
}
add_action( 'admin_notices', 'wpusher_pulled_copy_notice' );

/**
 * Initialize the plugin after all plugins are loaded.
 */
function wpusher_init() {
	WPusher_Admin::get_instance();
	WPusher_API::get_instance();
}
add_action( 'plugins_loaded', 'wpusher_init' );

/**
 * Plugin activation.
 */
function wpusher_activate() {
	if ( ! get_option( 'wpusher_api_key' ) ) {
		update_option( 'wpusher_api_key', wp_generate_password( 48, false ) );
	}
	if ( ! get_option( 'wpusher_backup_retention' ) ) {
		update_option( 'wpusher_backup_retention', 10 );
	}
	WPusher_Backup::ensure_backup_directory();
}
register_activation_hook( __FILE__, 'wpusher_activate' );
