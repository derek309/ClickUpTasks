<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Clean, branded viewer for preview-only shares (e.g. Quick Share links).
 * Expects $project (WP_Post) and $active (stdClass file row: kind, url, label).
 */
$title     = $project->post_title !== '' ? $project->post_title : 'Shared file';
$file_url  = $active->url;
$kind      = $active->kind;
$file_name = urldecode( basename( wp_parse_url( $file_url, PHP_URL_PATH ) ) );
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?php echo esc_html( $title ); ?></title>
<style>
    * { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; height: 100%; }
    body {
        font: 16px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, system-ui, sans-serif;
        color: #1f2330; background: #f4f5f8;
        display: flex; flex-direction: column; min-height: 100vh;
    }

    .pv-header {
        display: flex; align-items: center; justify-content: space-between; gap: 16px;
        padding: 12px 24px; background: #fff; border-bottom: 1px solid #e3e5ea;
        box-shadow: 0 1px 2px rgba(16,24,40,0.03); flex-shrink: 0;
    }
    .pv-brand { display: flex; align-items: center; gap: 12px; min-width: 0; }
    .pv-logo {
        display: inline-flex; align-items: center; justify-content: center;
        width: 30px; height: 30px; border-radius: 8px; flex-shrink: 0;
        background: #1f2330; color: #fff; font-weight: 700; font-size: 15px;
    }
    .pv-titles { min-width: 0; }
    .pv-title {
        font-size: 16px; font-weight: 600; line-height: 1.25;
        overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    .pv-sub { font-size: 13px; color: #6b7180; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .pv-actions { display: flex; align-items: center; gap: 8px; flex-shrink: 0; }
    .pv-btn {
        display: inline-flex; align-items: center; gap: 6px;
        background: #eef0f5; border: 1px solid #d8dbe3; color: #1f2330;
        padding: 7px 14px; border-radius: 8px; font-size: 14px; font-weight: 500;
        text-decoration: none; cursor: pointer; white-space: nowrap; transition: background .12s;
    }
    .pv-btn:hover { background: #e2e5ed; }
    .pv-btn.is-primary { background: #2f6cff; border-color: #2f6cff; color: #fff; }
    .pv-btn.is-primary:hover { background: #205ae0; }
    .pv-btn svg { width: 15px; height: 15px; }

    .pv-stage { flex: 1; display: flex; min-height: 0; }

    /* Framed media (html, pdf) fill the whole stage */
    .pv-frame { flex: 1; width: 100%; border: 0; background: #fff; }

    /* Centered media (image, video) float on the soft canvas */
    .pv-center {
        flex: 1; display: flex; align-items: center; justify-content: center;
        padding: 32px; overflow: auto;
    }
    .pv-center img, .pv-center video {
        max-width: 100%; max-height: 100%; height: auto;
        border-radius: 10px; box-shadow: 0 10px 40px rgba(16,24,40,0.12); background: #fff;
    }

    /* Fallback card (external links / unknown) */
    .pv-card {
        margin: auto; text-align: center; background: #fff; border: 1px solid #e3e5ea;
        border-radius: 14px; padding: 40px 36px; max-width: 440px;
        box-shadow: 0 10px 40px rgba(16,24,40,0.08);
    }
    .pv-card h1 { font-size: 20px; margin: 0 0 8px; }
    .pv-card p { color: #6b7180; margin: 0 0 24px; word-break: break-all; }

    @media (max-width: 600px) {
        .pv-header { padding: 10px 14px; }
        .pv-sub { display: none; }
        .pv-btn-label { display: none; }
        .pv-btn { padding: 8px 10px; }
        .pv-center { padding: 16px; }
    }
</style>
</head>
<body>
    <header class="pv-header">
        <div class="pv-brand">
            <span class="pv-logo" aria-hidden="true">C</span>
            <div class="pv-titles">
                <div class="pv-title"><?php echo esc_html( $title ); ?></div>
                <?php if ( $file_name ) : ?>
                    <div class="pv-sub"><?php echo esc_html( $file_name ); ?></div>
                <?php endif; ?>
            </div>
        </div>
        <div class="pv-actions">
            <a class="pv-btn" href="<?php echo esc_url( $file_url ); ?>" target="_blank" rel="noopener">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>
                <span class="pv-btn-label">Open in new tab</span>
            </a>
            <a class="pv-btn is-primary" href="<?php echo esc_url( $file_url ); ?>" download>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                <span class="pv-btn-label">Download</span>
            </a>
        </div>
    </header>

    <div class="pv-stage">
        <?php if ( $kind === 'image' ) : ?>
            <div class="pv-center"><img src="<?php echo esc_url( $file_url ); ?>" alt="<?php echo esc_attr( $title ); ?>"></div>
        <?php elseif ( $kind === 'video' ) : ?>
            <div class="pv-center"><video src="<?php echo esc_url( $file_url ); ?>" controls playsinline></video></div>
        <?php elseif ( $kind === 'html' || $kind === 'pdf' || $kind === 'markdown' || $kind === 'text' ) : ?>
            <iframe class="pv-frame" src="<?php echo esc_url( $file_url ); ?>" title="<?php echo esc_attr( $title ); ?>"></iframe>
        <?php else : ?>
            <div class="pv-card">
                <h1><?php echo esc_html( $title ); ?></h1>
                <p><?php echo esc_html( $file_url ); ?></p>
                <a class="pv-btn is-primary" href="<?php echo esc_url( $file_url ); ?>" target="_blank" rel="noopener">Open</a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
