<!doctype html>
<html><head>
<meta charset="utf-8">
<title>Review link not found</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body { font: 16px/1.5 system-ui, -apple-system, sans-serif; max-width: 480px; margin: 80px auto; padding: 0 20px; color: #222; }
h1 { font-size: 22px; }
</style>
</head><body>
<h1>Review link not found</h1>
<p>This review link is invalid or has been removed. Check with the sender for an updated link.</p>
</body></html>
