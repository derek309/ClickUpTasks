<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?php echo esc_html( $client->name ); ?> &mdash; Reviews</title>
<link rel="stylesheet" href="<?php echo esc_url( CUL_REVIEW_URL . 'assets/review.css?v=' . CUL_REVIEW_VERSION ); ?>">
</head>
<body class="cul-review-body">
<div id="cul-client-app">
    <header class="cul-header">
        <div class="cul-header-left">
            <nav class="cul-crumbs" aria-label="Breadcrumb">
                <strong class="cul-crumb-current"><?php echo esc_html( $client->name ); ?></strong>
            </nav>
            <span class="cul-sub">Reviews</span>
        </div>
        <div class="cul-header-right">
            <?php
            $changes_total = 0; $pending_total = 0;
            foreach ( $rows as $r ) { $changes_total += $r['changes']; $pending_total += $r['pending']; }
            $remaining = $changes_total + $pending_total;
            ?>
            <span class="cul-sub">
                <?php if ( $remaining ) : ?>
                    <strong><?php echo (int) $remaining; ?> file<?php echo $remaining === 1 ? '' : 's'; ?> need your review</strong>
                <?php else : ?>
                    All caught up &middot; <?php echo (int) count( $rows ); ?> project<?php echo count( $rows ) === 1 ? '' : 's'; ?>
                <?php endif; ?>
            </span>
        </div>
    </header>

    <div class="cul-queue">
        <div class="cul-queue-inner">
            <?php if ( ! $rows ) : ?>
                <p class="cul-queue-empty">No reviews yet for this client.</p>
            <?php else :
                $groups = [ 'changes' => [], 'pending' => [], 'approved' => [] ];
                foreach ( $rows as $r ) {
                    if ( $r['changes'] > 0 )            $groups['changes'][]  = $r;
                    elseif ( $r['pending'] > 0 )        $groups['pending'][]  = $r;
                    elseif ( $r['total'] > 0 )          $groups['approved'][] = $r;
                    else                                $groups['pending'][]  = $r;
                }
                $sections = [
                    [ 'key' => 'approved', 'label' => 'Approved',          'pill' => 'is-approved' ],
                    [ 'key' => 'pending',  'label' => 'Needs review',      'pill' => 'is-pending' ],
                    [ 'key' => 'changes',  'label' => 'Changes requested', 'pill' => 'is-changes_requested' ],
                ];
            ?>
            <div class="cul-queue-tasklist">
                <?php foreach ( $sections as $s ) :
                    if ( empty( $groups[ $s['key'] ] ) ) continue;
                ?>
                    <div class="cul-tasklist-card is-<?php echo esc_attr( $s['key'] ); ?>">
                        <div class="cul-tasklist-section">
                            <span class="cul-status-pill <?php echo esc_attr( $s['pill'] ); ?>"><?php echo esc_html( $s['label'] ); ?></span>
                            <span class="cul-tasklist-count"><?php echo (int) count( $groups[ $s['key'] ] ); ?></span>
                        </div>
                        <?php foreach ( $groups[ $s['key'] ] as $r ) :
                            $sub_parts = [];
                            if ( ! empty( $r['thumb_url'] ) ) {
                                $fn = urldecode( basename( wp_parse_url( $r['thumb_url'], PHP_URL_PATH ) ) );
                                if ( $fn ) $sub_parts[] = $fn;
                            }
                            if ( $r['approved'] )  $sub_parts[] = $r['approved'] . ' approved';
                            if ( $r['changes'] )   $sub_parts[] = $r['changes'] . ' changes';
                            if ( $r['pending'] )   $sub_parts[] = $r['pending'] . ' pending';
                            if ( $r['open_pins'] ) $sub_parts[] = $r['open_pins'] . ' open ' . ( $r['open_pins'] === 1 ? 'comment' : 'comments' );
                        ?>
                        <a class="cul-task-row" href="<?php echo esc_url( $r['url'] ); ?>">
                            <?php if ( $r['thumb_kind'] === 'image' && $r['thumb_url'] ) : ?>
                                <div class="cul-task-thumb"><img src="<?php echo esc_url( $r['thumb_url'] ); ?>" alt=""></div>
                            <?php elseif ( $r['thumb_kind'] === 'video' && $r['thumb_url'] ) : ?>
                                <div class="cul-task-thumb"><video src="<?php echo esc_url( $r['thumb_url'] ); ?>" muted></video></div>
                            <?php elseif ( $r['thumb_kind'] ) : ?>
                                <div class="cul-task-thumb"><?php echo esc_html( strtoupper( $r['thumb_kind'] ) ); ?></div>
                            <?php else : ?>
                                <div class="cul-task-thumb">📁</div>
                            <?php endif; ?>
                            <div class="cul-task-name">
                                <span class="cul-task-label"><?php echo esc_html( $r['title'] ); ?></span>
                                <?php if ( $sub_parts ) : ?>
                                    <span class="cul-task-filename"><?php echo esc_html( implode( ' · ', $sub_parts ) ); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="cul-task-meta">
                                Updated <?php echo esc_html( human_time_diff( strtotime( $r['modified'] ), current_time( 'timestamp' ) ) ); ?> ago
                            </div>
                            <div class="cul-task-chevron">›</div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
</body></html>
