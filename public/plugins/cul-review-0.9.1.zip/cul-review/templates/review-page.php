<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?php echo esc_html( $project->post_title ); ?> &mdash; Review</title>
<link rel="stylesheet" href="<?php echo esc_url( CUL_REVIEW_URL . 'assets/review.css?v=' . CUL_REVIEW_VERSION ); ?>">
</head>
<?php
// Minimal review view (everyone): no header/queue/version chrome — just the file with
// Approve / Need changes along the bottom. Preview-only keeps its own no-controls mode.
$cul_minimal = empty( $bootstrap['previewOnly'] );
?>
<body class="cul-review-body<?php echo ! empty( $bootstrap['previewOnly'] ) ? ' cul-preview-only' : ''; ?><?php echo $cul_minimal ? ' cul-minimal' : ''; ?>">
<div id="cul-review-app">
    <header class="cul-header">
        <div class="cul-header-left">
            <button type="button" id="cul-back-to-queue" class="cul-back-btn" hidden>← All files</button>
            <nav class="cul-crumbs" aria-label="Breadcrumb">
                <?php if ( ! empty( $bootstrap['client'] ) ) : ?>
                    <a class="cul-crumb-link" href="<?php echo esc_url( $bootstrap['client']['url'] ); ?>"><?php echo esc_html( $bootstrap['client']['name'] ); ?></a>
                    <span class="cul-crumb-sep">›</span>
                <?php endif; ?>
                <strong class="cul-crumb-current"><?php echo esc_html( $project->post_title ); ?></strong>
            </nav>
            <div id="cul-version-switcher" class="cul-version-switcher" hidden>
                <button type="button" id="cul-version-trigger" class="cul-version-trigger" aria-expanded="false">
                    <span id="cul-version-current-label">Version</span>
                    <span class="cul-version-caret">▾</span>
                </button>
                <div id="cul-version-menu" class="cul-version-menu" hidden role="menu"></div>
            </div>
        </div>
        <div class="cul-header-right">
            <?php if ( ! empty( $bootstrap['isAdmin'] ) ) : ?>
                <span class="cul-admin-badge" title="You're signed in as a team member">★ Admin · <?php echo esc_html( $bootstrap['adminName'] ); ?></span>
            <?php endif; ?>
            <button type="button" id="cul-help-btn" class="cul-help-btn" title="Keyboard shortcuts" aria-label="Keyboard shortcuts">?</button>
            <button type="button" id="cul-reviewer-btn" class="cul-name-btn">Set your name</button>
        </div>
    </header>

    <div id="cul-help-popover" class="cul-help-popover" hidden>
        <div class="cul-help-title">Keyboard shortcuts</div>
        <dl class="cul-help-list">
            <dt>J / K · ↑ ↓</dt><dd>Next / previous file</dd>
            <dt>+ / −</dt><dd>Zoom in / out</dd>
            <dt>0</dt><dd>Reset zoom</dd>
            <dt>F</dt><dd>Fit to window</dd>
            <dt>Esc</dt><dd>Close modal</dd>
            <dt>⌘/Ctrl + Enter</dt><dd>Post comment</dd>
        </dl>
        <div class="cul-help-tip">Tip: click anywhere on the file to drop a pin comment.</div>
    </div>

    <section id="cul-queue" class="cul-queue" hidden>
        <div class="cul-queue-inner">
            <h1 class="cul-queue-title">What's left to review</h1>
            <p class="cul-queue-sub" id="cul-queue-sub"></p>
            <div id="cul-queue-list" class="cul-queue-tasklist"></div>
        </div>
    </section>

    <div id="cul-toast" class="cul-toast" hidden></div>

<div id="cul-mobile-gate" class="cul-mobile-gate" hidden>
    <div class="cul-mobile-gate-inner">
        <div class="cul-mobile-gate-icon">🖥️</div>
        <h2>Open this on a computer</h2>
        <p>This review needs a desktop or laptop so you can click precisely and leave pin comments on the artwork.</p>
        <p class="cul-mobile-gate-tip">Please open this same link on a computer to review and approve.</p>
    </div>
</div>

    <div class="cul-layout" id="cul-layout">
        <aside class="cul-sidebar">
            <div id="cul-decision" class="cul-decision" hidden>
                <!-- Pending mode: two big buttons, this is the primary decision point -->
                <div class="cul-decision-pending" data-mode="pending">
                    <div class="cul-decision-prompt">How does <span id="cul-decision-file"></span> look?</div>
                    <div class="cul-decision-buttons">
                        <button type="button" class="cul-decision-btn is-approve" data-status="approved">
                            <span class="cul-decision-icon">✓</span> Approve
                        </button>
                        <button type="button" class="cul-decision-btn is-changes" data-status="changes_requested">
                            <span class="cul-decision-icon">✎</span> Need changes
                        </button>
                    </div>
                </div>

                <!-- Approved mode: confirmation + download CTA -->
                <div class="cul-decision-approved" data-mode="approved" hidden>
                    <div id="cul-approved-note" class="cul-approved-note"></div>
                    <a id="cul-decision-download" class="cul-decision-download" href="#" download>
                        <span class="cul-decision-icon">⬇</span> <span class="cul-decision-download-label">Download file</span>
                    </a>
                    <button type="button" class="cul-decision-reset" data-status="pending">Reset to pending</button>
                </div>

                <!-- Changes-requested mode container (empty; comments section handles the UI) -->
                <div class="cul-decision-changes" data-mode="changes" hidden></div>
            </div>

            <div id="cul-reviewers" class="cul-reviewers" hidden></div>

            <div id="cul-comments-section" class="cul-section cul-section-comments" hidden>
                <h2 class="cul-side-title">Pin comments</h2>
                <div id="cul-pin-list" class="cul-pin-list"></div>
            </div>

            <div id="cul-submit-bar" class="cul-submit-bar" hidden>
                <button type="button" id="cul-submit-review-btn" class="cul-submit-btn">Submit review request</button>
            </div>

            <div id="cul-admin-revision" class="cul-admin-revision" hidden>
                <div class="cul-admin-revision-head">
                    <span class="cul-admin-revision-title">Revisions complete?</span>
                    <span class="cul-admin-revision-sub">Upload the new version. This one will be marked as superseded.</span>
                </div>
                <div id="cul-admin-dropzone" class="cul-admin-dropzone">
                    <div class="cul-admin-dropzone-text">Drop the revised file here, or click to choose</div>
                    <input type="file" id="cul-admin-dropzone-input" hidden>
                </div>
                <div id="cul-admin-upload-progress" class="cul-admin-upload-progress"></div>

                <div id="cul-admin-staged" class="cul-admin-staged" hidden>
                    <div class="cul-admin-staged-preview">
                        <div id="cul-admin-staged-thumb" class="cul-admin-staged-thumb"></div>
                        <div class="cul-admin-staged-info">
                            <div id="cul-admin-staged-name" class="cul-admin-staged-name"></div>
                            <div id="cul-admin-staged-label" class="cul-admin-staged-label"></div>
                        </div>
                    </div>
                    <label class="cul-admin-staged-option">
                        <input type="checkbox" id="cul-admin-supersede" checked>
                        Mark current version as superseded (its open pins will auto-resolve)
                    </label>
                    <label class="cul-admin-staged-option">
                        <input type="checkbox" id="cul-admin-notify" checked>
                        Email the reviewer that a new version is ready
                    </label>
                    <div class="cul-admin-staged-actions">
                        <button type="button" id="cul-admin-cancel" class="cul-btn-text">Cancel</button>
                        <button type="button" id="cul-admin-submit" class="cul-submit-btn">Submit revision</button>
                    </div>
                </div>
            </div>
        </aside>
        <main class="cul-stage">
            <div id="cul-stage" class="cul-stage-canvas">
                <div class="cul-empty">Select a file on the left to start reviewing.</div>
            </div>
            <div id="cul-zoom-group" class="cul-zoom-overlay" hidden>
                <button type="button" id="cul-zoom-out" title="Zoom out (−)">−</button>
                <button type="button" id="cul-zoom-level" title="Reset zoom (0)">100%</button>
                <button type="button" id="cul-zoom-in" title="Zoom in (+)">+</button>
                <span class="cul-zoom-divider"></span>
                <button type="button" id="cul-zoom-fit" title="Fit to window (F)">Fit</button>
            </div>
        </main>
    </div>
</div>

<div id="cul-identity-modal" class="cul-modal" hidden>
    <div class="cul-modal-inner">
        <h3>Enter your email to continue</h3>
        <p style="color:#6b7180;margin:0 0 12px">We use your email to track your feedback and notify you when a new version is ready. Required.</p>
        <input type="email" id="cul-identity-email" placeholder="you@example.com" maxlength="190" required>
        <div id="cul-identity-error" class="cul-identity-error" hidden>Please enter a valid email address.</div>
        <div class="cul-modal-actions">
            <button type="button" class="cul-btn-text" id="cul-identity-cancel">Cancel</button>
            <button type="button" class="cul-btn-primary" id="cul-identity-save">Continue</button>
        </div>
    </div>
</div>

<div id="cul-approve-modal" class="cul-modal" hidden>
    <div class="cul-modal-inner">
        <h3>Approved ✓</h3>
        <p id="cul-approve-modal-text">Want to download the final file before you go?</p>
        <div class="cul-modal-actions cul-modal-stack">
            <a id="cul-approve-download" class="cul-btn-primary" href="#" download>⬇ Download file</a>
            <button type="button" class="cul-btn-secondary" id="cul-approve-skip">Skip, just exit</button>
            <button type="button" class="cul-btn-text" id="cul-approve-cancel">Cancel</button>
        </div>
    </div>
</div>

<div id="cul-submit-modal" class="cul-modal" hidden>
    <div class="cul-modal-inner">
        <h3>Submit review request</h3>
        <p>Any final notes for the team? (optional)</p>
        <textarea id="cul-submit-note" rows="4" placeholder="e.g. Prefer the second concept overall, focus on the headline copy."></textarea>
        <div class="cul-modal-actions">
            <button type="button" class="cul-btn-text" id="cul-submit-cancel">Cancel</button>
            <button type="button" class="cul-btn-secondary" id="cul-submit-skip">Skip & exit</button>
            <button type="button" class="cul-btn-primary" id="cul-submit-send">Submit</button>
        </div>
    </div>
</div>

<div id="cul-pin-modal" class="cul-modal" hidden>
    <div class="cul-modal-inner">
        <h3 id="cul-pin-modal-title">Leave a comment</h3>
        <textarea id="cul-pin-body" rows="4" placeholder="What needs changing here?"></textarea>
        <div class="cul-pin-attach">
            <label for="cul-pin-attach-input" class="cul-pin-attach-btn">📎 Attach a reference image</label>
            <input type="file" id="cul-pin-attach-input" accept="image/*" hidden>
            <div id="cul-pin-attach-preview" class="cul-pin-attach-preview" hidden></div>
        </div>
        <div class="cul-modal-actions">
            <button type="button" class="cul-btn-cancel cul-btn-text">Cancel</button>
            <button type="button" class="cul-btn-save cul-btn-primary">Post comment</button>
        </div>
    </div>
</div>

<script>
window.CUL_REVIEW = <?php echo wp_json_encode( $bootstrap ); ?>;
</script>
<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
<script src="<?php echo esc_url( CUL_REVIEW_URL . 'assets/review.js?v=' . CUL_REVIEW_VERSION ); ?>"></script>
</body></html>
