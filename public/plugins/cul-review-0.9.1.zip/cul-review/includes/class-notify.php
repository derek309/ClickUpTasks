<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class CUL_Review_Notify {

    public static function assigned_user( $project_id ) {
        $uid = (int) get_post_meta( $project_id, '_cul_assigned_user_id', true );
        if ( ! $uid ) {
            $post = get_post( $project_id );
            if ( $post ) $uid = (int) $post->post_author;
        }
        return $uid ? get_userdata( $uid ) : null;
    }

    private static function project_url( $project_id, $file_id = 0 ) {
        $token = CUL_Review_CPT::ensure_token( $project_id );
        $base  = home_url( '/r/' . $token );
        return $file_id ? $base . '#file=' . (int) $file_id : $base;
    }

    /**
     * Send an email to the assigned user.
     */
    public static function send( $project_id, $subject, $body_html ) {
        $user = self::assigned_user( $project_id );
        if ( ! $user || ! is_email( $user->user_email ) ) return false;

        $project = get_post( $project_id );
        $title   = $project ? $project->post_title : 'Review';
        $subject = '[' . get_bloginfo( 'name' ) . '] ' . $subject . ': ' . $title;

        $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
        return wp_mail( $user->user_email, $subject, $body_html, $headers );
    }

    public static function on_file_approved( $project_id, $file ) {
        $url = self::project_url( $project_id, $file->id );
        $when = mysql2date( get_option( 'date_format' ) . ' \a\t ' . get_option( 'time_format' ), $file->approved_at );
        $body = '<p><strong>' . esc_html( $file->label ) . '</strong> was approved.</p>'
              . '<p><strong>By:</strong> ' . esc_html( $file->approved_by ) . '<br>'
              . '<strong>When:</strong> ' . esc_html( $when ) . '</p>'
              . '<p><a href="' . esc_url( $url ) . '">Open the project →</a></p>';
        self::send( $project_id, '✓ Approved', $body );
    }

    public static function on_file_changes_requested( $project_id, $file, $author_name = '' ) {
        global $wpdb;
        $pin_count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}cul_review_pins WHERE file_id = %d AND status = 'open'", $file->id
        ) );
        $url = self::project_url( $project_id, $file->id );
        $body = '<p><strong>' . esc_html( $file->label ) . ':</strong> changes requested.</p>'
              . '<p>' . esc_html( $author_name ?: 'A reviewer' ) . ' has flagged this file. '
              . 'Currently ' . $pin_count . ' open pin comment' . ( $pin_count === 1 ? '' : 's' ) . '.</p>'
              . '<p><a href="' . esc_url( $url ) . '">Open the project →</a></p>';
        self::send( $project_id, '✎ Changes requested', $body );
    }

    public static function on_new_revision( $project_id, $new_file, $superseded_file_id = 0 ) {
        global $wpdb;

        // Build recipient list: assigned Client emails + project reviewer override + unique pin-author emails
        $emails = CUL_Review_CPT::client_emails_for_project( $project_id );

        $override = (string) get_post_meta( $project_id, '_cul_reviewer_email', true );
        if ( is_email( $override ) ) $emails[ strtolower( $override ) ] = $override;

        $pin_emails = $wpdb->get_col( $wpdb->prepare(
            "SELECT DISTINCT author_email FROM {$wpdb->prefix}cul_review_pins
             WHERE project_id = %d AND author_email <> ''",
            $project_id
        ) );
        foreach ( $pin_emails as $e ) {
            if ( is_email( $e ) ) $emails[ strtolower( $e ) ] = $e;
        }
        if ( ! $emails ) return;

        $project = get_post( $project_id );
        $title   = $project ? $project->post_title : 'Review';
        $url     = self::project_url( $project_id, $new_file->id );
        $site    = get_bloginfo( 'name' );

        $body = '<p>Hi,</p>'
              . '<p>A new version is ready for your review on <strong>' . esc_html( $title ) . '</strong>:</p>'
              . '<p><strong>' . esc_html( $new_file->label ) . '</strong></p>'
              . '<p><a href="' . esc_url( $url ) . '" style="background:#2f6cff;color:#fff;padding:10px 16px;border-radius:6px;text-decoration:none;font-weight:600">Review it →</a></p>'
              . '<p style="color:#6b7180;font-size:14px">Or paste this link in your browser:<br>' . esc_html( $url ) . '</p>';

        $subject = '[' . $site . '] New version to review: ' . $title;
        $headers = [ 'Content-Type: text/html; charset=UTF-8' ];
        foreach ( $emails as $to ) {
            wp_mail( $to, $subject, $body, $headers );
        }
    }

    public static function on_review_submitted( $project_id, $file, $author_name = '', $note = '' ) {
        global $wpdb;
        $pin_count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}cul_review_pins WHERE file_id = %d AND status = 'open'", $file->id
        ) );
        $url = self::project_url( $project_id, $file->id );
        $body = '<p><strong>Review request submitted</strong> for <strong>' . esc_html( $file->label ) . '</strong>.</p>'
              . '<p><strong>By:</strong> ' . esc_html( $author_name ?: 'Guest' ) . '<br>'
              . '<strong>Open pins to address:</strong> ' . $pin_count . '</p>';
        if ( $note !== '' ) {
            $body .= '<p><strong>Final note:</strong><br><em>' . nl2br( esc_html( $note ) ) . '</em></p>';
        }
        $body .= '<p><a href="' . esc_url( $url ) . '">Open the project →</a></p>';
        self::send( $project_id, '📨 Review submitted', $body );
    }
}
