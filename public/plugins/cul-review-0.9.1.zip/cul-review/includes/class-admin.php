<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class CUL_Review_Admin {

    public static function admin_init() {
        // nothing for now
    }

    /* --- Quick Share: one-step upload → published preview link --- */

    public static function quick_share_menu() {
        add_submenu_page(
            'edit.php?post_type=' . CUL_Review_CPT::POST_TYPE,
            'Quick Share',
            'Quick Share',
            'edit_posts',
            'cul-quick-share',
            [ __CLASS__, 'render_quick_share' ]
        );
    }

    public static function render_quick_share() {
        if ( ! current_user_can( 'edit_posts' ) ) return;
        $endpoint = esc_url_raw( rest_url( 'cul-review/v1/quick-share' ) );
        $nonce    = wp_create_nonce( 'wp_rest' );
        ?>
        <div class="wrap">
            <h1>Quick Share</h1>
            <p style="max-width:640px;color:#50575e;font-size:14px">
                Drop a file below. It uploads, creates a preview-only review page named after the file,
                and copies the public link to your clipboard. No login needed to view it.
            </p>

            <div id="cul-qs-drop" class="cul-qs-drop" tabindex="0" role="button" aria-label="Upload a file to share">
                <div class="cul-qs-drop-inner">
                    <span class="dashicons dashicons-upload"></span>
                    <div><strong>Drop a file here</strong> or click to choose</div>
                    <div class="cul-qs-hint">Images, video, PDF, HTML, or a zipped HTML bundle</div>
                </div>
                <input type="file" id="cul-qs-input" multiple style="display:none">
            </div>

            <div id="cul-qs-results" class="cul-qs-results"></div>
        </div>

        <style>
            .cul-qs-drop{max-width:640px;margin:16px 0;border:2px dashed #c3c4c7;border-radius:12px;
                background:#fff;text-align:center;padding:40px 20px;cursor:pointer;transition:.15s;color:#50575e}
            .cul-qs-drop:hover,.cul-qs-drop:focus{border-color:#2271b1;background:#f6fbff;outline:none}
            .cul-qs-drop.is-dragover{border-color:#2271b1;background:#eef6fd}
            .cul-qs-drop .dashicons{font-size:36px;width:36px;height:36px;color:#2271b1;margin-bottom:6px}
            .cul-qs-hint{font-size:12px;color:#787c82;margin-top:6px}
            .cul-qs-results{max-width:640px}
            .cul-qs-card{display:flex;align-items:center;gap:12px;background:#fff;border:1px solid #dcdcde;
                border-left:4px solid #2271b1;border-radius:8px;padding:14px 16px;margin:10px 0}
            .cul-qs-card.is-error{border-left-color:#d63638}
            .cul-qs-card.is-busy{border-left-color:#dba617}
            .cul-qs-card-main{flex:1;min-width:0}
            .cul-qs-card-title{font-weight:600;margin-bottom:4px}
            .cul-qs-card input.cul-qs-url{width:100%;font-size:13px;padding:5px 8px;border:1px solid #dcdcde;border-radius:6px}
            .cul-qs-card-actions{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
            .cul-qs-status{font-size:12px;color:#50575e;white-space:nowrap}
            .cul-qs-copied{color:#1f6f3f;font-weight:600}
        </style>

        <script>
        (function(){
            var ENDPOINT = <?php echo wp_json_encode( $endpoint ); ?>;
            var NONCE    = <?php echo wp_json_encode( $nonce ); ?>;
            var drop     = document.getElementById('cul-qs-drop');
            var input    = document.getElementById('cul-qs-input');
            var results  = document.getElementById('cul-qs-results');

            function copyText(text){
                if (navigator.clipboard && window.isSecureContext){
                    return navigator.clipboard.writeText(text);
                }
                return new Promise(function(resolve, reject){
                    var ta = document.createElement('textarea');
                    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
                    document.body.appendChild(ta); ta.focus(); ta.select();
                    var ok = false; try { ok = document.execCommand('copy'); } catch(e){}
                    document.body.removeChild(ta);
                    ok ? resolve() : reject();
                });
            }

            function esc(s){ var d = document.createElement('div'); d.textContent = s == null ? '' : s; return d.innerHTML; }

            function card(html, cls){
                var el = document.createElement('div');
                el.className = 'cul-qs-card' + (cls ? ' ' + cls : '');
                el.innerHTML = html;
                results.insertBefore(el, results.firstChild);
                return el;
            }

            function handleFiles(files){
                Array.prototype.forEach.call(files, function(file){ upload(file); });
            }

            function upload(file){
                var el = card('<div class="cul-qs-card-main"><div class="cul-qs-card-title">'
                    + esc(file.name) + '</div><div class="cul-qs-status">Uploading…</div></div>', 'is-busy');

                var fd = new FormData();
                fd.append('file', file);

                fetch(ENDPOINT, {
                    method: 'POST',
                    headers: { 'X-WP-Nonce': NONCE },
                    body: fd,
                    credentials: 'same-origin'
                }).then(function(r){
                    return r.json().then(function(data){ return { ok: r.ok, data: data }; });
                }).then(function(res){
                    if (!res.ok || !res.data || !res.data.share_url){
                        var msg = (res.data && res.data.message) ? res.data.message : 'Upload failed.';
                        el.className = 'cul-qs-card is-error';
                        el.innerHTML = '<div class="cul-qs-card-main"><div class="cul-qs-card-title">'
                            + esc(file.name) + '</div><div class="cul-qs-status">' + esc(msg) + '</div></div>';
                        return;
                    }
                    var d = res.data;
                    el.className = 'cul-qs-card';
                    el.innerHTML =
                        '<div class="cul-qs-card-main">'
                        + '<div class="cul-qs-card-title">' + esc(d.title) + '</div>'
                        + '<input class="cul-qs-url" readonly value="' + esc(d.share_url) + '" onclick="this.select()">'
                        + '<div class="cul-qs-card-actions">'
                        + '<a class="button button-primary" target="_blank" rel="noopener" href="' + esc(d.share_url) + '">Open preview</a>'
                        + '<button type="button" class="button cul-qs-copy">Copy link</button>'
                        + '<a class="button" target="_blank" rel="noopener" href="' + esc(d.edit_url) + '">Edit</a>'
                        + '<span class="cul-qs-status cul-qs-copied" style="display:none">Copied to clipboard ✓</span>'
                        + '</div></div>';

                    var copiedEl = el.querySelector('.cul-qs-copied');
                    var copyBtn  = el.querySelector('.cul-qs-copy');
                    copyText(d.share_url).then(function(){ copiedEl.style.display = ''; }).catch(function(){});
                    copyBtn.addEventListener('click', function(){
                        copyText(d.share_url).then(function(){
                            copiedEl.style.display = '';
                            copyBtn.textContent = 'Copied!';
                            setTimeout(function(){ copyBtn.textContent = 'Copy link'; }, 1200);
                        }).catch(function(){});
                    });
                }).catch(function(){
                    el.className = 'cul-qs-card is-error';
                    el.innerHTML = '<div class="cul-qs-card-main"><div class="cul-qs-card-title">'
                        + esc(file.name) + '</div><div class="cul-qs-status">Network error. Try again.</div></div>';
                });
            }

            drop.addEventListener('click', function(){ input.click(); });
            drop.addEventListener('keydown', function(e){ if (e.key === 'Enter' || e.key === ' '){ e.preventDefault(); input.click(); } });
            input.addEventListener('change', function(){ if (this.files.length){ handleFiles(this.files); this.value = ''; } });

            ['dragenter','dragover'].forEach(function(ev){
                drop.addEventListener(ev, function(e){ e.preventDefault(); e.stopPropagation(); drop.classList.add('is-dragover'); });
            });
            ['dragleave','drop'].forEach(function(ev){
                drop.addEventListener(ev, function(e){ e.preventDefault(); e.stopPropagation(); drop.classList.remove('is-dragover'); });
            });
            drop.addEventListener('drop', function(e){
                if (e.dataTransfer && e.dataTransfer.files.length){ handleFiles(e.dataTransfer.files); }
            });
        })();
        </script>
        <?php
    }

    /* --- Review Projects list table: Review status column --- */

    public static function project_columns( $columns ) {
        $new = [];
        foreach ( $columns as $key => $label ) {
            if ( $key === 'date' ) {
                $new['cul_status'] = 'Review status';
            }
            $new[ $key ] = $label;
        }
        if ( ! isset( $new['cul_status'] ) ) $new['cul_status'] = 'Review status';
        return $new;
    }

    public static function project_column_content( $column, $post_id ) {
        if ( $column !== 'cul_status' ) return;
        global $wpdb;

        $counts = $wpdb->get_results( $wpdb->prepare(
            "SELECT status, COUNT(*) c FROM {$wpdb->prefix}cul_review_files WHERE project_id = %d GROUP BY status",
            $post_id
        ), OBJECT_K );
        $get = function ( $k ) use ( $counts ) { return isset( $counts[ $k ] ) ? (int) $counts[ $k ]->c : 0; };
        $pending  = $get( 'pending' );
        $changes  = $get( 'changes_requested' );
        $approved = $get( 'approved' );
        $supers   = $get( 'superseded' );
        $total    = $pending + $changes + $approved + $supers;

        $open_pins = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}cul_review_pins WHERE project_id = %d AND status = 'open'",
            $post_id
        ) );

        if ( ! $total ) {
            echo '<span style="color:#999">No files yet</span>';
            return;
        }

        $pill = function ( $text, $bg, $fg ) {
            return '<span style="display:inline-block;padding:2px 8px;border-radius:999px;font-size:12px;'
                 . 'background:' . $bg . ';color:' . $fg . ';margin:0 4px 4px 0;white-space:nowrap">'
                 . esc_html( $text ) . '</span>';
        };

        echo '<div style="line-height:1.6">';
        if ( $changes )  echo $pill( $changes . ' changes requested', '#fde2cf', '#9a3210' );
        if ( $pending )  echo $pill( $pending . ' pending', '#eef0f5', '#4a4f5e' );
        if ( $approved ) echo $pill( $approved . ' approved', '#d8f1e2', '#1f6f3f' );
        if ( $supers )   echo $pill( $supers . ' superseded', '#eef0f5', '#9aa1b1' );
        echo '</div>';

        if ( $open_pins ) {
            echo '<div style="color:#9a3210;font-size:12px;margin-top:2px">'
               . (int) $open_pins . ' open comment' . ( $open_pins === 1 ? '' : 's' ) . '</div>';
        } else {
            echo '<div style="color:#999;font-size:12px;margin-top:2px">No open comments</div>';
        }
    }

    public static function enqueue( $hook ) {
        global $post;
        if ( ! $post || $post->post_type !== CUL_Review_CPT::POST_TYPE ) return;
        wp_enqueue_media();
        wp_enqueue_style( 'cul-review-admin', CUL_REVIEW_URL . 'assets/admin.css', [], CUL_REVIEW_VERSION );
        wp_enqueue_script( 'cul-review-admin', CUL_REVIEW_URL . 'assets/admin.js', [ 'jquery' ], CUL_REVIEW_VERSION, true );
        $token = $post->ID ? CUL_Review_CPT::ensure_token( $post->ID ) : '';
        wp_localize_script( 'cul-review-admin', 'CUL_ADMIN', [
            'mediaEndpoint' => esc_url_raw( rest_url( 'wp/v2/media' ) ),
            'zipEndpoint'   => esc_url_raw( rest_url( 'cul-review/v1/upload' ) ),
            'projectToken'  => $token,
            'nonce'         => wp_create_nonce( 'wp_rest' ),
        ] );
    }

    public static function meta_boxes() {
        add_meta_box( 'cul_review_share', 'Share Link', [ __CLASS__, 'box_share' ], CUL_Review_CPT::POST_TYPE, 'side' );
        add_meta_box( 'cul_review_assigned', 'Assigned to', [ __CLASS__, 'box_assigned' ], CUL_Review_CPT::POST_TYPE, 'side' );
        add_meta_box( 'cul_review_reviewer', 'Reviewer contact', [ __CLASS__, 'box_reviewer' ], CUL_Review_CPT::POST_TYPE, 'side' );
        add_meta_box( 'cul_review_files', 'Review Files', [ __CLASS__, 'box_files' ], CUL_Review_CPT::POST_TYPE, 'normal', 'high' );
    }

    /**
     * Build a full-snapshot markdown handoff for a review project: each file
     * (label, kind, link, status, decisions) followed by its pins (positioned
     * client comments) and any threaded replies.
     */
    public static function build_context_markdown( $project_id ) {
        global $wpdb;
        $project = get_post( $project_id );
        $title   = $project ? $project->post_title : '';

        $L   = [];
        $L[] = '# ' . ( $title !== '' ? $title : 'Review project' ) . ': review feedback';
        $L[] = '';
        $L[] = '- Project ID: ' . (int) $project_id;
        if ( $project && $project->post_status === 'publish' ) {
            $token = get_post_meta( $project_id, '_cul_share_token', true );
            if ( $token ) $L[] = '- Share link: ' . home_url( '/r/' . $token );
        }
        $reviewer = (string) get_post_meta( $project_id, '_cul_reviewer_name', true );
        if ( $reviewer !== '' ) $L[] = '- Reviewer: ' . $reviewer;
        $L[] = '- Exported: ' . current_time( 'Y-m-d H:i' );
        $L[] = '';

        $files = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}cul_review_files WHERE project_id = %d ORDER BY sort_order ASC, id ASC",
            $project_id
        ) );
        if ( ! $files ) {
            $L[] = '_No files in this project yet._';
            return implode( "\n", $L );
        }

        $status_label = [
            'pending'           => 'Pending',
            'approved'          => 'Approved',
            'changes_requested' => 'Changes requested',
            'superseded'        => 'Superseded',
        ];

        foreach ( $files as $f ) {
            $L[] = '## ' . ( $f->label !== '' ? $f->label : 'File #' . (int) $f->id ) . ' (' . $f->kind . ')';
            $L[] = '- Status: ' . ( $status_label[ $f->status ] ?? $f->status );
            $L[] = '- Link: ' . $f->url;
            if ( $f->status === 'approved' && $f->approved_by ) {
                $L[] = '- Approved by: ' . $f->approved_by . ( $f->approved_at ? ' on ' . $f->approved_at : '' );
            }

            $decisions = $wpdb->get_results( $wpdb->prepare(
                "SELECT reviewer_name, decision FROM {$wpdb->prefix}cul_review_decisions WHERE file_id = %d ORDER BY updated_at ASC",
                $f->id
            ) );
            if ( $decisions ) {
                $parts = [];
                foreach ( $decisions as $d ) {
                    $verb = $d->decision === 'changes_requested' ? 'changes requested' : $d->decision;
                    $parts[] = ( $d->reviewer_name ?: 'Guest' ) . ': ' . $verb;
                }
                $L[] = '- Decisions: ' . implode( '; ', $parts );
            }
            $L[] = '';

            $pins = $wpdb->get_results( $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}cul_review_pins WHERE file_id = %d ORDER BY number ASC, id ASC",
                $f->id
            ) );
            if ( ! $pins ) {
                $L[] = '_No comments on this file._';
                $L[] = '';
                continue;
            }

            $L[] = '### Comments';
            foreach ( $pins as $p ) {
                if ( $p->x_pct !== null && $p->y_pct !== null ) {
                    $loc = 'at ' . round( (float) $p->x_pct ) . '% left, ' . round( (float) $p->y_pct ) . '% top';
                } elseif ( $p->t_seconds !== null ) {
                    $secs = (int) $p->t_seconds;
                    $loc  = sprintf( 'at %d:%02d', intdiv( $secs, 60 ), $secs % 60 );
                } else {
                    $loc = 'general';
                }
                $state = $p->status === 'resolved' ? 'resolved' : 'open';
                $L[] = sprintf( '%d. [%s] (%s) %s: %s', (int) $p->number, $state, $loc, ( $p->author_name ?: 'Guest' ), $p->body );
                if ( ! empty( $p->attachment_url ) ) {
                    $L[] = '   - Attachment: ' . $p->attachment_url;
                }
                $replies = $wpdb->get_results( $wpdb->prepare(
                    "SELECT author_name, body, is_staff FROM {$wpdb->prefix}cul_review_comments WHERE pin_id = %d ORDER BY created_at ASC",
                    $p->id
                ) );
                foreach ( $replies as $r ) {
                    $who = ( $r->author_name ?: 'Guest' ) . ( $r->is_staff ? ' (staff)' : '' );
                    $L[] = '   - reply by ' . $who . ': ' . $r->body;
                }
            }
            $L[] = '';
        }

        return implode( "\n", $L );
    }

    public static function box_reviewer( $post ) {
        wp_nonce_field( 'cul_review_reviewer', 'cul_review_reviewer_nonce' );
        $name  = get_post_meta( $post->ID, '_cul_reviewer_name', true );
        $email = get_post_meta( $post->ID, '_cul_reviewer_email', true );
        echo '<p><label for="cul_reviewer_name" style="display:block;margin-bottom:4px">Reviewer name</label>';
        echo '<input type="text" id="cul_reviewer_name" name="cul_reviewer_name" value="' . esc_attr( $name ) . '" style="width:100%" placeholder="e.g. Jane Smith"></p>';
        echo '<p><label for="cul_reviewer_email" style="display:block;margin-bottom:4px">Reviewer email</label>';
        echo '<input type="email" id="cul_reviewer_email" name="cul_reviewer_email" value="' . esc_attr( $email ) . '" style="width:100%" placeholder="jane@example.com"></p>';
        echo '<p style="color:#666;font-size:12px">Pre-fills the reviewer\'s identity on the share page. They\'ll also get an email when you upload a new revision.</p>';
    }

    public static function box_assigned( $post ) {
        wp_nonce_field( 'cul_review_assigned', 'cul_review_assigned_nonce' );
        $current_id = (int) get_post_meta( $post->ID, '_cul_assigned_user_id', true );
        if ( ! $current_id ) $current_id = (int) $post->post_author;
        $users = get_users( [ 'capability' => 'edit_posts', 'fields' => [ 'ID', 'display_name', 'user_email' ] ] );
        echo '<p><label for="cul_assigned_user_id" style="display:block;margin-bottom:6px">Who gets notified when this project changes?</label>';
        echo '<select name="cul_assigned_user_id" id="cul_assigned_user_id" style="width:100%">';
        foreach ( $users as $u ) {
            printf(
                '<option value="%d"%s>%s &lt;%s&gt;</option>',
                (int) $u->ID,
                selected( $current_id, (int) $u->ID, false ),
                esc_html( $u->display_name ),
                esc_html( $u->user_email )
            );
        }
        echo '</select></p>';
        echo '<p style="color:#666;font-size:12px">Defaults to whoever created the project. They\'ll get an email when a reviewer approves, requests changes, or submits a review.</p>';
    }

    public static function box_share( $post ) {
        wp_nonce_field( 'cul_review_share', 'cul_review_share_nonce' );
        $preview_only = get_post_meta( $post->ID, '_cul_preview_only', true ) === '1';

        if ( $post->post_status === 'publish' ) {
            $token = CUL_Review_CPT::ensure_token( $post->ID );
            $url   = home_url( '/r/' . $token );
            echo '<p><input type="text" id="cul-share-url" readonly value="' . esc_attr( $url ) . '" style="width:100%" onclick="this.select()"></p>';
            echo '<p style="display:flex;gap:6px">';
            echo '<a class="button button-primary" target="_blank" href="' . esc_url( $url ) . '">Open review page</a>';
            echo '<button type="button" class="button" id="cul-copy-link">Copy link</button>';
            echo '</p>';
            echo '<p style="color:#666;font-size:12px">Anyone with this link can view' . ( $preview_only ? '' : ' and comment' ) . '. No login required.</p>';
            echo "<script>jQuery(function(\$){\$('#cul-copy-link').on('click',function(){var i=document.getElementById('cul-share-url');navigator.clipboard.writeText(i.value).then(function(){var b=document.getElementById('cul-copy-link');var t=b.textContent;b.textContent='Copied!';setTimeout(function(){b.textContent=t;},1200);});});});</script>";
        } else {
            echo '<p>Publish the project to generate a share link.</p>';
        }

        echo '<hr style="margin:12px 0">';
        echo '<p><label style="display:flex;gap:8px;align-items:flex-start;cursor:pointer">';
        echo '<input type="checkbox" name="cul_preview_only" value="1"' . checked( $preview_only, true, false ) . '>';
        echo '<span><strong>Preview only</strong><br><span style="color:#666;font-size:12px">Hides all review controls (Approve, Request changes, pin comments). The link just shows the file as a normal page — good for sharing an HTML page or design with no restrictions.</span></span>';
        echo '</label></p>';
    }

    public static function box_files( $post ) {
        wp_nonce_field( 'cul_review_files', 'cul_review_files_nonce' );
        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}cul_review_files WHERE project_id = %d ORDER BY sort_order ASC, id ASC",
            $post->ID
        ) );

        $files_json = wp_json_encode( array_map( function( $r ) {
            return [
                'id' => (int) $r->id,
                'attachment_id' => (int) $r->attachment_id,
                'kind' => $r->kind,
                'label' => $r->label,
                'url' => $r->url,
                'status' => $r->status,
            ];
        }, $rows ?: [] ) );
        ?>
        <div id="cul-review-files-app" data-files='<?php echo esc_attr( $files_json ); ?>'>
            <p style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                <button type="button" class="button button-primary" id="cul-add-files">Add files</button>
                <button type="button" class="button" id="cul-add-link">Add link (URL)</button>
                <span style="color:#666">Files: JPG, PNG, GIF, WEBP, SVG, MP4, WEBM, MOV, HTML, MD, TXT, PDF. Link: any public URL.</span>
                <button type="button" class="button" id="cul-claude-copy" data-fname="<?php echo esc_attr( ( sanitize_title( $post->post_title ) ?: 'review-' . $post->ID ) . '-review.md' ); ?>" title="Download a markdown snapshot of every file link and all client comments, and copy it to the clipboard for Claude Code" style="margin-left:auto">Copy for Claude</button>
            </p>
            <textarea id="cul-claude-md" readonly style="display:none"><?php echo esc_textarea( self::build_context_markdown( $post->ID ) ); ?></textarea>
            <script>
            jQuery(function($){
                $('#cul-claude-copy').on('click', function(){
                    var btn = this;
                    var text = document.getElementById('cul-claude-md').value;
                    var blob = new Blob([text], { type: 'text/markdown;charset=utf-8' });
                    var url  = URL.createObjectURL(blob);
                    var a    = document.createElement('a');
                    a.href = url;
                    a.download = btn.getAttribute('data-fname') || 'review.md';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    setTimeout(function(){ URL.revokeObjectURL(url); }, 1000);
                    var restore = function(){ btn.textContent = 'Copy for Claude'; };
                    if (navigator.clipboard && navigator.clipboard.writeText) {
                        navigator.clipboard.writeText(text)
                            .then(function(){ btn.textContent = 'Copied ✓'; setTimeout(restore, 1800); })
                            .catch(restore);
                    }
                });
            });
            </script>
            <div id="cul-dropzone" class="cul-dropzone">
                <div class="cul-dropzone-text"><strong>Drop files here</strong> to upload, or click to choose</div>
                <input type="file" id="cul-dropzone-input" multiple style="display:none">
                <div id="cul-upload-progress" class="cul-upload-progress"></div>
            </div>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th style="width:80px">Preview</th>
                        <th>Label</th>
                        <th style="width:90px">Type</th>
                        <th style="width:140px">Status</th>
                        <th style="width:70px">Done</th>
                        <th style="width:60px">Order</th>
                        <th style="width:60px">&nbsp;</th>
                    </tr>
                </thead>
                <tbody id="cul-files-tbody"></tbody>
            </table>
            <input type="hidden" name="cul_files_payload" id="cul-files-payload" value="">
        </div>
        <?php
    }

    public static function save_post( $post_id, $post ) {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
        if ( ! current_user_can( 'edit_post', $post_id ) ) return;

        // Save Assigned-to selection
        if ( isset( $_POST['cul_review_assigned_nonce'] ) && wp_verify_nonce( $_POST['cul_review_assigned_nonce'], 'cul_review_assigned' ) ) {
            $assigned = isset( $_POST['cul_assigned_user_id'] ) ? (int) $_POST['cul_assigned_user_id'] : 0;
            if ( $assigned > 0 ) update_post_meta( $post_id, '_cul_assigned_user_id', $assigned );
        }

        // Save Preview-only toggle
        if ( isset( $_POST['cul_review_share_nonce'] ) && wp_verify_nonce( $_POST['cul_review_share_nonce'], 'cul_review_share' ) ) {
            update_post_meta( $post_id, '_cul_preview_only', empty( $_POST['cul_preview_only'] ) ? '0' : '1' );
        }

        // Save Reviewer contact
        if ( isset( $_POST['cul_review_reviewer_nonce'] ) && wp_verify_nonce( $_POST['cul_review_reviewer_nonce'], 'cul_review_reviewer' ) ) {
            update_post_meta( $post_id, '_cul_reviewer_name', sanitize_text_field( $_POST['cul_reviewer_name'] ?? '' ) );
            $email = sanitize_email( $_POST['cul_reviewer_email'] ?? '' );
            update_post_meta( $post_id, '_cul_reviewer_email', $email );
        }

        if ( ! isset( $_POST['cul_review_files_nonce'] ) ) return;
        if ( ! wp_verify_nonce( $_POST['cul_review_files_nonce'], 'cul_review_files' ) ) return;

        $payload = isset( $_POST['cul_files_payload'] ) ? wp_unslash( $_POST['cul_files_payload'] ) : '';
        $items   = json_decode( $payload, true );
        if ( ! is_array( $items ) ) return;

        global $wpdb;
        $table = $wpdb->prefix . 'cul_review_files';

        $keep_ids = [];
        $newly_added = [];
        foreach ( $items as $i => $item ) {
            $attachment_id = isset( $item['attachment_id'] ) ? (int) $item['attachment_id'] : 0;
            $url           = isset( $item['url'] ) ? esc_url_raw( $item['url'] ) : '';
            if ( ! $url && $attachment_id ) $url = wp_get_attachment_url( $attachment_id );
            if ( ! $url ) continue;
            $kind   = self::detect_kind( $item, $url );
            $label  = sanitize_text_field( $item['label'] ?? '' );
            $status = in_array( ( $item['status'] ?? 'pending' ), [ 'pending', 'approved', 'changes_requested', 'superseded' ], true ) ? $item['status'] : 'pending';
            $data = [
                'project_id'    => $post_id,
                'attachment_id' => $attachment_id ?: null,
                'kind'          => $kind,
                'label'         => $label,
                'url'           => $url,
                'status'        => $status,
                'sort_order'    => (int) ( $item['sort_order'] ?? $i ),
            ];
            $id = isset( $item['id'] ) ? (int) $item['id'] : 0;
            if ( $id > 0 ) {
                // Admin reset to Pending reopens the file: clear reviewer decisions
                // (the share page mode is driven by the reviewer's own decision, so
                // without this the page stays stuck in "changes requested").
                if ( $status === 'pending' ) {
                    $wpdb->delete( "{$wpdb->prefix}cul_review_decisions", [ 'file_id' => $id ] );
                    $data['approved_at'] = null;
                    $data['approved_by'] = '';
                }
                $wpdb->update( $table, $data, [ 'id' => $id ] );
                $keep_ids[] = $id;
                // If status was just set to superseded, auto-resolve any open pins
                if ( $status === 'superseded' ) {
                    $wpdb->update( "{$wpdb->prefix}cul_review_pins", [ 'status' => 'resolved' ], [ 'file_id' => $id, 'status' => 'open' ] );
                }
            } else {
                $wpdb->insert( $table, $data );
                $new_db_id = (int) $wpdb->insert_id;
                $keep_ids[] = $new_db_id;
                $newly_added[] = $new_db_id;
            }
        }

        // Delete files removed from the list
        $existing = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $table WHERE project_id = %d", $post_id ) );
        $to_delete = array_diff( array_map( 'intval', $existing ), $keep_ids );
        if ( $to_delete ) {
            $in = implode( ',', array_map( 'intval', $to_delete ) );
            $wpdb->query( "DELETE FROM $table WHERE id IN ($in)" );
            $wpdb->query( "DELETE FROM {$wpdb->prefix}cul_review_pins WHERE file_id IN ($in)" );
        }

        // Notify reviewer(s) once if anything was newly added
        if ( $newly_added ) {
            $latest = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM $table WHERE id = %d", end( $newly_added )
            ) );
            if ( $latest ) CUL_Review_Notify::on_new_revision( $post_id, $latest );
        }
    }

    private static function detect_kind( $item, $url ) {
        if ( ! empty( $item['kind'] ) ) return sanitize_key( $item['kind'] );
        $ext = strtolower( pathinfo( wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
        if ( in_array( $ext, [ 'mp4', 'webm', 'mov', 'm4v' ], true ) ) return 'video';
        if ( in_array( $ext, [ 'html', 'htm' ], true ) ) return 'html';
        if ( in_array( $ext, [ 'md', 'markdown' ], true ) ) return 'markdown';
        if ( $ext === 'txt' ) return 'text';
        if ( in_array( $ext, [ 'pdf' ], true ) ) return 'pdf';
        if ( in_array( $ext, [ 'jpg','jpeg','png','gif','webp','svg' ], true ) ) return 'image';
        return 'link';
    }
}
