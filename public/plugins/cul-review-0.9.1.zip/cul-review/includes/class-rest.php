<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class CUL_Review_REST {
    const NS = 'cul-review/v1';

    public static function register() {
        register_rest_route( self::NS, '/project/(?P<token>[A-Za-z0-9]+)', [
            'methods'  => 'GET',
            'callback' => [ __CLASS__, 'get_project' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( self::NS, '/pins', [
            'methods'  => 'POST',
            'callback' => [ __CLASS__, 'create_pin' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( self::NS, '/pins/(?P<id>\d+)', [
            'methods'  => 'PATCH',
            'callback' => [ __CLASS__, 'update_pin' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( self::NS, '/pins/(?P<id>\d+)', [
            'methods'  => 'DELETE',
            'callback' => [ __CLASS__, 'delete_pin' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( self::NS, '/comments', [
            'methods'  => 'POST',
            'callback' => [ __CLASS__, 'create_comment' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( self::NS, '/comments/(?P<id>\d+)', [
            'methods'  => 'DELETE',
            'callback' => [ __CLASS__, 'delete_comment' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( self::NS, '/comments/(?P<id>\d+)', [
            'methods'  => 'PATCH',
            'callback' => [ __CLASS__, 'update_comment' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( self::NS, '/files/(?P<id>\d+)/status', [
            'methods'  => 'POST',
            'callback' => [ __CLASS__, 'set_file_status' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( self::NS, '/files/(?P<id>\d+)/decision', [
            'methods'  => 'POST',
            'callback' => [ __CLASS__, 'submit_decision' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( self::NS, '/upload', [
            'methods'  => 'POST',
            'callback' => [ __CLASS__, 'upload_attachment' ],
            'permission_callback' => '__return_true',
        ] );
        register_rest_route( self::NS, '/quick-share', [
            'methods'  => 'POST',
            'callback' => [ __CLASS__, 'quick_share' ],
            'permission_callback' => function () { return is_user_logged_in() && current_user_can( 'edit_posts' ); },
        ] );
        register_rest_route( self::NS, '/files', [
            'methods'  => 'POST',
            'callback' => [ __CLASS__, 'admin_create_file' ],
            'permission_callback' => function () { return is_user_logged_in() && current_user_can( 'edit_posts' ); },
        ] );
        register_rest_route( self::NS, '/submit-review', [
            'methods'  => 'POST',
            'callback' => [ __CLASS__, 'submit_review' ],
            'permission_callback' => '__return_true',
        ] );
    }

    private static function load_project_by_token( $token ) {
        $project = CUL_Review_CPT::project_by_token( $token );
        if ( ! $project ) return new WP_Error( 'no_project', 'Not found', [ 'status' => 404 ] );
        return $project;
    }

    public static function get_project( $req ) {
        $project = self::load_project_by_token( $req['token'] );
        if ( is_wp_error( $project ) ) return $project;

        global $wpdb;
        $files = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, kind, label, url, status, approved_at, approved_by, created_at FROM {$wpdb->prefix}cul_review_files WHERE project_id = %d ORDER BY sort_order ASC, id ASC",
            $project->ID
        ) );
        $file_ids = wp_list_pluck( $files, 'id' );
        $pins = $comments = $decisions = [];
        if ( $file_ids ) {
            $in = implode( ',', array_map( 'intval', $file_ids ) );
            $pins = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}cul_review_pins WHERE file_id IN ($in) ORDER BY created_at ASC" );
            $decisions = $wpdb->get_results(
                "SELECT id, file_id, reviewer_key, reviewer_name, decision, created_at, updated_at
                 FROM {$wpdb->prefix}cul_review_decisions WHERE file_id IN ($in) ORDER BY updated_at ASC"
            );
            $pin_ids = wp_list_pluck( $pins, 'id' );
            if ( $pin_ids ) {
                $pin_in = implode( ',', array_map( 'intval', $pin_ids ) );
                $comments = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}cul_review_comments WHERE pin_id IN ($pin_in) ORDER BY created_at ASC" );
            }
        }
        return [
            'project'  => [ 'id' => $project->ID, 'title' => $project->post_title ],
            'files'    => $files,
            'pins'     => $pins,
            'comments' => $comments,
            'decisions'=> $decisions,
        ];
    }

    public static function submit_review( $req ) {
        $token = $req->get_param( 'token' );
        $project = self::load_project_by_token( $token );
        if ( is_wp_error( $project ) ) return $project;

        global $wpdb;
        $file_id = (int) $req->get_param( 'file_id' );
        $file = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}cul_review_files WHERE id = %d AND project_id = %d", $file_id, $project->ID
        ) );
        if ( ! $file ) return new WP_Error( 'no_file', 'File not found', [ 'status' => 404 ] );

        $author = sanitize_text_field( (string) $req->get_param( 'author_name' ) ) ?: 'Guest';
        $note   = trim( wp_strip_all_tags( (string) $req->get_param( 'note' ) ) );

        // If they left a final note, store it as a top-level pin (no coordinates)
        if ( $note !== '' ) {
            $next_num = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COALESCE(MAX(number),0)+1 FROM {$wpdb->prefix}cul_review_pins WHERE file_id = %d", $file_id
            ) );
            $wpdb->insert( "{$wpdb->prefix}cul_review_pins", [
                'file_id'     => $file_id,
                'project_id'  => $project->ID,
                'x_pct'       => null,
                'y_pct'       => null,
                't_seconds'   => null,
                'number'      => $next_num,
                'status'      => 'open',
                'author_name' => $author,
                'body'        => '[Submission note] ' . $note,
            ] );
        }

        CUL_Review_Notify::on_review_submitted( $project->ID, $file, $author, $note );

        return [ 'ok' => true ];
    }

    public static function admin_create_file( $req ) {
        $token = $req->get_param( 'token' );
        $project = self::load_project_by_token( $token );
        if ( is_wp_error( $project ) ) return $project;

        $url = esc_url_raw( (string) $req->get_param( 'url' ) );
        if ( ! $url ) return new WP_Error( 'no_url', 'URL required', [ 'status' => 400 ] );

        $kind  = sanitize_key( (string) $req->get_param( 'kind' ) ) ?: self::detect_kind_from_url( $url );
        $label = sanitize_text_field( (string) $req->get_param( 'label' ) );
        $attachment_id = (int) $req->get_param( 'attachment_id' );
        $supersede_id  = (int) $req->get_param( 'supersede_file_id' );

        global $wpdb;
        $table = $wpdb->prefix . 'cul_review_files';

        // Auto-label as "Version N" if not provided
        if ( $label === '' ) {
            $existing_labels = $wpdb->get_col( $wpdb->prepare(
                "SELECT label FROM $table WHERE project_id = %d", $project->ID
            ) );
            $max = 0;
            foreach ( $existing_labels as $lbl ) {
                if ( preg_match( '/^Version\s+(\d+)$/i', trim( $lbl ), $m ) ) {
                    $max = max( $max, (int) $m[1] );
                }
            }
            $label = 'Version ' . ( $max + 1 );
        }

        // Shift sort_order down so new file goes to top
        $wpdb->query( $wpdb->prepare(
            "UPDATE $table SET sort_order = sort_order + 1 WHERE project_id = %d", $project->ID
        ) );

        $wpdb->insert( $table, [
            'project_id'    => $project->ID,
            'attachment_id' => $attachment_id ?: null,
            'kind'          => $kind,
            'label'         => $label,
            'url'           => $url,
            'status'        => 'pending',
            'sort_order'    => 0,
        ] );
        $new_id = (int) $wpdb->insert_id;

        if ( $supersede_id > 0 ) {
            $wpdb->update( $table, [ 'status' => 'superseded' ], [ 'id' => $supersede_id, 'project_id' => $project->ID ] );
            $wpdb->update( "{$wpdb->prefix}cul_review_pins", [ 'status' => 'resolved' ], [ 'file_id' => $supersede_id, 'status' => 'open' ] );
        }

        $new_file = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $new_id ) );
        $notify = $req->get_param( 'notify' );
        if ( $notify === null || (int) $notify === 1 ) {
            CUL_Review_Notify::on_new_revision( $project->ID, $new_file, $supersede_id );
        }
        return $new_file;
    }

    private static function detect_kind_from_url( $url ) {
        $ext = strtolower( pathinfo( wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
        if ( in_array( $ext, [ 'mp4', 'webm', 'mov', 'm4v' ], true ) ) return 'video';
        if ( in_array( $ext, [ 'html', 'htm' ], true ) ) return 'html';
        if ( in_array( $ext, [ 'md', 'markdown' ], true ) ) return 'markdown';
        if ( $ext === 'txt' ) return 'text';
        if ( $ext === 'pdf' ) return 'pdf';
        if ( in_array( $ext, [ 'jpg','jpeg','png','gif','webp','svg' ], true ) ) return 'image';
        return 'link';
    }

    public static function upload_attachment( $req ) {
        $token = $req->get_param( 'token' );
        $project = self::load_project_by_token( $token );
        if ( is_wp_error( $project ) ) return $project;

        $files = $req->get_file_params();
        if ( empty( $files['file'] ) ) return new WP_Error( 'no_file', 'No file uploaded', [ 'status' => 400 ] );

        $allow_staff = is_user_logged_in() && current_user_can( 'edit_posts' );
        return self::store_uploaded_file( $files['file'], $project->ID, $allow_staff );
    }

    /**
     * Move an uploaded file into place and return its public URL + mime.
     * Zip bundles are extracted and the HTML entry point is served instead.
     * $allow_staff_types unlocks the richer mime set (video, pdf, html, md, txt)
     * and zip extraction; anonymous callers are limited to plain image types.
     */
    private static function store_uploaded_file( $file, $project_id, $allow_staff_types ) {
        $ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
        if ( $ext === 'zip' ) {
            if ( ! $allow_staff_types ) {
                return new WP_Error( 'forbidden', 'Zip uploads require staff access', [ 'status' => 403 ] );
            }
            return self::handle_zip_upload( $file, $project_id );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $allowed = [
            'jpg|jpeg|jpe' => 'image/jpeg',
            'png'          => 'image/png',
            'gif'          => 'image/gif',
            'webp'         => 'image/webp',
            'svg'          => 'image/svg+xml',
        ];
        if ( $allow_staff_types ) {
            $allowed += [
                'mp4'      => 'video/mp4',
                'webm'     => 'video/webm',
                'mov'      => 'video/quicktime',
                'pdf'      => 'application/pdf',
                'html|htm' => 'text/html',
                'md'       => 'text/markdown',
                'txt'      => 'text/plain',
            ];
        }
        $overrides = [
            'test_form' => false,
            'mimes'     => $allowed,
        ];

        $uploaded = wp_handle_upload( $file, $overrides );
        if ( isset( $uploaded['error'] ) ) {
            return new WP_Error( 'upload_failed', $uploaded['error'], [ 'status' => 400 ] );
        }

        return [
            'url'  => $uploaded['url'],
            'mime' => $uploaded['type'],
        ];
    }

    /**
     * One-step share: take an uploaded file, spin up a published, preview-only
     * project named after the file, attach the file, and hand back the public
     * /r/{token} link. Powers the "Quick Share" admin page.
     */
    public static function quick_share( $req ) {
        $files = $req->get_file_params();
        if ( empty( $files['file'] ) ) return new WP_Error( 'no_file', 'No file uploaded', [ 'status' => 400 ] );

        $title = self::title_from_filename( $files['file']['name'] );

        // Create the project up front so the upload (and any zip extraction) has
        // a home; roll it back if the upload fails so we never leave an empty shell.
        $project_id = wp_insert_post( [
            'post_type'   => CUL_Review_CPT::POST_TYPE,
            'post_title'  => $title,
            'post_status' => 'publish',
            'post_author' => get_current_user_id(),
        ], true );
        if ( is_wp_error( $project_id ) ) {
            return new WP_Error( 'no_project', 'Could not create project: ' . $project_id->get_error_message(), [ 'status' => 500 ] );
        }
        update_post_meta( $project_id, '_cul_preview_only', '1' );
        update_post_meta( $project_id, '_cul_assigned_user_id', get_current_user_id() );
        $token = CUL_Review_CPT::ensure_token( $project_id );

        $stored = self::store_uploaded_file( $files['file'], $project_id, true );
        if ( is_wp_error( $stored ) ) {
            wp_delete_post( $project_id, true );
            return $stored;
        }

        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'cul_review_files', [
            'project_id' => $project_id,
            'kind'       => self::detect_kind_from_url( $stored['url'] ),
            'label'      => 'Version 1',
            'url'        => $stored['url'],
            'status'     => 'pending',
            'sort_order' => 0,
        ] );

        return [
            'ok'        => true,
            'share_url' => home_url( '/r/' . $token ),
            'edit_url'  => get_edit_post_link( $project_id, 'raw' ),
            'title'     => get_the_title( $project_id ),
        ];
    }

    /**
     * Turn an uploaded filename into a readable project title:
     * "homepage-mockup_v2.html" -> "Homepage Mockup V2".
     */
    private static function title_from_filename( $name ) {
        $base = pathinfo( (string) $name, PATHINFO_FILENAME );
        $base = trim( preg_replace( '/\s+/', ' ', preg_replace( '/[-_]+/', ' ', $base ) ) );
        if ( $base === '' ) $base = 'Shared file';
        return ucwords( $base );
    }

    public static function create_pin( $req ) {
        $token = $req->get_param( 'token' );
        $project = self::load_project_by_token( $token );
        if ( is_wp_error( $project ) ) return $project;

        global $wpdb;
        $file_id = (int) $req->get_param( 'file_id' );
        $file = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}cul_review_files WHERE id = %d AND project_id = %d",
            $file_id, $project->ID
        ) );
        if ( ! $file ) return new WP_Error( 'no_file', 'File not found', [ 'status' => 404 ] );

        $body = trim( wp_strip_all_tags( (string) $req->get_param( 'body' ) ) );
        if ( $body === '' ) return new WP_Error( 'empty', 'Comment required', [ 'status' => 400 ] );

        $author = sanitize_text_field( substr( (string) $req->get_param( 'author_name' ), 0, 190 ) );
        if ( $author === '' ) $author = 'Guest';
        $author_email = sanitize_email( (string) $req->get_param( 'author_email' ) );

        $x = $req->get_param( 'x_pct' ); $y = $req->get_param( 'y_pct' ); $t = $req->get_param( 't_seconds' );
        $x = ( $x === null || $x === '' ) ? null : max( 0, min( 100, (float) $x ) );
        $y = ( $y === null || $y === '' ) ? null : max( 0, min( 100, (float) $y ) );
        $t = ( $t === null || $t === '' ) ? null : max( 0, (float) $t );

        $next_num = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(MAX(number),0)+1 FROM {$wpdb->prefix}cul_review_pins WHERE file_id = %d", $file_id
        ) );

        $attachment_url = esc_url_raw( (string) $req->get_param( 'attachment_url' ) );
        if ( $attachment_url === '' ) $attachment_url = null;

        $wpdb->insert( "{$wpdb->prefix}cul_review_pins", [
            'file_id'        => $file_id,
            'project_id'     => $project->ID,
            'x_pct'          => $x,
            'y_pct'          => $y,
            't_seconds'      => $t,
            'number'         => $next_num,
            'status'         => 'open',
            'author_name'    => $author,
            'author_email'   => $author_email,
            'body'           => $body,
            'attachment_url' => $attachment_url,
        ] );
        $id = (int) $wpdb->insert_id;

        // Dropping a pin registers this reviewer's decision as "changes requested"
        $key = $author_email ? strtolower( $author_email ) : ( $author ? 'name:' . strtolower( $author ) : '' );
        if ( $key ) {
            $dtable = $wpdb->prefix . 'cul_review_decisions';
            $existing = $wpdb->get_row( $wpdb->prepare(
                "SELECT id FROM $dtable WHERE file_id = %d AND reviewer_key = %s", $file_id, $key
            ) );
            if ( $existing ) {
                $wpdb->update( $dtable, [
                    'decision'       => 'changes_requested',
                    'reviewer_name'  => $author,
                    'reviewer_email' => $author_email,
                    'updated_at'     => current_time( 'mysql' ),
                ], [ 'id' => $existing->id ] );
            } else {
                $wpdb->insert( $dtable, [
                    'file_id'        => $file_id,
                    'project_id'     => $project->ID,
                    'reviewer_key'   => $key,
                    'reviewer_name'  => $author,
                    'reviewer_email' => $author_email,
                    'decision'       => 'changes_requested',
                ] );
            }
        }
        $fresh = self::recompute_file_status( $file_id );

        $pin = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cul_review_pins WHERE id = %d", $id ) );
        $pin->file_status = $fresh ? $fresh->status : 'changes_requested';
        $pin->decisions = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, file_id, reviewer_key, reviewer_name, decision, created_at, updated_at
             FROM {$wpdb->prefix}cul_review_decisions WHERE file_id = %d ORDER BY updated_at ASC", $file_id
        ) );
        return $pin;
    }

    public static function update_pin( $req ) {
        $token = $req->get_param( 'token' );
        $project = self::load_project_by_token( $token );
        if ( is_wp_error( $project ) ) return $project;

        global $wpdb;
        $id = (int) $req['id'];
        $pin = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}cul_review_pins WHERE id = %d AND project_id = %d", $id, $project->ID
        ) );
        if ( ! $pin ) return new WP_Error( 'no_pin', 'Not found', [ 'status' => 404 ] );

        $update = [];
        $status = $req->get_param( 'status' );
        if ( $status !== null ) {
            if ( ! in_array( $status, [ 'open', 'resolved' ], true ) ) {
                return new WP_Error( 'bad_status', 'Bad status', [ 'status' => 400 ] );
            }
            $update['status'] = $status;
        }
        $body = $req->get_param( 'body' );
        if ( $body !== null ) {
            $body = trim( wp_strip_all_tags( (string) $body ) );
            if ( $body === '' ) return new WP_Error( 'empty', 'Comment cannot be empty', [ 'status' => 400 ] );
            $update['body'] = $body;
        }
        if ( ! $update ) return new WP_Error( 'no_op', 'Nothing to update', [ 'status' => 400 ] );
        $wpdb->update( "{$wpdb->prefix}cul_review_pins", $update, [ 'id' => $id ] );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cul_review_pins WHERE id = %d", $id ) );
    }

    public static function update_comment( $req ) {
        $token = $req->get_param( 'token' );
        $project = self::load_project_by_token( $token );
        if ( is_wp_error( $project ) ) return $project;

        global $wpdb;
        $id = (int) $req['id'];
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT c.* FROM {$wpdb->prefix}cul_review_comments c
             INNER JOIN {$wpdb->prefix}cul_review_pins p ON p.id = c.pin_id
             WHERE c.id = %d AND p.project_id = %d", $id, $project->ID
        ) );
        if ( ! $row ) return new WP_Error( 'no_comment', 'Not found', [ 'status' => 404 ] );

        $body = trim( wp_strip_all_tags( (string) $req->get_param( 'body' ) ) );
        if ( $body === '' ) return new WP_Error( 'empty', 'Reply cannot be empty', [ 'status' => 400 ] );
        $wpdb->update( "{$wpdb->prefix}cul_review_comments", [ 'body' => $body ], [ 'id' => $id ] );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cul_review_comments WHERE id = %d", $id ) );
    }

    public static function delete_pin( $req ) {
        $token = $req->get_param( 'token' );
        $project = self::load_project_by_token( $token );
        if ( is_wp_error( $project ) ) return $project;

        global $wpdb;
        $id = (int) $req['id'];
        $pin = $wpdb->get_row( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}cul_review_pins WHERE id = %d AND project_id = %d", $id, $project->ID
        ) );
        if ( ! $pin ) return new WP_Error( 'no_pin', 'Not found', [ 'status' => 404 ] );
        $wpdb->delete( "{$wpdb->prefix}cul_review_comments", [ 'pin_id' => $id ] );
        $wpdb->delete( "{$wpdb->prefix}cul_review_pins", [ 'id' => $id ] );
        return [ 'ok' => true, 'deleted_pin' => $id ];
    }

    public static function delete_comment( $req ) {
        $token = $req->get_param( 'token' );
        $project = self::load_project_by_token( $token );
        if ( is_wp_error( $project ) ) return $project;

        global $wpdb;
        $id = (int) $req['id'];
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT c.id FROM {$wpdb->prefix}cul_review_comments c
             INNER JOIN {$wpdb->prefix}cul_review_pins p ON p.id = c.pin_id
             WHERE c.id = %d AND p.project_id = %d", $id, $project->ID
        ) );
        if ( ! $row ) return new WP_Error( 'no_comment', 'Not found', [ 'status' => 404 ] );
        $wpdb->delete( "{$wpdb->prefix}cul_review_comments", [ 'id' => $id ] );
        return [ 'ok' => true, 'deleted_comment' => $id ];
    }

    public static function create_comment( $req ) {
        $token = $req->get_param( 'token' );
        $project = self::load_project_by_token( $token );
        if ( is_wp_error( $project ) ) return $project;

        global $wpdb;
        $pin_id = (int) $req->get_param( 'pin_id' );
        $pin = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}cul_review_pins WHERE id = %d AND project_id = %d", $pin_id, $project->ID
        ) );
        if ( ! $pin ) return new WP_Error( 'no_pin', 'Pin not found', [ 'status' => 404 ] );

        $body = trim( wp_strip_all_tags( (string) $req->get_param( 'body' ) ) );
        if ( $body === '' ) return new WP_Error( 'empty', 'Comment required', [ 'status' => 400 ] );

        $author = sanitize_text_field( substr( (string) $req->get_param( 'author_name' ), 0, 190 ) );
        if ( $author === '' ) $author = 'Guest';

        $wpdb->insert( "{$wpdb->prefix}cul_review_comments", [
            'pin_id'      => $pin_id,
            'author_name' => $author,
            'body'        => $body,
            'is_staff'    => is_user_logged_in() && current_user_can( 'edit_posts' ) ? 1 : 0,
        ] );
        $id = (int) $wpdb->insert_id;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cul_review_comments WHERE id = %d", $id ) );
    }

    /**
     * Recompute a file's rolled-up status from its per-reviewer decisions.
     * Any "changes_requested" wins; else any "approved" → approved; else pending.
     * A superseded file is left untouched (admin-set).
     */
    public static function recompute_file_status( $file_id ) {
        global $wpdb;
        $file = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cul_review_files WHERE id = %d", $file_id ) );
        if ( ! $file ) return null;
        if ( $file->status === 'superseded' ) return $file;

        $decisions = $wpdb->get_results( $wpdb->prepare(
            "SELECT decision FROM {$wpdb->prefix}cul_review_decisions WHERE file_id = %d", $file_id
        ) );
        $has_changes = false; $has_approved = false;
        foreach ( $decisions as $d ) {
            if ( $d->decision === 'changes_requested' ) $has_changes = true;
            if ( $d->decision === 'approved' ) $has_approved = true;
        }
        $status = $has_changes ? 'changes_requested' : ( $has_approved ? 'approved' : 'pending' );

        $data = [ 'status' => $status ];
        if ( $status === 'approved' ) {
            $latest = $wpdb->get_row( $wpdb->prepare(
                "SELECT reviewer_name, updated_at FROM {$wpdb->prefix}cul_review_decisions
                 WHERE file_id = %d AND decision = 'approved' ORDER BY updated_at DESC LIMIT 1", $file_id
            ) );
            $data['approved_at'] = $latest ? $latest->updated_at : current_time( 'mysql' );
            $data['approved_by'] = $latest ? $latest->reviewer_name : '';
        } else {
            $data['approved_at'] = null;
            $data['approved_by'] = '';
        }
        $wpdb->update( "{$wpdb->prefix}cul_review_files", $data, [ 'id' => $file_id ] );
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cul_review_files WHERE id = %d", $file_id ) );
    }

    public static function submit_decision( $req ) {
        $token = $req->get_param( 'token' );
        $project = self::load_project_by_token( $token );
        if ( is_wp_error( $project ) ) return $project;

        global $wpdb;
        $id = (int) $req['id'];
        $file = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}cul_review_files WHERE id = %d AND project_id = %d", $id, $project->ID
        ) );
        if ( ! $file ) return new WP_Error( 'no_file', 'File not found', [ 'status' => 404 ] );

        $decision = $req->get_param( 'decision' );
        if ( ! in_array( $decision, [ 'approved', 'changes_requested', 'none' ], true ) ) {
            return new WP_Error( 'bad_decision', 'Bad decision', [ 'status' => 400 ] );
        }

        $name  = sanitize_text_field( substr( (string) $req->get_param( 'reviewer_name' ), 0, 190 ) );
        $email = sanitize_email( (string) $req->get_param( 'reviewer_email' ) );
        $key   = $email ? strtolower( $email ) : ( $name ? 'name:' . strtolower( $name ) : '' );
        if ( $key === '' ) return new WP_Error( 'no_identity', 'Reviewer name required', [ 'status' => 400 ] );

        $table = $wpdb->prefix . 'cul_review_decisions';
        $existing = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM $table WHERE file_id = %d AND reviewer_key = %s", $id, $key
        ) );
        $prev = $existing ? $existing->decision : null;

        if ( $decision === 'none' ) {
            if ( $existing ) $wpdb->delete( $table, [ 'id' => $existing->id ] );
        } elseif ( $existing ) {
            $wpdb->update( $table, [
                'decision'       => $decision,
                'reviewer_name'  => $name ?: 'Guest',
                'reviewer_email' => $email,
                'updated_at'     => current_time( 'mysql' ),
            ], [ 'id' => $existing->id ] );
        } else {
            $wpdb->insert( $table, [
                'file_id'        => $id,
                'project_id'     => $project->ID,
                'reviewer_key'   => $key,
                'reviewer_name'  => $name ?: 'Guest',
                'reviewer_email' => $email,
                'decision'       => $decision,
            ] );
        }

        $fresh = self::recompute_file_status( $id );

        // Notify the assigned admin only when a reviewer makes a NEW or CHANGED decision
        $is_admin_actor = is_user_logged_in() && current_user_can( 'edit_posts' );
        if ( ! $is_admin_actor && $decision !== 'none' && $decision !== $prev ) {
            if ( $decision === 'approved' ) {
                CUL_Review_Notify::on_file_approved( $project->ID, $fresh );
            } else {
                CUL_Review_Notify::on_file_changes_requested( $project->ID, $fresh, $name );
            }
        }

        $decisions = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, file_id, reviewer_key, reviewer_name, decision, created_at, updated_at
             FROM $table WHERE file_id = %d ORDER BY updated_at ASC", $id
        ) );

        return [
            'ok'          => true,
            'file_status' => $fresh->status,
            'approved_at' => $fresh->approved_at,
            'approved_by' => $fresh->approved_by,
            'decisions'   => $decisions,
        ];
    }

    public static function set_file_status( $req ) {
        $token = $req->get_param( 'token' );
        $project = self::load_project_by_token( $token );
        if ( is_wp_error( $project ) ) return $project;

        global $wpdb;
        $id = (int) $req['id'];
        $status = $req->get_param( 'status' );
        if ( ! in_array( $status, [ 'pending', 'approved', 'changes_requested', 'superseded' ], true ) ) {
            return new WP_Error( 'bad_status', 'Bad status', [ 'status' => 400 ] );
        }
        $file = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}cul_review_files WHERE id = %d AND project_id = %d", $id, $project->ID
        ) );
        if ( ! $file ) return new WP_Error( 'no_file', 'Not found', [ 'status' => 404 ] );

        $data = [ 'status' => $status ];
        if ( $status === 'superseded' ) {
            // Auto-resolve any open pins on this file so they stop showing in counts
            $wpdb->update( "{$wpdb->prefix}cul_review_pins", [ 'status' => 'resolved' ], [ 'file_id' => $id, 'status' => 'open' ] );
        }
        $approved_at = null;
        $approved_by = '';
        if ( $status === 'approved' ) {
            $approved_by = sanitize_text_field( substr( (string) $req->get_param( 'author_name' ), 0, 190 ) );
            if ( $approved_by === '' ) $approved_by = 'Guest';
            $approved_at = current_time( 'mysql' );
            $data['approved_at'] = $approved_at;
            $data['approved_by'] = $approved_by;
        } else {
            $data['approved_at'] = null;
            $data['approved_by'] = '';
        }
        $wpdb->update( "{$wpdb->prefix}cul_review_files", $data, [ 'id' => $id ] );

        // Notify assigned admin (only on client-driven status changes, not when admin themselves is the actor)
        $is_admin_actor = is_user_logged_in() && current_user_can( 'edit_posts' );
        if ( ! $is_admin_actor ) {
            $fresh = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}cul_review_files WHERE id = %d", $id ) );
            if ( $status === 'approved' ) {
                CUL_Review_Notify::on_file_approved( $project->ID, $fresh );
            } elseif ( $status === 'changes_requested' && $file->status !== 'changes_requested' ) {
                $actor = sanitize_text_field( (string) $req->get_param( 'author_name' ) );
                CUL_Review_Notify::on_file_changes_requested( $project->ID, $fresh, $actor );
            }
        }

        return [
            'ok'          => true,
            'status'      => $status,
            'approved_at' => $approved_at,
            'approved_by' => $approved_by,
        ];
    }

    private static function handle_zip_upload( $file, $project_id ) {
        if ( ! class_exists( 'ZipArchive' ) ) {
            return new WP_Error( 'no_zip', 'ZipArchive is not available on this server', [ 'status' => 500 ] );
        }

        $zip = new ZipArchive();
        if ( $zip->open( $file['tmp_name'] ) !== true ) {
            return new WP_Error( 'bad_zip', 'Could not open zip file', [ 'status' => 400 ] );
        }

        // Reject path traversal
        for ( $i = 0; $i < $zip->numFiles; $i++ ) {
            $name = $zip->getNameIndex( $i );
            if ( strpos( $name, '..' ) !== false ) {
                $zip->close();
                return new WP_Error( 'bad_zip', 'Zip contains invalid paths', [ 'status' => 400 ] );
            }
        }

        $upload   = wp_upload_dir();
        $dest_dir = $upload['basedir'] . '/cul-review/' . (int) $project_id . '/' . wp_generate_uuid4();
        wp_mkdir_p( $dest_dir );

        $zip->extractTo( $dest_dir );
        $zip->close();

        $entry = self::find_html_entry( $dest_dir );
        if ( ! $entry ) {
            self::rmdir_recursive( $dest_dir );
            return new WP_Error( 'no_html', 'No HTML file found in zip', [ 'status' => 400 ] );
        }

        $rel_path  = ltrim( str_replace( $upload['basedir'], '', $entry ), '/' );
        $entry_url = $upload['baseurl'] . '/' . $rel_path;

        return [
            'url'  => $entry_url,
            'mime' => 'text/html',
        ];
    }

    private static function find_html_entry( $dir ) {
        // Root index.html
        foreach ( [ 'index.html', 'index.htm' ] as $f ) {
            if ( file_exists( $dir . '/' . $f ) ) return $dir . '/' . $f;
        }
        // Single top-level subfolder (common when zipping a folder)
        $items = array_values( array_diff( scandir( $dir ), [ '.', '..' ] ) );
        if ( count( $items ) === 1 && is_dir( $dir . '/' . $items[0] ) ) {
            $sub      = $dir . '/' . $items[0];
            $subitems = array_values( array_diff( scandir( $sub ), [ '.', '..' ] ) );
            foreach ( [ 'index.html', 'index.htm' ] as $f ) {
                if ( file_exists( $sub . '/' . $f ) ) return $sub . '/' . $f;
            }
            foreach ( $subitems as $item ) {
                if ( preg_match( '/\.html?$/i', $item ) && is_file( $sub . '/' . $item ) ) return $sub . '/' . $item;
            }
        }
        // First .html at root
        foreach ( $items as $item ) {
            if ( preg_match( '/\.html?$/i', $item ) && is_file( $dir . '/' . $item ) ) return $dir . '/' . $item;
        }
        return null;
    }

    private static function rmdir_recursive( $dir ) {
        foreach ( scandir( $dir ) as $item ) {
            if ( $item === '.' || $item === '..' ) continue;
            $path = $dir . '/' . $item;
            is_dir( $path ) ? self::rmdir_recursive( $path ) : unlink( $path );
        }
        rmdir( $dir );
    }
}
