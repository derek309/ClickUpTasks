<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class CUL_Review_Activator {

    /**
     * One-time reconciliation for sites upgrading from the pre-0.6.0 single-status model.
     * Backfills per-reviewer decisions from existing pins / approved files, then
     * recomputes every file's rolled-up status so it can't drift from reality.
     */
    public static function maybe_migrate_decisions() {
        if ( get_option( 'cul_review_decisions_migrated' ) ) return;
        global $wpdb;
        $pins_t  = $wpdb->prefix . 'cul_review_pins';
        $dec_t   = $wpdb->prefix . 'cul_review_decisions';
        $files_t = $wpdb->prefix . 'cul_review_files';

        // Tables may not exist yet on a brand-new install — activate() creates them; bail safely.
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$dec_t'" ) !== $dec_t ) return;

        // Backfill "changes requested" decisions from existing pins
        $pins = $wpdb->get_results( "SELECT file_id, project_id, author_name, author_email FROM $pins_t" );
        foreach ( $pins as $p ) {
            $name  = $p->author_name;
            $email = $p->author_email;
            $key   = $email ? strtolower( $email ) : ( $name ? 'name:' . strtolower( $name ) : '' );
            if ( ! $key ) continue;
            $exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM $dec_t WHERE file_id = %d AND reviewer_key = %s", $p->file_id, $key
            ) );
            if ( ! $exists ) {
                $wpdb->insert( $dec_t, [
                    'file_id'        => $p->file_id,
                    'project_id'     => $p->project_id,
                    'reviewer_key'   => $key,
                    'reviewer_name'  => $name ?: 'Guest',
                    'reviewer_email' => $email ?: '',
                    'decision'       => 'changes_requested',
                ] );
            }
        }

        // Backfill "approved" decisions for files marked approved that have no decisions yet
        $approved = $wpdb->get_results( "SELECT id, project_id, approved_by FROM $files_t WHERE status = 'approved'" );
        foreach ( $approved as $af ) {
            $any = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $dec_t WHERE file_id = %d", $af->id ) );
            if ( $any ) continue;
            $name = $af->approved_by ?: 'Guest';
            $wpdb->insert( $dec_t, [
                'file_id'        => $af->id,
                'project_id'     => $af->project_id,
                'reviewer_key'   => 'name:' . strtolower( $name ),
                'reviewer_name'  => $name,
                'reviewer_email' => '',
                'decision'       => 'approved',
            ] );
        }

        // Recompute every file's rolled-up status from the (now backfilled) decisions
        $all = $wpdb->get_col( "SELECT id FROM $files_t" );
        foreach ( $all as $fid ) {
            if ( class_exists( 'CUL_Review_REST' ) ) {
                CUL_Review_REST::recompute_file_status( (int) $fid );
            }
        }

        update_option( 'cul_review_decisions_migrated', 1 );
    }

    public static function activate() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $p = $wpdb->prefix;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Files attached to a project
        dbDelta( "CREATE TABLE {$p}cul_review_files (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            project_id bigint(20) unsigned NOT NULL,
            attachment_id bigint(20) unsigned DEFAULT NULL,
            kind varchar(20) NOT NULL DEFAULT 'image',
            label varchar(190) NOT NULL DEFAULT '',
            url text NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'pending',
            sort_order int(11) NOT NULL DEFAULT 0,
            approved_at datetime NULL,
            approved_by varchar(190) NOT NULL DEFAULT '',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY project_id (project_id)
        ) $charset;" );

        // Pins (anchored comments)
        dbDelta( "CREATE TABLE {$p}cul_review_pins (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            file_id bigint(20) unsigned NOT NULL,
            project_id bigint(20) unsigned NOT NULL,
            x_pct decimal(6,3) DEFAULT NULL,
            y_pct decimal(6,3) DEFAULT NULL,
            t_seconds decimal(10,3) DEFAULT NULL,
            number int(11) NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'open',
            author_name varchar(190) NOT NULL DEFAULT '',
            author_email varchar(190) NOT NULL DEFAULT '',
            body text NOT NULL,
            attachment_url text NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY file_id (file_id),
            KEY project_id (project_id)
        ) $charset;" );

        // Per-reviewer approve / request-changes decisions on a file
        dbDelta( "CREATE TABLE {$p}cul_review_decisions (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            file_id bigint(20) unsigned NOT NULL,
            project_id bigint(20) unsigned NOT NULL,
            reviewer_key varchar(190) NOT NULL DEFAULT '',
            reviewer_name varchar(190) NOT NULL DEFAULT '',
            reviewer_email varchar(190) NOT NULL DEFAULT '',
            decision varchar(20) NOT NULL DEFAULT 'approved',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY file_reviewer (file_id, reviewer_key),
            KEY project_id (project_id)
        ) $charset;" );

        // Replies on a pin
        dbDelta( "CREATE TABLE {$p}cul_review_comments (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            pin_id bigint(20) unsigned NOT NULL,
            author_name varchar(190) NOT NULL DEFAULT '',
            body text NOT NULL,
            is_staff tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY pin_id (pin_id)
        ) $charset;" );
    }
}
