<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class CUL_Review_Public {

    public static function add_rewrite() {
        add_rewrite_rule( '^r/([A-Za-z0-9]+)/?$', 'index.php?cul_review_token=$matches[1]', 'top' );
        add_rewrite_rule( '^c/([A-Za-z0-9_-]+)/?$', 'index.php?cul_client_slug=$matches[1]', 'top' );
    }

    public static function query_vars( $vars ) {
        $vars[] = 'cul_review_token';
        $vars[] = 'cul_client_slug';
        return $vars;
    }

    public static function maybe_render() {
        $client_slug = get_query_var( 'cul_client_slug' );
        if ( $client_slug ) {
            self::render_client_index( $client_slug );
            exit;
        }
        $token = get_query_var( 'cul_review_token' );
        if ( ! $token ) return;
        $project = CUL_Review_CPT::project_by_token( $token );
        if ( ! $project ) {
            status_header( 404 );
            nocache_headers();
            include CUL_REVIEW_PATH . 'templates/not-found.php';
            exit;
        }
        self::render( $project, $token );
        exit;
    }

    private static function render_client_index( $slug ) {
        nocache_headers();
        header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
        header( 'Pragma: no-cache' );
        $term = get_term_by( 'slug', $slug, CUL_Review_CPT::TAX_CLIENT );
        if ( ! $term ) {
            status_header( 404 );
            nocache_headers();
            include CUL_REVIEW_PATH . 'templates/not-found.php';
            return;
        }

        $projects = get_posts( [
            'post_type'      => CUL_Review_CPT::POST_TYPE,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'tax_query'      => [ [
                'taxonomy' => CUL_Review_CPT::TAX_CLIENT,
                'field'    => 'term_id',
                'terms'    => $term->term_id,
            ] ],
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ] );

        global $wpdb;
        $rows = [];
        foreach ( $projects as $p ) {
            $token   = CUL_Review_CPT::ensure_token( $p->ID );
            $counts  = $wpdb->get_results( $wpdb->prepare(
                "SELECT status, COUNT(*) c FROM {$wpdb->prefix}cul_review_files WHERE project_id = %d GROUP BY status",
                $p->ID
            ), OBJECT_K );
            $pending   = isset( $counts['pending'] ) ? (int) $counts['pending']->c : 0;
            $changes   = isset( $counts['changes_requested'] ) ? (int) $counts['changes_requested']->c : 0;
            $approved  = isset( $counts['approved'] ) ? (int) $counts['approved']->c : 0;
            $total     = $pending + $changes + $approved;
            $open_pins = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}cul_review_pins WHERE project_id = %d AND status = 'open'", $p->ID
            ) );

            // Latest file (top of the sort order) for the thumbnail
            $latest = $wpdb->get_row( $wpdb->prepare(
                "SELECT kind, url FROM {$wpdb->prefix}cul_review_files WHERE project_id = %d ORDER BY sort_order ASC, id ASC LIMIT 1",
                $p->ID
            ) );

            // Priority: changes_requested first, then pending, then approved
            $priority = $changes > 0 ? 0 : ( $pending > 0 ? 1 : 2 );

            $rows[] = [
                'priority' => $priority,
                'title'    => $p->post_title,
                'url'      => home_url( '/r/' . $token ),
                'modified' => $p->post_modified,
                'total'    => $total,
                'pending'  => $pending,
                'changes'  => $changes,
                'approved' => $approved,
                'open_pins'=> $open_pins,
                'thumb_url'  => $latest ? $latest->url : '',
                'thumb_kind' => $latest ? $latest->kind : '',
            ];
        }
        usort( $rows, function ( $a, $b ) {
            if ( $a['priority'] !== $b['priority'] ) return $a['priority'] - $b['priority'];
            return strcmp( $b['modified'], $a['modified'] );
        } );

        $client = $term;
        include CUL_REVIEW_PATH . 'templates/client-index.php';
    }

    private static function render( $project, $token ) {
        nocache_headers();
        header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
        header( 'Pragma: no-cache' );
        global $wpdb;
        $files = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, kind, label, url, status, approved_at, approved_by, created_at FROM {$wpdb->prefix}cul_review_files WHERE project_id = %d ORDER BY sort_order ASC, id ASC",
            $project->ID
        ) );
        $pins = $comments = $decisions = [];
        $file_ids = wp_list_pluck( $files, 'id' );
        if ( $file_ids ) {
            $in = implode( ',', array_map( 'intval', $file_ids ) );
            $pins = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}cul_review_pins WHERE file_id IN ($in) ORDER BY created_at ASC" );
            $decisions = $wpdb->get_results(
                "SELECT id, file_id, reviewer_key, reviewer_name, decision, created_at, updated_at
                 FROM {$wpdb->prefix}cul_review_decisions WHERE file_id IN ($in) ORDER BY updated_at ASC"
            );
            $pin_ids = wp_list_pluck( $pins, 'id' );
            if ( $pin_ids ) {
                $pin_in = implode( ',', array_map( 'intval', $pin_ids ) );
                $comments = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}cul_review_comments WHERE pin_id IN ($pin_in) ORDER BY created_at ASC" );
            }
        }

        $client = null;
        $client_terms = wp_get_post_terms( $project->ID, CUL_Review_CPT::TAX_CLIENT );
        if ( $client_terms && ! is_wp_error( $client_terms ) ) {
            $t = $client_terms[0];
            $client = [
                'name' => $t->name,
                'slug' => $t->slug,
                'url'  => home_url( '/c/' . $t->slug ),
            ];
        }

        $is_admin = is_user_logged_in() && current_user_can( 'edit_posts' );
        $current_user = $is_admin ? wp_get_current_user() : null;

        $reviewer_name  = (string) get_post_meta( $project->ID, '_cul_reviewer_name', true );
        $reviewer_email = (string) get_post_meta( $project->ID, '_cul_reviewer_email', true );
        // Fall back to the assigned Client term if project-level override is empty
        if ( ( ! $reviewer_name || ! $reviewer_email ) && $client_terms && ! is_wp_error( $client_terms ) ) {
            $t = $client_terms[0];
            if ( ! $reviewer_name )  $reviewer_name  = $t->name;
            if ( ! $reviewer_email ) $reviewer_email = (string) get_term_meta( $t->term_id, '_cul_client_email', true );
        }

        $preview_only = get_post_meta( $project->ID, '_cul_preview_only', true ) === '1';

        if ( $preview_only ) {
            $active = null;
            foreach ( $files as $f ) {
                if ( $f->status !== 'superseded' ) { $active = $f; break; }
            }
            if ( $active ) {
                // Clean, branded viewer instead of dumping the visitor on the raw file URL.
                include CUL_REVIEW_PATH . 'templates/preview.php';
                exit;
            }
        }

        $bootstrap = [
            'token'    => $token,
            'restRoot' => esc_url_raw( rest_url( CUL_Review_REST::NS ) ),
            'nonce'    => wp_create_nonce( 'wp_rest' ),
            'project'  => [ 'id' => $project->ID, 'title' => $project->post_title ],
            'client'   => $client,
            'exitUrl'  => $client ? $client['url'] : null,
            'isAdmin'  => $is_admin,
            'adminName'=> $current_user ? $current_user->display_name : '',
            'previewOnly' => false,
            'reviewer' => [ 'name' => $reviewer_name, 'email' => $reviewer_email ],
            'files'    => $files,
            'pins'     => $pins,
            'comments' => $comments,
            'decisions'=> $decisions,
        ];

        include CUL_REVIEW_PATH . 'templates/review-page.php';
    }
}
