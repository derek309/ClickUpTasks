<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class CUL_Review_CPT {
    const POST_TYPE = 'cul_project';
    const TAX_CLIENT = 'cul_client';

    public static function register() {
        register_post_type( self::POST_TYPE, [
            'labels' => [
                'name'          => 'Review Projects',
                'singular_name' => 'Review Project',
                'add_new_item'  => 'Add Review Project',
                'edit_item'     => 'Edit Review Project',
                'menu_name'     => 'Reviews',
            ],
            'public'       => false,
            'show_ui'      => true,
            'show_in_menu' => true,
            'menu_icon'    => 'dashicons-feedback',
            'supports'     => [ 'title' ],
            'capability_type' => 'post',
        ] );

        register_taxonomy( self::TAX_CLIENT, self::POST_TYPE, [
            'labels' => [
                'name'              => 'Clients',
                'singular_name'     => 'Client',
                'menu_name'         => 'Clients',
                'all_items'         => 'All Clients',
                'edit_item'         => 'Edit Client',
                'view_item'         => 'View Client',
                'add_new_item'      => 'Add New Client',
                'search_items'      => 'Search Clients',
                'not_found'         => 'No clients found.',
            ],
            'hierarchical'      => true,
            'public'            => false,
            'show_ui'           => true,
            'show_admin_column' => true,
            'show_in_rest'      => false,
            'rewrite'           => false,
        ] );
    }

    public static function ensure_token( $project_id ) {
        $token = get_post_meta( $project_id, '_cul_share_token', true );
        if ( ! $token ) {
            $token = wp_generate_password( 20, false, false );
            update_post_meta( $project_id, '_cul_share_token', $token );
        }
        return $token;
    }

    /* --- Clients taxonomy: extra fields --- */

    public static function client_add_form_fields( $taxonomy ) {
        ?>
        <div class="form-field term-email-wrap">
            <label for="cul_client_email">Email</label>
            <input type="email" id="cul_client_email" name="cul_client_email" value="" placeholder="client@example.com">
            <p>Used to notify this client when a new revision is uploaded.</p>
        </div>
        <?php
    }

    public static function client_edit_form_fields( $term ) {
        $email = (string) get_term_meta( $term->term_id, '_cul_client_email', true );
        ?>
        <tr class="form-field term-email-wrap">
            <th scope="row"><label for="cul_client_email">Email</label></th>
            <td>
                <input type="email" id="cul_client_email" name="cul_client_email" value="<?php echo esc_attr( $email ); ?>" placeholder="client@example.com" style="width:95%;max-width:500px">
                <p class="description">Used to notify this client when a new revision is uploaded.</p>
            </td>
        </tr>
        <?php
    }

    public static function save_client_meta( $term_id ) {
        if ( isset( $_POST['cul_client_email'] ) ) {
            $email = sanitize_email( wp_unslash( $_POST['cul_client_email'] ) );
            update_term_meta( $term_id, '_cul_client_email', $email );
        }
    }

    public static function client_columns( $columns ) {
        $columns['cul_email'] = 'Email';
        return $columns;
    }

    public static function client_column_content( $content, $column_name, $term_id ) {
        if ( $column_name !== 'cul_email' ) return $content;
        $email = (string) get_term_meta( $term_id, '_cul_client_email', true );
        return $email ? '<a href="mailto:' . esc_attr( $email ) . '">' . esc_html( $email ) . '</a>' : '<span style="color:#999">—</span>';
    }

    /**
     * Return distinct emails of all Client terms assigned to a project.
     */
    public static function client_emails_for_project( $project_id ) {
        $emails = [];
        $terms = wp_get_post_terms( $project_id, self::TAX_CLIENT );
        if ( is_wp_error( $terms ) || ! $terms ) return $emails;
        foreach ( $terms as $t ) {
            $e = (string) get_term_meta( $t->term_id, '_cul_client_email', true );
            if ( is_email( $e ) ) $emails[ strtolower( $e ) ] = $e;
        }
        return $emails;
    }

    public static function project_by_token( $token ) {
        $token = sanitize_text_field( $token );
        if ( ! $token ) return null;
        $q = new WP_Query( [
            'post_type'      => self::POST_TYPE,
            'post_status'    => [ 'publish', 'draft', 'auto-draft', 'pending' ],
            'posts_per_page' => 1,
            'meta_key'       => '_cul_share_token',
            'meta_value'     => $token,
            'no_found_rows'  => true,
        ] );
        return $q->have_posts() ? $q->posts[0] : null;
    }
}
