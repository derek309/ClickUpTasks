<?php
/**
 * Plugin Name: ClickUpLocal Review
 * Description: Upload images, videos, and HTML for client review with pin-style comments and approvals.
 * Version: 0.9.1
 * Author: ClickUpLocal
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'CUL_REVIEW_VERSION', '0.9.1' );
define( 'CUL_REVIEW_PATH', plugin_dir_path( __FILE__ ) );
define( 'CUL_REVIEW_URL', plugin_dir_url( __FILE__ ) );

require_once CUL_REVIEW_PATH . 'includes/class-cul-updater.php';
require_once CUL_REVIEW_PATH . 'includes/class-activator.php';
require_once CUL_REVIEW_PATH . 'includes/class-cpt.php';
require_once CUL_REVIEW_PATH . 'includes/class-admin.php';
require_once CUL_REVIEW_PATH . 'includes/class-rest.php';
require_once CUL_REVIEW_PATH . 'includes/class-public.php';
require_once CUL_REVIEW_PATH . 'includes/class-notify.php';

// One-click updates from the Plugins screen. Deploying used to mean building
// a zip and uploading it in wp-admin on the live site, which is why source
// edits on Local could sit unreleased for weeks.
CUL_Updater::boot( [
    'slug'     => 'cul-review',
    'file'     => __FILE__,
    'version'  => CUL_REVIEW_VERSION,
    'manifest' => 'https://clickuptasks.vercel.app/plugins/cul-review.json',
] );

register_activation_hook( __FILE__, [ 'CUL_Review_Activator', 'activate' ] );

add_action( 'init', [ 'CUL_Review_CPT', 'register' ] );
add_action( 'init', [ 'CUL_Review_Public', 'add_rewrite' ] );
add_action( 'init', function () {
    if ( get_option( 'cul_review_version' ) !== CUL_REVIEW_VERSION ) {
        CUL_Review_Activator::activate();
        CUL_Review_Activator::maybe_migrate_decisions();
        flush_rewrite_rules();
        update_option( 'cul_review_version', CUL_REVIEW_VERSION );
    }
}, 99 );
add_filter( 'query_vars', [ 'CUL_Review_Public', 'query_vars' ] );
add_action( 'template_redirect', [ 'CUL_Review_Public', 'maybe_render' ] );

add_action( 'admin_init', [ 'CUL_Review_Admin', 'admin_init' ] );
add_action( 'admin_menu', [ 'CUL_Review_Admin', 'quick_share_menu' ] );
add_filter( 'manage_cul_project_posts_columns', [ 'CUL_Review_Admin', 'project_columns' ] );
add_action( 'manage_cul_project_posts_custom_column', [ 'CUL_Review_Admin', 'project_column_content' ], 10, 2 );
add_action( 'add_meta_boxes', [ 'CUL_Review_Admin', 'meta_boxes' ] );
add_action( 'save_post_cul_project', [ 'CUL_Review_Admin', 'save_post' ], 10, 2 );
add_action( 'admin_enqueue_scripts', [ 'CUL_Review_Admin', 'enqueue' ] );

add_action( 'rest_api_init', [ 'CUL_Review_REST', 'register' ] );

// Clients taxonomy: extra fields (email)
add_action( 'cul_client_add_form_fields', [ 'CUL_Review_CPT', 'client_add_form_fields' ] );
add_action( 'cul_client_edit_form_fields', [ 'CUL_Review_CPT', 'client_edit_form_fields' ], 10, 2 );
add_action( 'created_cul_client', [ 'CUL_Review_CPT', 'save_client_meta' ] );
add_action( 'edited_cul_client',  [ 'CUL_Review_CPT', 'save_client_meta' ] );
add_filter( 'manage_edit-cul_client_columns', [ 'CUL_Review_CPT', 'client_columns' ] );
add_filter( 'manage_cul_client_custom_column', [ 'CUL_Review_CPT', 'client_column_content' ], 10, 3 );

// Allow extra file types in media library for review uploads
add_filter( 'upload_mimes', function ( $mimes ) {
    $mimes['html|htm'] = 'text/html';
    $mimes['md']       = 'text/markdown';
    $mimes['txt']      = 'text/plain';
    $mimes['svg']      = 'image/svg+xml';
    return $mimes;
} );

// Bypass WP's "real mime" check for text-like files where finfo guesses text/plain
add_filter( 'wp_check_filetype_and_ext', function ( $data, $file, $filename, $mimes, $real_mime ) {
    if ( $data['ext'] && $data['type'] ) return $data;
    $ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
    $map = [
        'html' => 'text/html',
        'htm'  => 'text/html',
        'md'   => 'text/markdown',
        'txt'  => 'text/plain',
        'svg'  => 'image/svg+xml',
    ];
    if ( isset( $map[ $ext ] ) ) {
        $data['ext']  = $ext;
        $data['type'] = $map[ $ext ];
    }
    return $data;
}, 10, 5 );

// Flush rewrites once after activation
register_activation_hook( __FILE__, function () {
    CUL_Review_CPT::register();
    CUL_Review_Public::add_rewrite();
    flush_rewrite_rules();
} );
register_deactivation_hook( __FILE__, function () {
    flush_rewrite_rules();
} );
