(function(){
"use strict";

var BOOT = window.CUL_REVIEW || {};
var state = {
    token: BOOT.token,
    files: BOOT.files || [],
    pins: BOOT.pins || [],
    comments: BOOT.comments || [],
    decisions: BOOT.decisions || [],
    activeFileId: null,
    activePinId: null,
    reviewer: localStorage.getItem('cul_review_name') || (BOOT.reviewer && BOOT.reviewer.name) || '',
    reviewerEmail: localStorage.getItem('cul_review_email') || (BOOT.reviewer && BOOT.reviewer.email) || '',
    pendingPin: null,
    zoom: {},           // fileId -> zoom factor
    fitted: {}          // fileId -> true once auto-fitted
};
var ZOOM_STEPS = [0.25, 0.33, 0.5, 0.67, 0.75, 0.9, 1, 1.25, 1.5, 1.75, 2, 2.5, 3];

function api(path, opts){
    opts = opts || {};
    opts.headers = Object.assign({
        'Content-Type': 'application/json',
        'X-WP-Nonce': BOOT.nonce
    }, opts.headers || {});
    if (opts.body && typeof opts.body !== 'string') opts.body = JSON.stringify(opts.body);
    var url = BOOT.restRoot + path;
    return fetch(url, opts).then(function(r){
        return r.json().then(function(j){ return r.ok ? j : Promise.reject(j); });
    });
}

function el(tag, attrs, children){
    var e = document.createElement(tag);
    if (attrs) for (var k in attrs) {
        if (k === 'class') e.className = attrs[k];
        else if (k === 'html') e.innerHTML = attrs[k];
        else if (k === 'text') e.textContent = attrs[k];
        else if (k.indexOf('on') === 0) e.addEventListener(k.slice(2), attrs[k]);
        else e.setAttribute(k, attrs[k]);
    }
    (children || []).forEach(function(c){ if (c) e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
}

function fileById(id){ return state.files.find(function(f){ return +f.id === +id; }); }
function reviewerKey(){
    if (state.reviewerEmail) return state.reviewerEmail.toLowerCase();
    if (state.reviewer) return 'name:' + state.reviewer.toLowerCase();
    return '';
}
function decisionsForFile(fid){ return state.decisions.filter(function(d){ return +d.file_id === +fid; }); }
function myDecision(fid){
    var key = reviewerKey();
    if (!key) return null;
    return state.decisions.find(function(d){ return +d.file_id === +fid && d.reviewer_key === key; }) || null;
}
function pinsForFile(fid){ return state.pins.filter(function(p){ return +p.file_id === +fid; }); }
function commentsForPin(pid){ return state.comments.filter(function(c){ return +c.pin_id === +pid; }); }
function fmtTime(s){ s = +s; var m = Math.floor(s/60); var sec = Math.floor(s%60); return m + ':' + (sec<10?'0':'') + sec; }
function fmtDateTime(iso){
    if (!iso) return '';
    try {
        var d = new Date(String(iso).replace(' ', 'T') + 'Z');
        return d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
    } catch(e) { return String(iso); }
}
function fmtAgo(iso){
    if (!iso) return '';
    var d = new Date(iso.replace(' ', 'T') + 'Z');
    var diff = (Date.now() - d.getTime())/1000;
    if (diff < 60) return 'just now';
    if (diff < 3600) return Math.floor(diff/60)+'m';
    if (diff < 86400) return Math.floor(diff/3600)+'h';
    return Math.floor(diff/86400)+'d';
}

// ---------- File list ----------
function renderFileList(){
    var ul = document.getElementById('cul-file-list');
    if (!ul) return;
    ul.innerHTML = '';
    if (!state.files.length) {
        ul.appendChild(el('li', { class: 'cul-empty', text: 'No files yet.' }));
        return;
    }
    state.files.forEach(function(f){
        var thumb;
        if (f.kind === 'image') thumb = el('div', { class: 'cul-file-thumb' }, [ el('img', { src: f.url }) ]);
        else if (f.kind === 'video') thumb = el('div', { class: 'cul-file-thumb' }, [ el('video', { src: f.url, muted: 'muted' }) ]);
        else thumb = el('div', { class: 'cul-file-thumb', text: 'HTML' });

        var count = pinsForFile(f.id).length;
        var meta = el('div', { class: 'cul-file-meta' }, [
            el('div', { class: 'cul-file-name', text: f.label || ('File ' + f.id) }),
            el('div', { class: 'cul-file-sub' }, [
                el('span', { class: 'cul-status-pill is-' + f.status, text: humanStatus(f.status) }),
                count ? el('span', { class: 'cul-file-pincount', text: count + ' pin' + (count > 1 ? 's' : '') }) : null
            ])
        ]);
        var li = el('li', {
            class: 'cul-file-item' + (+state.activeFileId === +f.id ? ' is-active' : ''),
            onclick: function(){ selectFile(f.id); }
        }, [ thumb, meta ]);
        ul.appendChild(li);
    });
}
function humanStatus(s){
    if (s === 'approved') return 'Approved';
    if (s === 'changes_requested') return 'Changes requested';
    if (s === 'superseded') return 'Superseded';
    return 'Pending';
}

// ---------- Pin list (sidebar) ----------
function renderPinList(){
    var box = document.getElementById('cul-pin-list');
    box.innerHTML = '';
    if (!state.activeFileId) {
        box.appendChild(el('div', { class: 'cul-empty', text: 'Open a file to see comments.' }));
        return;
    }
    var pins = pinsForFile(state.activeFileId);
    if (!pins.length) {
        var steps = el('ol', { class: 'cul-empty-steps' }, [
            el('li', { text: 'Click anywhere on the artwork to drop a numbered pin.' }),
            el('li', { text: 'Type what needs to change in that spot.' }),
            el('li', { text: 'Add a pin for every change. Your team is notified automatically.' })
        ]);
        box.appendChild(el('div', { class: 'cul-empty-instructions' }, [
            el('div', { class: 'cul-empty-headline', text: 'How to request changes' }),
            steps
        ]));
        return;
    }
    pins.forEach(function(p){
        var replies = commentsForPin(p.id);
        var node = el('div', {
            class: 'cul-pin-item is-' + p.status + (+state.activePinId === +p.id ? ' is-active' : ''),
            onclick: function(e){
                if (e.target.closest('input,button,form')) return;
                state.activePinId = p.id;
                renderPinList();
                renderStage();
                seekVideoToPin(p);
            }
        });

        var row = el('div', { class: 'cul-pin-row' }, [
            el('span', { class: 'cul-pin-num', text: String(p.number) }),
            el('span', { class: 'cul-pin-author', text: p.author_name }),
            el('span', { class: 'cul-pin-time', text: ' · ' + fmtAgo(p.created_at) + (p.t_seconds != null ? ' · @' + fmtTime(p.t_seconds) : '') })
        ]);
        var actions = el('span', { class: 'cul-pin-actions' });
        actions.appendChild(el('button', {
            class: 'cul-pin-resolve',
            type: 'button',
            text: p.status === 'open' ? '✓' : '↺',
            title: p.status === 'open' ? 'Mark resolved' : 'Reopen',
            onclick: function(e){ e.stopPropagation(); togglePinStatus(p); }
        }));
        actions.appendChild(el('button', {
            class: 'cul-pin-edit',
            type: 'button',
            text: '✎',
            title: 'Edit',
            onclick: function(e){ e.stopPropagation(); startEditPin(p, bodyEl); }
        }));
        actions.appendChild(el('button', {
            class: 'cul-pin-delete',
            type: 'button',
            text: '✕',
            title: 'Delete',
            onclick: function(e){
                e.stopPropagation();
                if (!confirm('Delete this comment and all replies?')) return;
                deletePin(p);
            }
        }));
        row.appendChild(actions);
        node.appendChild(row);
        var bodyEl = el('div', { class: 'cul-pin-body', text: p.body });
        node.appendChild(bodyEl);

        if (p.attachment_url) {
            var att = el('a', {
                class: 'cul-pin-attachment',
                href: p.attachment_url,
                target: '_blank',
                rel: 'noopener',
                onclick: function(e){ e.stopPropagation(); }
            }, [ el('img', { src: p.attachment_url, alt: 'reference' }) ]);
            node.appendChild(att);
        }

        var rep = el('div', { class: 'cul-pin-replies' });
        replies.forEach(function(c){
            var cBody = el('div', { class: 'cul-c-body', text: c.body });
            var cnode = el('div', { class: 'cul-comment' }, [
                el('span', { class: 'cul-c-author', text: c.author_name }),
                document.createTextNode(' '),
                el('span', { class: 'cul-pin-time', text: fmtAgo(c.created_at) }),
                el('button', {
                    class: 'cul-comment-edit',
                    type: 'button',
                    text: '✎',
                    title: 'Edit reply',
                    onclick: function(e){ e.stopPropagation(); startEditComment(c, cBody); }
                }),
                el('button', {
                    class: 'cul-comment-delete',
                    type: 'button',
                    text: '✕',
                    title: 'Delete reply',
                    onclick: function(e){
                        e.stopPropagation();
                        if (!confirm('Delete this reply?')) return;
                        deleteComment(c);
                    }
                }),
                cBody
            ]);
            rep.appendChild(cnode);
        });
        var form = el('form', { class: 'cul-pin-reply-form', onsubmit: function(e){
            e.preventDefault();
            var input = form.querySelector('input');
            var body = input.value.trim();
            if (!body) return;
            ensureReviewerName().then(function(name){
                return api('/comments?token=' + state.token, { method: 'POST', body: { pin_id: p.id, body: body, author_name: name } });
            }).then(function(c){
                state.comments.push(c);
                input.value = '';
                renderPinList();
            });
        }});
        form.appendChild(el('input', { type: 'text', placeholder: 'Reply...', maxlength: 1000 }));
        form.appendChild(el('button', { type: 'submit', text: 'Send' }));
        rep.appendChild(form);
        node.appendChild(rep);

        box.appendChild(node);
    });
}

function inlineEdit(bodyEl, currentText, onSave){
    if (bodyEl.querySelector('textarea')) return; // already editing
    var original = currentText;
    var ta = document.createElement('textarea');
    ta.className = 'cul-inline-edit';
    ta.value = original;
    ta.rows = 3;
    var save = document.createElement('button');
    save.type = 'button'; save.className = 'cul-inline-save'; save.textContent = 'Save';
    var cancel = document.createElement('button');
    cancel.type = 'button'; cancel.className = 'cul-inline-cancel'; cancel.textContent = 'Cancel';
    var actions = document.createElement('div');
    actions.className = 'cul-inline-actions';
    actions.appendChild(save); actions.appendChild(cancel);
    bodyEl.innerHTML = '';
    bodyEl.appendChild(ta);
    bodyEl.appendChild(actions);
    ta.focus();
    cancel.addEventListener('click', function(){ bodyEl.textContent = original; });
    save.addEventListener('click', function(){
        var val = ta.value.trim();
        if (!val) return;
        save.disabled = true;
        onSave(val, function(updated){
            bodyEl.textContent = updated;
        }, function(){
            save.disabled = false;
        });
    });
}

function startEditPin(p, bodyEl){
    inlineEdit(bodyEl, p.body, function(newBody, done, fail){
        api('/pins/' + p.id + '?token=' + state.token, { method: 'PATCH', body: { body: newBody } }).then(function(updated){
            p.body = updated.body;
            done(updated.body);
            renderPinList();
        }).catch(function(){ fail(); });
    });
}

function startEditComment(c, bodyEl){
    inlineEdit(bodyEl, c.body, function(newBody, done, fail){
        api('/comments/' + c.id + '?token=' + state.token, { method: 'PATCH', body: { body: newBody } }).then(function(updated){
            c.body = updated.body;
            done(updated.body);
            renderPinList();
        }).catch(function(){ fail(); });
    });
}

function deletePin(p){
    api('/pins/' + p.id + '?token=' + state.token, { method: 'DELETE' }).then(function(){
        state.pins = state.pins.filter(function(x){ return +x.id !== +p.id; });
        state.comments = state.comments.filter(function(c){ return +c.pin_id !== +p.id; });
        if (+state.activePinId === +p.id) state.activePinId = null;
        var f = fileById(state.activeFileId);
        var iframe = document.querySelector('.cul-media-wrap iframe');
        if (f && f.kind === 'html' && iframe) wireHtmlIframe(f, iframe);
        else renderStage();
        renderPinList();
        renderFileList();
    });
}

function deleteComment(c){
    api('/comments/' + c.id + '?token=' + state.token, { method: 'DELETE' }).then(function(){
        state.comments = state.comments.filter(function(x){ return +x.id !== +c.id; });
        renderPinList();
    });
}

function togglePinStatus(p){
    var next = p.status === 'open' ? 'resolved' : 'open';
    api('/pins/' + p.id + '?token=' + state.token, { method: 'PATCH', body: { status: next } }).then(function(){
        p.status = next;
        renderPinList();
        renderStage();
    });
}

// ---------- Stage (file viewer) ----------
function selectFile(id){
    state.activeFileId = id;
    state.activePinId = null;
    renderFileList();
    renderStage();
    renderPinList();
    updateStatusButtons();
    renderVersionSwitcher();
}

// ---------- Version switcher ----------
function renderVersionSwitcher(){
    var wrap = document.getElementById('cul-version-switcher');
    if (!wrap) return;
    if (state.files.length < 2) { wrap.hidden = true; return; }
    wrap.hidden = false;
    var f = fileById(state.activeFileId);
    var labelEl = document.getElementById('cul-version-current-label');
    if (f) {
        labelEl.innerHTML = '<span class="cul-version-statusdot is-' + f.status + '" aria-hidden="true"></span>'
            + escapeHtml(f.label || 'File ' + f.id);
    } else {
        labelEl.textContent = 'Pick a version';
    }

    var menu = document.getElementById('cul-version-menu');
    menu.innerHTML = '';
    state.files.forEach(function(file){
        var isActive = +file.id === +state.activeFileId;
        var item = el('button', {
            type: 'button',
            class: 'cul-version-item' + (isActive ? ' is-active' : '') + (file.status === 'superseded' ? ' is-past' : ''),
            onclick: function(){ closeVersionMenu(); openFile(file.id); }
        });
        var thumb;
        if (file.kind === 'image') thumb = el('div', { class: 'cul-version-thumb' }, [ el('img', { src: file.url }) ]);
        else if (file.kind === 'video') thumb = el('div', { class: 'cul-version-thumb' }, [ el('video', { src: file.url, muted: 'muted' }) ]);
        else thumb = el('div', { class: 'cul-version-thumb', text: file.kind.toUpperCase() });
        item.appendChild(thumb);
        var info = el('div', { class: 'cul-version-info' }, [
            el('div', { class: 'cul-version-label', text: file.label || 'File ' + file.id }),
            el('div', { class: 'cul-version-sub', text: 'Added ' + fmtDateTime(file.created_at) })
        ]);
        item.appendChild(info);
        item.appendChild(el('span', { class: 'cul-status-pill is-' + file.status, text: humanStatus(file.status) }));
        menu.appendChild(item);
    });
}

function closeVersionMenu(){
    var menu = document.getElementById('cul-version-menu');
    var btn  = document.getElementById('cul-version-trigger');
    if (menu) menu.hidden = true;
    if (btn) btn.setAttribute('aria-expanded', 'false');
}
(function(){
    var btn = document.getElementById('cul-version-trigger');
    var menu = document.getElementById('cul-version-menu');
    if (!btn || !menu) return;
    btn.addEventListener('click', function(e){
        e.stopPropagation();
        var open = btn.getAttribute('aria-expanded') === 'true';
        btn.setAttribute('aria-expanded', open ? 'false' : 'true');
        menu.hidden = open;
    });
    document.addEventListener('click', function(e){
        if (!menu.hidden && !menu.contains(e.target) && e.target !== btn) closeVersionMenu();
    });
})();

function renderStage(){
    var stage = document.getElementById('cul-stage');
    stage.innerHTML = '';
    var f = fileById(state.activeFileId);
    if (!f) { stage.appendChild(el('div', { class: 'cul-empty', text: 'Select a file on the left to start reviewing.' })); return; }

    var zoomGroup = document.getElementById('cul-zoom-group');
    var zoomable = (f.kind === 'image' || f.kind === 'video' || f.kind === 'markdown' || f.kind === 'text');
    zoomGroup.hidden = !zoomable;


    var wrapClass = 'cul-media-wrap';
    if (f.kind === 'html' || f.kind === 'pdf' || f.kind === 'link') wrapClass += ' is-iframe';
    var wrap = el('div', { class: wrapClass });
    var media;
    var isVideo = f.kind === 'video';

    if (f.kind === 'image') {
        media = el('img', { src: f.url, alt: f.label || '' });
    } else if (isVideo) {
        media = el('video', { src: f.url, controls: 'controls', preload: 'metadata' });
    } else if (f.kind === 'pdf' || f.kind === 'link') {
        media = el('iframe', { src: f.url });
    } else if (f.kind === 'html') {
        media = el('iframe', { src: f.url });
        if (!BOOT.previewOnly) {
            media.addEventListener('load', function(){ wireHtmlIframe(f, media); });
        }
    } else if (f.kind === 'markdown' || f.kind === 'text') {
        media = el('div', { class: 'cul-doc' });
        media.innerHTML = '<div class="cul-doc-loading">Loading…</div>';
        fetch(f.url).then(function(r){ return r.text(); }).then(function(txt){
            if (f.kind === 'markdown' && window.marked) {
                media.innerHTML = '<div class="cul-doc-inner">' + window.marked.parse(txt) + '</div>';
            } else {
                var pre = document.createElement('pre');
                pre.className = 'cul-doc-pre';
                pre.textContent = txt;
                media.innerHTML = '';
                media.appendChild(pre);
            }
        }).catch(function(){ media.innerHTML = '<div class="cul-doc-loading">Could not load file.</div>'; });
    } else {
        media = el('iframe', { src: f.url, sandbox: 'allow-same-origin allow-scripts allow-forms' });
    }
    wrap.appendChild(media);

  // Preview-only mode: skip the whole pin layer — file shows as a normal, unrestricted page.
  if (!BOOT.previewOnly) {
    var layer = el('div', { class: 'cul-pin-layer' + (isVideo ? ' is-video' : '') });
    wrap.appendChild(layer);

    // Remove any prior floating pin-mode toggle
    var prevToggle = document.querySelector('.cul-pinmode-floating');
    if (prevToggle) prevToggle.remove();

    // HTML: clicks routed INSIDE the iframe (see wireHtmlIframe), outer layer disabled.
    // PDF / link / video: layer is off by default so native controls work (play, scrub,
    // scroll); a floating "Pin mode" toggle turns the layer on for dropping pins.
    if (f.kind === 'html') {
        layer.style.pointerEvents = 'none';
    } else if (f.kind === 'pdf' || f.kind === 'link' || f.kind === 'video') {
        layer.style.pointerEvents = 'none';
        var offText = isVideo ? '✎ Pin mode: off' : '✎ Pin mode: off';
        var pinToggle = el('button', {
            type: 'button',
            class: 'cul-pinmode-floating',
            text: offText,
            onclick: function(){
                var on = layer.style.pointerEvents !== 'none';
                if (on) { layer.style.pointerEvents = 'none'; pinToggle.textContent = '✎ Pin mode: off'; pinToggle.classList.remove('is-on'); }
                else    { layer.style.pointerEvents = 'auto'; pinToggle.textContent = '✎ Pin mode: on — click the ' + (isVideo ? 'frame' : 'page'); pinToggle.classList.add('is-on'); }
            }
        });
        document.querySelector('.cul-stage').appendChild(pinToggle);
    }

    layer.addEventListener('click', function(e){
        var rect = layer.getBoundingClientRect();
        var x = ((e.clientX - rect.left) / rect.width) * 100;
        var y = ((e.clientY - rect.top) / rect.height) * 100;
        var t = isVideo ? media.currentTime : null;
        if (isVideo) media.pause();
        openPinModal({ file_id: f.id, x_pct: x, y_pct: y, t_seconds: t });
        // For pdf/link/video, drop back out of pin mode after placing one pin
        var ftog = document.querySelector('.cul-pinmode-floating');
        if (ftog) {
            layer.style.pointerEvents = 'none';
            ftog.textContent = '✎ Pin mode: off';
            ftog.classList.remove('is-on');
        }
    });

    // Render existing pins as markers (skipped for HTML — handled inside iframe)
    if (f.kind !== 'html') {
        var pins = pinsForFile(f.id);
        pins.forEach(function(p){
            if (p.x_pct == null || p.y_pct == null) return;
            var marker = el('div', {
                class: 'cul-pin-marker is-' + p.status + (+state.activePinId === +p.id ? ' is-active' : ''),
                text: String(p.number),
                title: p.author_name + ': ' + p.body,
                onclick: function(e){
                    e.stopPropagation();
                    state.activePinId = p.id;
                    renderPinList();
                    renderStage();
                    seekVideoToPin(p);
                }
            });
            marker.style.left = p.x_pct + '%';
            marker.style.top = p.y_pct + '%';
            if (isVideo) {
                marker.dataset.t = p.t_seconds;
                marker.style.display = 'none';
            }
            layer.appendChild(marker);
        });
    }
  } // end !previewOnly pin layer

    stage.appendChild(wrap);

    if (zoomable) {
        if (state.zoom[f.id] == null) state.zoom[f.id] = 1;
        applyZoom(f, wrap, media);
        if (!state.fitted[f.id]) {
            var doFit = function(){
                state.fitted[f.id] = true;
                fitZoom();
            };
            if (f.kind === 'image') {
                if (media.complete && media.naturalWidth) doFit();
                else media.addEventListener('load', doFit, { once: true });
            } else if (f.kind === 'video') {
                if (media.videoWidth) doFit();
                else media.addEventListener('loadedmetadata', doFit, { once: true });
            } else {
                // markdown/text — fit after async fetch completes
                setTimeout(doFit, 100);
            }
        }
    }

    if (isVideo && !BOOT.previewOnly) {
        var track = el('div', { class: 'cul-video-pins-track' });
        pins.forEach(function(p){
            track.appendChild(el('span', {
                class: 'cul-vp',
                text: '#' + p.number + ' @ ' + fmtTime(p.t_seconds || 0),
                onclick: function(){ media.currentTime = +p.t_seconds || 0; media.pause(); state.activePinId = p.id; renderPinList(); refreshVideoMarkers(media, layer); }
            }));
        });
        stage.appendChild(track);

        media.addEventListener('timeupdate', function(){ refreshVideoMarkers(media, layer); });
        media.addEventListener('loadedmetadata', function(){ refreshVideoMarkers(media, layer); });
        refreshVideoMarkers(media, layer);
    }
}

function wireHtmlIframe(f, iframe){
    var doc;
    try { doc = iframe.contentDocument; } catch (e) { return; }
    if (!doc || !doc.body) return;

    // Inject styles + marker container into the iframe document
    var existing = doc.getElementById('cul-iframe-style');
    if (!existing) {
        var st = doc.createElement('style');
        st.id = 'cul-iframe-style';
        st.textContent =
            'html, body { cursor: crosshair !important; }' +
            '.cul-iframe-marker { position: absolute; transform: translate(-50%,-50%); width:26px; height:26px;' +
            'border-radius:50%; background:#2f6cff; color:#fff; border:2px solid #fff; box-shadow:0 1px 4px rgba(0,0,0,.25);' +
            'display:flex; align-items:center; justify-content:center; font:700 16px/1 -apple-system,sans-serif;' +
            'z-index:2147483647; cursor:pointer; }' +
            '.cul-iframe-marker.is-resolved { background:#9aa1b1; }' +
            '.cul-iframe-marker.is-active { box-shadow:0 0 0 4px rgba(47,108,255,.25); }' +
            'a, button { pointer-events: none !important; }';
        doc.head.appendChild(st);
    }

    var layer = doc.getElementById('cul-iframe-pins');
    if (!layer) {
        layer = doc.createElement('div');
        layer.id = 'cul-iframe-pins';
        layer.style.cssText = 'position:absolute; left:0; top:0; width:100%; height:100%; pointer-events:none; z-index:2147483646;';
        doc.body.style.position = doc.body.style.position || 'relative';
        doc.body.appendChild(layer);
    }
    layer.innerHTML = '';

    // Use document scroll dimensions so pins anchor to content, not viewport
    function docW(){ return Math.max(doc.documentElement.scrollWidth, doc.body.scrollWidth); }
    function docH(){ return Math.max(doc.documentElement.scrollHeight, doc.body.scrollHeight); }

    pinsForFile(f.id).forEach(function(p){
        if (p.x_pct == null || p.y_pct == null) return;
        var m = doc.createElement('div');
        m.className = 'cul-iframe-marker is-' + p.status + (+state.activePinId === +p.id ? ' is-active' : '');
        m.textContent = String(p.number);
        m.title = p.author_name + ': ' + p.body;
        m.style.pointerEvents = 'auto';
        m.style.left = (p.x_pct / 100 * docW()) + 'px';
        m.style.top  = (p.y_pct / 100 * docH()) + 'px';
        m.addEventListener('click', function(e){
            e.stopPropagation(); e.preventDefault();
            state.activePinId = p.id;
            renderPinList();
            // Re-render markers to update active state
            wireHtmlIframe(f, iframe);
        });
        layer.appendChild(m);
    });

    // Click anywhere in the iframe → open pin modal with document-relative coords
    doc.addEventListener('click', function(e){
        if (e.target.closest && e.target.closest('.cul-iframe-marker')) return;
        var x = (e.pageX / docW()) * 100;
        var y = (e.pageY / docH()) * 100;
        e.preventDefault();
        openPinModal({ file_id: f.id, x_pct: x, y_pct: y, t_seconds: null });
    }, true);
}

function applyZoom(f, wrap, media){
    var z = state.zoom[f.id] || 1;
    var natural;
    if (f.kind === 'image') {
        natural = media.naturalWidth;
        if (!natural) { media.addEventListener('load', function(){ applyZoom(f, wrap, media); }, { once: true }); }
        if (natural) media.style.width = (natural * z) + 'px';
    } else if (f.kind === 'video') {
        natural = media.videoWidth;
        if (!natural) { media.addEventListener('loadedmetadata', function(){ applyZoom(f, wrap, media); }, { once: true }); }
        if (natural) media.style.width = (natural * z) + 'px';
    } else if (f.kind === 'markdown' || f.kind === 'text') {
        var base = (f.kind === 'markdown') ? 820 : 820;
        media.style.width = (base * z) + 'px';
        media.style.fontSize = (16 * z) + 'px';
    }
    var lbl = document.getElementById('cul-zoom-level');
    if (lbl) lbl.textContent = Math.round(z * 100) + '%';
}

function currentFileWrapMedia(){
    var f = fileById(state.activeFileId);
    if (!f) return null;
    var wrap = document.querySelector('.cul-media-wrap');
    if (!wrap) return null;
    var media = wrap.querySelector('img, video, iframe, .cul-doc');
    return { f: f, wrap: wrap, media: media };
}

function stepZoom(delta){
    var ctx = currentFileWrapMedia(); if (!ctx) return;
    var cur = state.zoom[ctx.f.id] || 1;
    var idx = ZOOM_STEPS.indexOf(cur);
    if (idx === -1) {
        // find nearest
        idx = ZOOM_STEPS.reduce(function(best, v, i){
            return Math.abs(v - cur) < Math.abs(ZOOM_STEPS[best] - cur) ? i : best;
        }, 0);
    }
    var next = ZOOM_STEPS[Math.max(0, Math.min(ZOOM_STEPS.length - 1, idx + delta))];
    state.zoom[ctx.f.id] = next;
    applyZoom(ctx.f, ctx.wrap, ctx.media);
}

function resetZoom(){
    var ctx = currentFileWrapMedia(); if (!ctx) return;
    state.zoom[ctx.f.id] = 1;
    applyZoom(ctx.f, ctx.wrap, ctx.media);
}

function fitZoom(){
    var ctx = currentFileWrapMedia(); if (!ctx) return;
    var stage = document.getElementById('cul-stage');
    var avail = stage.clientWidth - 48; // padding
    var natural;
    if (ctx.f.kind === 'image') natural = ctx.media.naturalWidth;
    else if (ctx.f.kind === 'video') natural = ctx.media.videoWidth;
    else natural = 820;
    if (!natural) return;
    state.zoom[ctx.f.id] = Math.min(1, avail / natural);
    applyZoom(ctx.f, ctx.wrap, ctx.media);
}

document.getElementById('cul-zoom-in').addEventListener('click', function(){ stepZoom(1); });
document.getElementById('cul-zoom-out').addEventListener('click', function(){ stepZoom(-1); });
document.getElementById('cul-zoom-level').addEventListener('click', resetZoom);
document.getElementById('cul-zoom-fit').addEventListener('click', fitZoom);

function refreshVideoMarkers(video, layer){
    var t = video.currentTime;
    layer.querySelectorAll('.cul-pin-marker').forEach(function(m){
        var pt = +m.dataset.t || 0;
        m.style.display = (Math.abs(pt - t) < 1.5) ? 'flex' : 'none';
    });
}

function seekVideoToPin(p){
    if (p.t_seconds == null) return;
    var v = document.querySelector('.cul-media-wrap video');
    if (v) { v.currentTime = +p.t_seconds; v.pause(); }
}

// ---------- Status buttons ----------
function applyDecisionResponse(f, res){
    // Replace this file's decisions with the fresh server list
    state.decisions = state.decisions.filter(function(d){ return +d.file_id !== +f.id; })
        .concat(res.decisions || []);
    f.status = res.file_status;
    f.approved_at = res.approved_at || null;
    f.approved_by = res.approved_by || '';
    updateStatusButtons();
    renderFileList();
}

// decision: 'approved' | 'changes_requested' | 'none'
function setMyDecision(decision){
    var f = fileById(state.activeFileId);
    if (!f) return Promise.reject();
    var send = function(){
        return api('/files/' + f.id + '/decision?token=' + state.token, { method: 'POST', body: {
            decision: decision,
            reviewer_name: state.reviewer || '',
            reviewer_email: state.reviewerEmail || ''
        } }).then(function(res){ applyDecisionResponse(f, res); return res; });
    };
    if (decision === 'none') return send();
    return ensureReviewerName().then(send);
}

function escapeHtml(s){ return String(s).replace(/[&<>"']/g, function(c){ return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]; }); }
function filenameFromUrl(url){
    if (!url) return '';
    try {
        var path = url.split('?')[0].split('#')[0];
        var name = decodeURIComponent(path.split('/').pop() || '');
        // Trim common WP-injected size suffixes like -300x200 just before extension? Keep raw for now.
        return name;
    } catch(e) { return ''; }
}
function updateStatusButtons(){
    var f = fileById(state.activeFileId);
    var panel = document.getElementById('cul-decision');
    var comments = document.getElementById('cul-comments-section');
    var submitBar = document.getElementById('cul-submit-bar');
    var adminPanel = document.getElementById('cul-admin-revision');
    if (!f) { panel.hidden = true; comments.hidden = true; submitBar.hidden = true; adminPanel.hidden = true; return; }

    // Preview-only: no review controls at all
    if (BOOT.previewOnly) {
        panel.hidden = true; comments.hidden = true; submitBar.hidden = true; adminPanel.hidden = true;
        return;
    }

    // Panel mode is driven by THIS reviewer's own decision, not the file rollup
    var mine = myDecision(f.id);
    var mode = mine ? (mine.decision === 'approved' ? 'approved' : 'changes') : 'pending';
    // Superseded files: no decision UI at all
    if (f.status === 'superseded') {
        panel.hidden = true; comments.hidden = true; submitBar.hidden = true; adminPanel.hidden = true;
        renderReviewers(f);
        return;
    }

    panel.hidden = (mode === 'changes');
    panel.querySelectorAll('[data-mode]').forEach(function(el){ el.hidden = (el.dataset.mode !== mode); });
    var fileLabel = document.getElementById('cul-decision-file');
    if (fileLabel) fileLabel.textContent = f.label || 'this file';

    // Comment slide-out shows only while this reviewer is in "changes" mode
    comments.hidden = (mode !== 'changes');

    // Submit bar (reviewer) vs admin revision upload panel
    if (mode === 'changes' && BOOT.isAdmin) {
        submitBar.hidden = true;
        adminPanel.hidden = false;
    } else {
        submitBar.hidden = (mode !== 'changes');
        adminPanel.hidden = true;
    }

    if (mode === 'approved') {
        var note = document.getElementById('cul-approved-note');
        if (mine && mine.updated_at) {
            note.textContent = '✓ You approved this on ' + fmtDateTime(mine.updated_at);
        } else {
            note.textContent = '✓ You approved this.';
        }
        var dlCta = document.getElementById('cul-decision-download');
        dlCta.href = f.url;
        if (f.kind === 'link') {
            dlCta.removeAttribute('download');
            dlCta.querySelector('.cul-decision-download-label').textContent = 'Open ' + (f.label || 'link');
        } else {
            var fname = (f.url.split('/').pop() || '').split('?')[0] || (f.label || 'file');
            dlCta.setAttribute('download', fname);
            dlCta.querySelector('.cul-decision-download-label').textContent = 'Download ' + (f.label || 'file');
        }
        dlCta.setAttribute('target', '_blank');
        dlCta.setAttribute('rel', 'noopener');
    }

    renderReviewers(f);
}

function renderReviewers(f){
    var box = document.getElementById('cul-reviewers');
    if (!box) return;
    var ds = decisionsForFile(f.id);
    if (!ds.length) { box.hidden = true; box.innerHTML = ''; return; }
    box.hidden = false;
    box.innerHTML = '';
    box.appendChild(el('div', { class: 'cul-reviewers-title', text: 'Reviewer decisions' }));
    ds.forEach(function(d){
        box.appendChild(el('div', { class: 'cul-reviewer-row' }, [
            el('span', { class: 'cul-reviewer-name', text: d.reviewer_name || 'Guest' }),
            el('span', { class: 'cul-status-pill is-' + d.decision, text: humanStatus(d.decision) })
        ]));
    });
}

document.querySelectorAll('.cul-decision-btn, .cul-decision-reset').forEach(function(b){
    b.addEventListener('click', function(){
        var status = b.dataset.status;
        if (status === 'approved') {
            setMyDecision('approved').then(function(){ openApproveModal(); }, function(){});
        } else if (status === 'changes_requested') {
            setMyDecision('changes_requested');
        } else {
            // "Reset to pending" → withdraw this reviewer's decision
            setMyDecision('none');
        }
    });
});

// ---------- Approve modal flow ----------
function openApproveModal(){
    var f = fileById(state.activeFileId);
    if (!f) return;
    var modal = document.getElementById('cul-approve-modal');
    var dl    = document.getElementById('cul-approve-download');
    dl.href = f.url;
    if (f.kind === 'link') {
        dl.removeAttribute('download');
        dl.textContent = '→ Open ' + (f.label || 'link');
    } else {
        var fname = (f.url.split('/').pop() || '').split('?')[0] || (f.label || 'file');
        dl.setAttribute('download', fname);
        dl.textContent = '⬇ Download ' + (f.label || 'file');
    }
    dl.setAttribute('target', '_blank');
    dl.setAttribute('rel', 'noopener');
    document.getElementById('cul-approve-modal-text').textContent =
        'Approved by ' + (state.reviewer || 'you') + '. Want to download the final file before you go?';
    modal.hidden = false;
}
function closeApproveModal(){ document.getElementById('cul-approve-modal').hidden = true; }
document.getElementById('cul-approve-download').addEventListener('click', function(){
    // Allow the browser to start the download, then exit
    setTimeout(function(){ closeApproveModal(); exitProject(); }, 300);
});
document.getElementById('cul-approve-skip').addEventListener('click', function(){
    closeApproveModal();
    exitProject();
});
document.getElementById('cul-approve-cancel').addEventListener('click', closeApproveModal);

// ---------- Submit review request flow ----------
document.getElementById('cul-submit-review-btn').addEventListener('click', function(){
    document.getElementById('cul-submit-note').value = '';
    document.getElementById('cul-submit-modal').hidden = false;
    setTimeout(function(){ document.getElementById('cul-submit-note').focus(); }, 30);
});
document.getElementById('cul-submit-cancel').addEventListener('click', function(){
    document.getElementById('cul-submit-modal').hidden = true;
});
document.getElementById('cul-submit-skip').addEventListener('click', function(){
    var f = fileById(state.activeFileId);
    var done = function(){ document.getElementById('cul-submit-modal').hidden = true; exitProject(); };
    if (!f) { done(); return; }
    api('/submit-review?token=' + state.token, { method: 'POST', body: {
        file_id: f.id, author_name: state.reviewer || '', author_email: state.reviewerEmail || '', note: ''
    } }).then(done, done);
});
document.getElementById('cul-submit-send').addEventListener('click', function(){
    var note = document.getElementById('cul-submit-note').value.trim();
    var done = function(){ document.getElementById('cul-submit-modal').hidden = true; exitProject(); };
    var f = fileById(state.activeFileId);
    if (!f) { done(); return; }
    var send = function(name){
        return api('/submit-review?token=' + state.token, { method: 'POST', body: {
            file_id: f.id, author_name: name || '', author_email: state.reviewerEmail || '', note: note
        } });
    };
    if (note) {
        ensureReviewerName().then(function(name){ send(name).then(done, done); }, done);
    } else {
        send(state.reviewer || '').then(done, done);
    }
});

function exitProject(){
    if (BOOT.exitUrl) {
        location.href = BOOT.exitUrl;
    } else {
        // Fall back to the queue
        showQueue();
    }
}

// ---------- Admin: upload revision flow ----------
(function(){
    if (!BOOT.isAdmin) return;
    var dz = document.getElementById('cul-admin-dropzone');
    var input = document.getElementById('cul-admin-dropzone-input');
    if (!dz || !input) return;

    var staged = null; // { url, mime, filename }

    dz.addEventListener('click', function(){ input.click(); });
    input.addEventListener('change', function(e){ if (e.target.files[0]) handleFile(e.target.files[0]); e.target.value = ''; });
    ['dragenter','dragover'].forEach(function(ev){ dz.addEventListener(ev, function(e){ e.preventDefault(); dz.classList.add('is-dragover'); }); });
    ['dragleave','drop'].forEach(function(ev){ dz.addEventListener(ev, function(e){ e.preventDefault(); dz.classList.remove('is-dragover'); }); });
    dz.addEventListener('drop', function(e){
        var f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (f) handleFile(f);
    });

    function handleFile(file){
        var progress = document.getElementById('cul-admin-upload-progress');
        var stagedEl = document.getElementById('cul-admin-staged');
        stagedEl.hidden = true;
        progress.innerHTML = '<div class="cul-upload-row"><span class="cul-name"></span><div class="cul-bar"><div class="cul-bar-fill"></div></div><span class="cul-pct">0%</span></div>';
        progress.querySelector('.cul-name').textContent = file.name;

        var fd = new FormData();
        fd.append('file', file);
        var xhr = new XMLHttpRequest();
        xhr.open('POST', BOOT.restRoot + '/upload?token=' + state.token, true);
        xhr.setRequestHeader('X-WP-Nonce', BOOT.nonce);
        xhr.upload.onprogress = function(e){
            if (!e.lengthComputable) return;
            var pct = Math.round((e.loaded / e.total) * 100);
            progress.querySelector('.cul-bar-fill').style.width = pct + '%';
            progress.querySelector('.cul-pct').textContent = pct + '%';
        };
        xhr.onload = function(){
            if (xhr.status < 200 || xhr.status >= 300) {
                var msg = 'failed';
                try { msg = (JSON.parse(xhr.responseText).message || msg); } catch(e) {}
                progress.innerHTML = '<div class="cul-attach-error">Upload failed: ' + msg + '</div>';
                return;
            }
            var res = JSON.parse(xhr.responseText);
            staged = { url: res.url, mime: res.mime, filename: file.name };
            showStaged(staged);
            progress.innerHTML = '';
        };
        xhr.onerror = function(){ progress.innerHTML = '<div class="cul-attach-error">Network error</div>'; };
        xhr.send(fd);
    }

    function showStaged(s){
        var stagedEl = document.getElementById('cul-admin-staged');
        var thumb = document.getElementById('cul-admin-staged-thumb');
        var nm = document.getElementById('cul-admin-staged-name');
        var lbl = document.getElementById('cul-admin-staged-label');
        thumb.innerHTML = '';
        if (s.mime && s.mime.indexOf('image') === 0) {
            var img = document.createElement('img'); img.src = s.url; thumb.appendChild(img);
        } else if (s.mime && s.mime.indexOf('video') === 0) {
            var v = document.createElement('video'); v.src = s.url; v.muted = true; thumb.appendChild(v);
        } else {
            thumb.textContent = (s.filename.split('.').pop() || 'FILE').toUpperCase();
        }
        nm.textContent = s.filename;
        // Predict the auto-label
        var max = 0;
        state.files.forEach(function(f){
            var m = /^Version\s+(\d+)$/i.exec((f.label || '').trim());
            if (m) max = Math.max(max, parseInt(m[1], 10));
        });
        lbl.textContent = 'Will be saved as: Version ' + (max + 1);
        stagedEl.hidden = false;
    }

    document.getElementById('cul-admin-cancel').addEventListener('click', function(){
        staged = null;
        document.getElementById('cul-admin-staged').hidden = true;
    });

    document.getElementById('cul-admin-submit').addEventListener('click', function(){
        if (!staged) return;
        var current = fileById(state.activeFileId);
        if (!current) return;
        var doSupersede = document.getElementById('cul-admin-supersede').checked;
        var doNotify    = document.getElementById('cul-admin-notify').checked;
        var btn = document.getElementById('cul-admin-submit');
        btn.disabled = true; btn.textContent = 'Submitting…';
        api('/files?token=' + state.token, { method: 'POST', body: {
            url: staged.url,
            kind: '',
            label: '',
            supersede_file_id: doSupersede ? current.id : 0,
            notify: doNotify ? 1 : 0
        } }).then(function(newFile){
            state.files.unshift(newFile);
            if (doSupersede) current.status = 'superseded';
            staged = null;
            document.getElementById('cul-admin-staged').hidden = true;
            btn.disabled = false; btn.textContent = 'Submit revision';
            showToast('Revision saved as <strong>' + escapeHtml(newFile.label) + '</strong>' + (doNotify ? '. Reviewer notified.' : '.') + ' <a id="cul-toast-new">Open it →</a>');
            document.getElementById('cul-toast-new').onclick = function(){ openFile(newFile.id); document.getElementById('cul-toast').hidden = true; };
            openFile(newFile.id);
        }, function(err){
            btn.disabled = false; btn.textContent = 'Submit revision';
            alert('Could not save revision: ' + (err.message || 'error'));
        });
    });
})();

// ---------- Pin modal ----------
function openPinModal(pending){
    // Require an email identity before leaving any pin comment
    if (!state.reviewerEmail) {
        openIdentityModal().then(function(){ openPinModal(pending); }, function(){});
        return;
    }
    state.pendingPin = pending;
    state.pendingAttachment = null;
    var modal = document.getElementById('cul-pin-modal');
    document.getElementById('cul-pin-body').value = '';
    document.getElementById('cul-pin-attach-input').value = '';
    var preview = document.getElementById('cul-pin-attach-preview');
    preview.innerHTML = '';
    preview.hidden = true;
    document.getElementById('cul-pin-modal-title').textContent = pending.t_seconds != null
        ? 'Comment at ' + fmtTime(pending.t_seconds)
        : 'Leave a comment';
    modal.hidden = false;
    setTimeout(function(){ document.getElementById('cul-pin-body').focus(); }, 30);
}
function closePinModal(){ document.getElementById('cul-pin-modal').hidden = true; state.pendingPin = null; state.pendingAttachment = null; }

document.getElementById('cul-pin-attach-input').addEventListener('change', function(e){
    var file = e.target.files && e.target.files[0];
    if (!file) return;
    var preview = document.getElementById('cul-pin-attach-preview');
    preview.hidden = false;
    preview.innerHTML = '<div class="cul-attach-uploading">Uploading…</div>';
    var fd = new FormData();
    fd.append('file', file);
    fetch(BOOT.restRoot + '/upload?token=' + state.token, {
        method: 'POST',
        headers: { 'X-WP-Nonce': BOOT.nonce },
        body: fd
    }).then(function(r){ return r.json(); }).then(function(res){
        if (!res || !res.url) { preview.innerHTML = '<div class="cul-attach-error">Upload failed: ' + (res && res.message || 'try a different image') + '</div>'; return; }
        state.pendingAttachment = res.url;
        preview.innerHTML = '<img src="' + res.url + '" alt="reference"><button type="button" class="cul-attach-remove">Remove</button>';
        preview.querySelector('.cul-attach-remove').addEventListener('click', function(){
            state.pendingAttachment = null;
            preview.innerHTML = '';
            preview.hidden = true;
            document.getElementById('cul-pin-attach-input').value = '';
        });
    }).catch(function(){ preview.innerHTML = '<div class="cul-attach-error">Network error</div>'; });
});
document.querySelector('#cul-pin-modal .cul-btn-cancel').addEventListener('click', closePinModal);
document.querySelector('#cul-pin-modal .cul-btn-save').addEventListener('click', function(){
    var body = document.getElementById('cul-pin-body').value.trim();
    if (!body) return;
    var p = state.pendingPin;
    var author = state.reviewer || state.reviewerEmail;
    api('/pins?token=' + state.token, { method: 'POST', body: Object.assign({}, p, { body: body, author_name: author, author_email: state.reviewerEmail || '', attachment_url: state.pendingAttachment || '' }) }).then(function(pin){
        state.pins.push(pin);
        state.activePinId = pin.id;
        closePinModal();
        var f = fileById(state.activeFileId);
        if (f && pin.file_status) f.status = pin.file_status;
        if (f && pin.decisions) {
            state.decisions = state.decisions.filter(function(d){ return +d.file_id !== +f.id; })
                .concat(pin.decisions);
        }
        var iframe = document.querySelector('.cul-media-wrap iframe');
        if (f && f.kind === 'html' && iframe) {
            wireHtmlIframe(f, iframe);
        } else {
            renderStage();
        }
        renderPinList();
        renderFileList();
        updateStatusButtons();
    });
});

// ---------- Reviewer name ----------
function updateReviewerBtn(){
    var btn = document.getElementById('cul-reviewer-btn');
    var who = state.reviewerEmail || state.reviewer;
    btn.textContent = who || 'Add your email';
    btn.classList.toggle('is-empty', !who);
}
function openIdentityModal(){
    return new Promise(function(resolve, reject){
        var modal = document.getElementById('cul-identity-modal');
        var emailInput = document.getElementById('cul-identity-email');
        var errorEl    = document.getElementById('cul-identity-error');
        var saveBtn    = document.getElementById('cul-identity-save');
        var cancelBtn  = document.getElementById('cul-identity-cancel');
        emailInput.value = state.reviewerEmail || '';
        errorEl.hidden = true;
        modal.hidden = false;
        setTimeout(function(){ emailInput.focus(); emailInput.select(); }, 30);

        function cleanup(){ saveBtn.onclick = null; cancelBtn.onclick = null; emailInput.onkeydown = null; modal.hidden = true; }
        function commit(){
            var email = emailInput.value.trim();
            if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                errorEl.hidden = false;
                emailInput.focus();
                return;
            }
            // Email is the reviewer's identity — used as the display name too
            state.reviewerEmail = email;
            state.reviewer = email;
            localStorage.setItem('cul_review_email', email);
            localStorage.setItem('cul_review_name', email);
            updateReviewerBtn();
            cleanup();
            resolve(email);
        }
        saveBtn.onclick = commit;
        emailInput.onkeydown = function(e){ if (e.key === 'Enter') { e.preventDefault(); commit(); } };
        cancelBtn.onclick = function(){ cleanup(); reject(); };
    });
}

function ensureReviewerName(){
    if (state.reviewerEmail) return Promise.resolve(state.reviewerEmail);
    return openIdentityModal();
}

document.getElementById('cul-reviewer-btn').addEventListener('click', function(){
    openIdentityModal().catch(function(){});
});

// ---------- Help popover ----------
(function(){
    var btn = document.getElementById('cul-help-btn');
    var pop = document.getElementById('cul-help-popover');
    if (!btn || !pop) return;
    btn.addEventListener('click', function(e){
        e.stopPropagation();
        pop.hidden = !pop.hidden;
    });
    document.addEventListener('click', function(e){
        if (!pop.hidden && !pop.contains(e.target) && e.target !== btn) pop.hidden = true;
    });
})();

// ---------- Files collapse toggle ----------
(function(){
    var btn = document.getElementById('cul-files-toggle');
    if (!btn) return;
    btn.addEventListener('click', function(){
        var section = btn.closest('.cul-section-files');
        var expanded = btn.getAttribute('aria-expanded') !== 'false';
        var next = !expanded;
        btn.setAttribute('aria-expanded', next ? 'true' : 'false');
        section.classList.toggle('is-collapsed', !next);
    });
})();

// ---------- Keyboard shortcuts ----------
document.addEventListener('keydown', function(e){
    // Ignore typing in inputs/textareas
    var t = e.target;
    var inField = t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable);
    var modalOpen = !document.getElementById('cul-pin-modal').hidden;

    if (e.key === 'Escape') {
        if (modalOpen) { closePinModal(); e.preventDefault(); }
        return;
    }
    // Cmd/Ctrl+Enter inside pin modal posts
    if (modalOpen && (e.key === 'Enter') && (e.metaKey || e.ctrlKey)) {
        document.querySelector('#cul-pin-modal .cul-btn-save').click();
        e.preventDefault();
        return;
    }
    if (inField) return;

    if (e.key === 'j' || e.key === 'ArrowDown') { stepFile(1); e.preventDefault(); }
    else if (e.key === 'k' || e.key === 'ArrowUp') { stepFile(-1); e.preventDefault(); }
    else if (e.key === '+' || e.key === '=') { stepZoom(1); e.preventDefault(); }
    else if (e.key === '-' || e.key === '_') { stepZoom(-1); e.preventDefault(); }
    else if (e.key === '0') { resetZoom(); e.preventDefault(); }
    else if (e.key === 'f') { fitZoom(); e.preventDefault(); }
});

function stepFile(delta){
    if (!state.files.length) return;
    var idx = state.files.findIndex(function(f){ return +f.id === +state.activeFileId; });
    if (idx < 0) idx = 0;
    var next = Math.max(0, Math.min(state.files.length - 1, idx + delta));
    if (next !== idx) selectFile(state.files[next].id);
}

// ---------- Queue view ----------
function showQueue(){
    document.getElementById('cul-queue').hidden = false;
    document.getElementById('cul-layout').hidden = true;
    document.getElementById('cul-back-to-queue').hidden = true;
    var sw = document.getElementById('cul-version-switcher');
    if (sw) sw.hidden = true;
    renderQueue();
    if (history.replaceState) history.replaceState(null, '', location.pathname + location.search);
}
function showReview(){
    document.getElementById('cul-queue').hidden = true;
    document.getElementById('cul-layout').hidden = false;
    // Only show "All files" if there's more than one file (queue is useful)
    document.getElementById('cul-back-to-queue').hidden = state.files.length < 2;
}
function renderQueue(){
    var groups = { changes_requested: [], pending: [], approved: [], superseded: [] };
    state.files.forEach(function(f){
        if (f.status === 'superseded')               groups.superseded.push(f);
        else if (f.status === 'approved')            groups.approved.push(f);
        else if (f.status === 'changes_requested')   groups.changes_requested.push(f);
        else                                         groups.pending.push(f);
    });
    var total = state.files.length - groups.superseded.length; // exclude past versions from the headline count
    var done = groups.approved.length;
    var sub = document.getElementById('cul-queue-sub');
    sub.textContent = total === 0
        ? 'No files in this project yet.'
        : (done === total
            ? 'All ' + total + ' file' + (total > 1 ? 's' : '') + ' approved. ✓'
            : done + ' of ' + total + ' approved · ' + (total - done) + ' remaining');

    var container = document.getElementById('cul-queue-list');
    container.innerHTML = '';

    var sections = [
        { key: 'approved', label: 'Approved' },
        { key: 'pending', label: 'Needs review' },
        { key: 'changes_requested', label: 'Changes requested' }
    ];

    sections.forEach(function(s){
        if (!groups[s.key].length) return;
        var card = el('div', { class: 'cul-tasklist-card is-' + s.key });
        card.appendChild(el('div', { class: 'cul-tasklist-section' }, [
            el('span', { class: 'cul-status-pill is-' + s.key, text: s.label }),
            el('span', { class: 'cul-tasklist-count', text: String(groups[s.key].length) })
        ]));
        container.appendChild(card);

        groups[s.key].forEach(function(f){
            var thumb;
            if (f.kind === 'image') thumb = el('div', { class: 'cul-task-thumb' }, [ el('img', { src: f.url }) ]);
            else if (f.kind === 'video') thumb = el('div', { class: 'cul-task-thumb' }, [ el('video', { src: f.url, muted: 'muted' }) ]);
            else thumb = el('div', { class: 'cul-task-thumb', text: f.kind.toUpperCase() });

            var pinCount = pinsForFile(f.id).length;
            var parts = [];
            parts.push('Added ' + fmtDateTime(f.created_at));
            if (s.key === 'approved' && f.approved_at) {
                parts.push('✓ ' + (f.approved_by || 'Guest') + ' on ' + fmtDateTime(f.approved_at));
            } else if (pinCount) {
                parts.push(pinCount + ' comment' + (pinCount > 1 ? 's' : ''));
            }
            var rightText = parts.join(' · ');

            var filename = filenameFromUrl(f.url);
            var nameBlock = el('div', { class: 'cul-task-name' }, [
                el('span', { class: 'cul-task-label', text: f.label || ('File ' + f.id) }),
                filename ? el('span', { class: 'cul-task-filename', text: filename }) : null
            ]);
            var row = el('a', {
                class: 'cul-task-row',
                href: '#file=' + f.id,
                onclick: function(e){ e.preventDefault(); openFile(f.id); }
            }, [
                thumb,
                nameBlock,
                rightText ? el('div', { class: 'cul-task-meta', text: rightText }) : null,
                el('div', { class: 'cul-task-chevron', text: '›' })
            ]);
            card.appendChild(row);
        });
    });

    if (!total && !groups.superseded.length) {
        container.appendChild(el('div', { class: 'cul-queue-empty', text: 'No files in this project yet.' }));
    }

    // Past versions (default open)
    if (groups.superseded.length) {
        var pastBtn = el('button', {
            type: 'button',
            class: 'cul-past-toggle',
            text: 'Hide past versions',
            'aria-expanded': 'true'
        });
        var pastCard = el('div', { class: 'cul-tasklist-card is-superseded' });
        pastCard.appendChild(el('div', { class: 'cul-tasklist-section' }, [
            el('span', { class: 'cul-status-pill is-superseded', text: 'Past versions' }),
            el('span', { class: 'cul-tasklist-count', text: String(groups.superseded.length) })
        ]));
        groups.superseded.forEach(function(f){
            var thumb;
            if (f.kind === 'image') thumb = el('div', { class: 'cul-task-thumb' }, [ el('img', { src: f.url }) ]);
            else if (f.kind === 'video') thumb = el('div', { class: 'cul-task-thumb' }, [ el('video', { src: f.url, muted: 'muted' }) ]);
            else thumb = el('div', { class: 'cul-task-thumb', text: f.kind.toUpperCase() });
            var filename = filenameFromUrl(f.url);
            var nameBlock = el('div', { class: 'cul-task-name' }, [
                el('span', { class: 'cul-task-label', text: f.label || ('File ' + f.id) }),
                filename ? el('span', { class: 'cul-task-filename', text: filename }) : null
            ]);
            pastCard.appendChild(el('a', {
                class: 'cul-task-row',
                href: '#file=' + f.id,
                onclick: function(e){ e.preventDefault(); openFile(f.id); }
            }, [
                thumb,
                nameBlock,
                el('div', { class: 'cul-task-meta', text: 'Added ' + fmtDateTime(f.created_at) + ' · Superseded' }),
                el('div', { class: 'cul-task-chevron', text: '›' })
            ]));
        });
        pastBtn.addEventListener('click', function(){
            var open = pastBtn.getAttribute('aria-expanded') === 'true';
            pastBtn.setAttribute('aria-expanded', open ? 'false' : 'true');
            pastCard.hidden = open;
            pastBtn.textContent = open
                ? 'Show ' + groups.superseded.length + ' past version' + (groups.superseded.length > 1 ? 's' : '')
                : 'Hide past versions';
        });
        container.appendChild(pastBtn);
        container.appendChild(pastCard);
    }
}

function openFile(id){
    showReview();
    selectFile(id);
    if (history.replaceState) history.replaceState(null, '', location.pathname + location.search + '#file=' + id);
}

document.getElementById('cul-back-to-queue').addEventListener('click', showQueue);

// ---------- Toast ----------
var toastTimer = null;
function showToast(html){
    var t = document.getElementById('cul-toast');
    t.innerHTML = html;
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function(){ t.hidden = true; }, 4500);
}

// ---------- Mobile gate (hard block — no bypass) ----------
(function(){
    if (BOOT.previewOnly) return; // preview-only links work on any device
    var gate = document.getElementById('cul-mobile-gate');
    if (!gate) return;
    function check(){
        var isSmall = window.innerWidth < 760;
        gate.hidden = !isSmall;
        document.body.style.overflow = isSmall ? 'hidden' : '';
    }
    check();
    // Re-check on resize/rotate so it engages if they shrink the window
    window.addEventListener('resize', check);
})();

// ---------- Init ----------
updateReviewerBtn();
renderFileList();
renderPinList();

// Routing: ?#file=ID to deep-link to a file; else queue if 2+ files, else review.
function initRoute(){
    var m = /^#file=(\d+)$/.exec(location.hash);
    if (m) {
        var f = fileById(+m[1]);
        if (f) { openFile(f.id); return; }
    }
    // Always open the newest (top) active file — no multi-file queue.
    var active = state.files.filter(function(f){ return f.status !== 'superseded'; });
    if (active.length) openFile(active[0].id);
    else if (state.files.length) openFile(state.files[0].id);
    else showQueue();
}
initRoute();
window.addEventListener('hashchange', initRoute);

})();
