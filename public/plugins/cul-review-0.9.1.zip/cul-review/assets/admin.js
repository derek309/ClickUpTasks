(function($){
    $(function(){
        var $app = $('#cul-review-files-app');
        if (!$app.length) return;

        var files = [];
        try { files = JSON.parse($app.attr('data-files') || '[]'); } catch(e) {}
        files.forEach(function(f, i){ if (f.sort_order == null) f.sort_order = i; });

        function kindFromUrl(url, mime){
            if (mime && mime.indexOf('video') === 0) return 'video';
            if (mime && mime.indexOf('image') === 0) return 'image';
            var ext = (url.split('.').pop() || '').toLowerCase().split('?')[0];
            if (['mp4','webm','mov','m4v'].indexOf(ext) > -1) return 'video';
            if (['html','htm'].indexOf(ext) > -1) return 'html';
            if (['md','markdown'].indexOf(ext) > -1) return 'markdown';
            if (ext === 'txt') return 'text';
            if (ext === 'pdf') return 'pdf';
            return 'image';
        }

        function render(){
            var $tb = $('#cul-files-tbody').empty();
            files.forEach(function(f, idx){
                var preview;
                if (f.kind === 'image') preview = '<img src="'+f.url+'">';
                else if (f.kind === 'video') preview = '<video src="'+f.url+'" muted></video>';
                else preview = f.kind.toUpperCase();
                var done = (f.status === 'superseded');
                var $row = $('<tr>').html(
                    '<td><div class="cul-thumb">'+preview+'</div></td>' +
                    '<td><input type="text" class="cul-label" value="'+escapeAttr(f.label||'')+'" placeholder="e.g. Homepage hero"></td>' +
                    '<td>'+f.kind+'</td>' +
                    '<td><select class="cul-status">'+
                        opt('pending', 'Pending', f.status)+
                        opt('approved', 'Approved', f.status)+
                        opt('changes_requested', 'Changes requested', f.status)+
                        opt('superseded', 'Superseded', f.status)+
                    '</select></td>' +
                    '<td style="text-align:center"><label class="cul-done-wrap" title="Mark this revision complete (superseded)">'+
                        '<input type="checkbox" class="cul-done"'+(done?' checked':'')+'></label></td>' +
                    '<td><input type="number" class="cul-order" value="'+(f.sort_order|0)+'" style="width:60px"></td>' +
                    '<td><span class="cul-remove dashicons dashicons-trash"></span></td>'
                );
                if (done) $row.addClass('cul-row-done');
                $row.find('.cul-label').on('input', function(){ f.label = $(this).val(); });
                $row.find('.cul-status').on('change', function(){ f.status = $(this).val(); render(); });
                $row.find('.cul-done').on('change', function(){
                    f.status = $(this).is(':checked') ? 'superseded' : 'pending';
                    render();
                });
                $row.find('.cul-order').on('input', function(){ f.sort_order = parseInt($(this).val(),10) || 0; });
                $row.find('.cul-remove').on('click', function(){ files.splice(idx,1); render(); });
                $tb.append($row);
            });
            $('#cul-files-payload').val(JSON.stringify(files));
        }
        function opt(v,l,sel){ return '<option value="'+v+'"'+(sel===v?' selected':'')+'>'+l+'</option>'; }
        function escapeAttr(s){ return String(s).replace(/"/g,'&quot;').replace(/</g,'&lt;'); }
        function nextVersionNum(){
            var max = 0;
            files.forEach(function(f){
                var m = /^Version\s+(\d+)$/i.exec((f.label || '').trim());
                if (m) max = Math.max(max, parseInt(m[1], 10));
            });
            return max + 1;
        }
        function resequence(){ files.forEach(function(f, i){ f.sort_order = i; }); }
        function labelFromFilename(name){
            return name.replace(/\.[^.]+$/, '').replace(/[-_]+/g, ' ').replace(/^\w/, function(c){ return c.toUpperCase(); });
        }

        function offerSupersedePrevious(newFile){
            // Targets: any pre-existing file that's not the new one and isn't already superseded
            var targets = files.filter(function(f){
                return f !== newFile && f.status !== 'superseded';
            });
            if (!targets.length) return;
            // Show an inline prompt above the table
            var $existing = $('#cul-supersede-prompt');
            if ($existing.length) $existing.remove();
            var labels = targets.map(function(t){ return t.label || ('File ' + (t.id || '?')); }).join(', ');
            var $prompt = $(
                '<div id="cul-supersede-prompt" class="notice notice-info" style="margin:10px 0;padding:10px 14px;">' +
                    '<strong>New version added.</strong> Mark previous version' + (targets.length > 1 ? 's' : '') +
                    ' (' + escapeHtml(labels) + ') as <em>superseded</em>? Their open pins will auto-resolve.' +
                    ' <button type="button" class="button button-primary" id="cul-do-supersede" style="margin-left:8px">Yes, supersede</button>' +
                    ' <button type="button" class="button" id="cul-cancel-supersede">No, keep them</button>' +
                '</div>'
            );
            $('#cul-review-files-app').prepend($prompt);
            $prompt.find('#cul-do-supersede').on('click', function(){
                targets.forEach(function(t){ t.status = 'superseded'; });
                $prompt.remove();
                render();
            });
            $prompt.find('#cul-cancel-supersede').on('click', function(){ $prompt.remove(); });
        }
        function escapeHtml(s){ return String(s).replace(/[&<>"']/g, function(c){ return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]; }); }

        $('#cul-add-link').on('click', function(e){
            e.preventDefault();
            var url = prompt('Paste a URL to review (e.g. https://example.com/preview):');
            if (!url) return;
            url = url.trim();
            if (!/^https?:\/\//i.test(url)) { alert('URL must start with http:// or https://'); return; }
            var defaultLabel = 'Version ' + nextVersionNum();
            var label = prompt('Label for this link:', defaultLabel) || defaultLabel;
            var newFile = {
                id: 0,
                attachment_id: 0,
                kind: 'link',
                label: label,
                url: url,
                status: 'pending',
                sort_order: 0
            };
            files.unshift(newFile);
            resequence();
            render();
            offerSupersedePrevious(newFile);
        });

        $('#cul-add-files').on('click', function(e){
            e.preventDefault();
            var frame = wp.media({
                title: 'Add review files',
                multiple: true
            });
            frame.on('select', function(){
                var lastAdded = null;
                frame.state().get('selection').each(function(att){
                    var a = att.toJSON();
                    lastAdded = {
                        id: 0,
                        attachment_id: a.id,
                        kind: kindFromUrl(a.url, a.mime),
                        label: a.title ? labelFromFilename(a.title) : labelFromFilename((a.url || '').split('/').pop()),
                        url: a.url,
                        status: 'pending',
                        sort_order: 0
                    };
                    files.unshift(lastAdded);
                });
                resequence();
                render();
                if (lastAdded) offerSupersedePrevious(lastAdded);
            });
            frame.open();
        });

        // Drag-and-drop upload
        var $dz = $('#cul-dropzone');
        var $progress = $('#cul-upload-progress');
        $dz.on('click', function(){ $('#cul-dropzone-input').trigger('click'); });
        $('#cul-dropzone-input').on('change', function(e){ handleFiles(e.target.files); e.target.value = ''; });
        ['dragenter','dragover'].forEach(function(evt){
            $dz.on(evt, function(e){ e.preventDefault(); e.stopPropagation(); $dz.addClass('is-dragover'); });
        });
        ['dragleave','drop'].forEach(function(evt){
            $dz.on(evt, function(e){ e.preventDefault(); e.stopPropagation(); $dz.removeClass('is-dragover'); });
        });
        $dz.on('drop', function(e){
            var dt = e.originalEvent.dataTransfer;
            if (dt && dt.files && dt.files.length) handleFiles(dt.files);
        });

        function handleFiles(fileList){
            Array.prototype.forEach.call(fileList, uploadOne);
        }

        function uploadOne(file){
            var row = $('<div class="cul-upload-row"><span class="cul-name"></span><div class="cul-bar"><div class="cul-bar-fill"></div></div><span class="cul-pct">0%</span></div>');
            row.find('.cul-name').text(file.name);
            $progress.append(row);

            var isZip = /\.zip$/i.test(file.name);
            var xhr = new XMLHttpRequest();

            if (isZip) {
                var fd = new FormData();
                fd.append('file', file, file.name);
                xhr.open('POST', CUL_ADMIN.zipEndpoint + '?token=' + encodeURIComponent(CUL_ADMIN.projectToken), true);
                xhr.setRequestHeader('X-WP-Nonce', CUL_ADMIN.nonce);
                xhr.upload.onprogress = function(e){
                    if (!e.lengthComputable) return;
                    var pct = Math.round((e.loaded / e.total) * 100);
                    row.find('.cul-bar-fill').css('width', pct + '%');
                    row.find('.cul-pct').text(pct + '%');
                };
                xhr.onload = function(){
                    if (xhr.status >= 200 && xhr.status < 300) {
                        var resp;
                        try { resp = JSON.parse(xhr.responseText); } catch(e) {}
                        if (resp && resp.url) {
                            var newFile = {
                                id: 0,
                                attachment_id: 0,
                                kind: 'html',
                                label: labelFromFilename(file.name),
                                url: resp.url,
                                status: 'pending',
                                sort_order: 0
                            };
                            files.unshift(newFile);
                            resequence();
                            render();
                            row.remove();
                            offerSupersedePrevious(newFile);
                        } else {
                            row.addClass('is-error').find('.cul-pct').text('error');
                        }
                    } else {
                        var msg = 'failed';
                        try { msg = (JSON.parse(xhr.responseText).message || msg); } catch(e) {}
                        row.addClass('is-error').find('.cul-pct').text(msg);
                    }
                };
                xhr.onerror = function(){ row.addClass('is-error').find('.cul-pct').text('network error'); };
                xhr.send(fd);
            } else {
                xhr.open('POST', CUL_ADMIN.mediaEndpoint, true);
                xhr.setRequestHeader('X-WP-Nonce', CUL_ADMIN.nonce);
                xhr.setRequestHeader('Content-Disposition', 'attachment; filename="' + encodeURIComponent(file.name) + '"');
                xhr.setRequestHeader('Content-Type', file.type || 'application/octet-stream');
                xhr.upload.onprogress = function(e){
                    if (!e.lengthComputable) return;
                    var pct = Math.round((e.loaded / e.total) * 100);
                    row.find('.cul-bar-fill').css('width', pct + '%');
                    row.find('.cul-pct').text(pct + '%');
                };
                xhr.onload = function(){
                    if (xhr.status >= 200 && xhr.status < 300) {
                        var att;
                        try { att = JSON.parse(xhr.responseText); } catch(e) {}
                        if (att && att.source_url) {
                            var newFile = {
                                id: 0,
                                attachment_id: att.id,
                                kind: kindFromUrl(att.source_url, att.mime_type),
                                label: labelFromFilename(file.name),
                                url: att.source_url,
                                status: 'pending',
                                sort_order: 0
                            };
                            files.unshift(newFile);
                            resequence();
                            render();
                            row.remove();
                            offerSupersedePrevious(newFile);
                        } else {
                            row.addClass('is-error').find('.cul-pct').text('error');
                        }
                    } else {
                        var msg = 'failed';
                        try { msg = (JSON.parse(xhr.responseText).message || msg); } catch(e) {}
                        row.addClass('is-error').find('.cul-pct').text(msg);
                    }
                };
                xhr.onerror = function(){ row.addClass('is-error').find('.cul-pct').text('network error'); };
                xhr.send(file);
            }
        }

        // Keep payload up to date on submit
        $('form#post').on('submit', function(){ $('#cul-files-payload').val(JSON.stringify(files)); });

        render();
    });
})(jQuery);
