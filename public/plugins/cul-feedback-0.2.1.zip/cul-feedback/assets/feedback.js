// The bubble, the crosshair, and the little form. No framework and no build
// step: this runs on client sites we do not control, so it ships as one file
// that touches nothing outside its own ids.
(function () {
  var CFG = window.CUL_FEEDBACK;
  if (!CFG) return;

  // PHP says yes when it built this page for a reviewer. The flag cookie says
  // yes when a cache handed over a page PHP built for someone else.
  function flagged() {
    return document.cookie.split(/;\s*/).some(function (c) { return c === CFG.flag + "=1"; });
  }
  if (!CFG.show && !flagged()) return;

  // The stylesheet is fetched only now, so ordinary visitors never load it.
  if (CFG.css && !document.getElementById("cul-fb-css")) {
    var css = document.createElement("link");
    css.id = "cul-fb-css";
    css.rel = "stylesheet";
    css.href = CFG.css;
    document.head.appendChild(css);
  }

  var CATEGORIES = ["Copy", "Image", "Layout", "Link", "Other"];
  // The ClickUpTasks upload limit. Bigger photos are shrunk in the browser
  // first, because a phone photo is routinely 6MB and should not bounce.
  var MAX_BYTES = 5 * 1024 * 1024;
  var picking = false;
  var target = null;
  var wholePage = false;
  var category = "";
  var picture = null;

  // ---- the element you clicked, described well enough to find again -------
  // Not a unique selector for its own sake: an id when there is one, else the
  // tag and its position among siblings, four levels up. Enough to land on
  // the right thing by eye, which is what a person fixing it needs.
  function selectorFor(el) {
    var parts = [];
    var node = el;
    for (var depth = 0; node && node.nodeType === 1 && depth < 4; depth++) {
      if (node.id) { parts.unshift("#" + node.id); break; }
      var name = node.nodeName.toLowerCase();
      if (node.className && typeof node.className === "string") {
        var cls = node.className.trim().split(/\s+/).filter(function (c) { return c && c.indexOf("cul-fb") !== 0; })[0];
        if (cls) name += "." + cls;
      }
      var parent = node.parentNode;
      if (parent && parent.children && parent.children.length > 1) {
        var same = Array.prototype.filter.call(parent.children, function (c) { return c.nodeName === node.nodeName; });
        if (same.length > 1) name += ":nth-of-type(" + (Array.prototype.indexOf.call(same, node) + 1) + ")";
      }
      parts.unshift(name);
      node = parent;
    }
    return parts.join(" > ");
  }

  function textOf(el) {
    var t = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
    return t.length > 120 ? t.slice(0, 119) + "…" : t;
  }

  // The picture they meant: the image itself, or the only image inside
  // what they clicked when that has no words of its own (a linked logo, a
  // wrapper div a page builder put around a photo).
  function pictureIn(node) {
    if (!node) return null;
    if (node.nodeName === "IMG") return node;
    if (textOf(node) || !node.querySelectorAll) return null;
    var imgs = node.querySelectorAll("img");
    return imgs.length === 1 ? imgs[0] : null;
  }

  // What they clicked, in words they would use. "img" means nothing to a
  // client, so a picture is named by its description when it has one.
  function describe(node) {
    var img = pictureIn(node);
    if (img) return img.alt || "A picture";
    return textOf(node) || node.nodeName.toLowerCase();
  }

  // ---- chrome ------------------------------------------------------------
  var root = document.createElement("div");
  root.id = "cul-fb-root";
  root.setAttribute("data-side", CFG.side || "right");

  var bubble = document.createElement("button");
  bubble.id = "cul-fb-bubble";
  bubble.type = "button";
  bubble.title = CFG.strings.open;
  bubble.setAttribute("aria-label", CFG.strings.open);
  bubble.textContent = "?";

  var hint = document.createElement("div");
  hint.id = "cul-fb-hint";
  var hintText = document.createElement("span");
  hintText.textContent = CFG.strings.picking;
  // For what cannot be clicked: a missing section, the page as a whole.
  var pageBtn = document.createElement("button");
  pageBtn.type = "button";
  pageBtn.className = "cul-fb-pagebtn";
  pageBtn.textContent = "Or report the whole page";
  pageBtn.addEventListener("click", function () {
    target = null;
    wholePage = true;
    stopPicking();
    openPanel();
  });
  hint.appendChild(hintText);
  hint.appendChild(pageBtn);

  var halo = document.createElement("div");
  halo.id = "cul-fb-halo";

  var panel = document.createElement("div");
  panel.id = "cul-fb-panel";

  root.appendChild(bubble);
  root.appendChild(hint);
  root.appendChild(halo);
  root.appendChild(panel);
  document.addEventListener("DOMContentLoaded", function () { document.body.appendChild(root); });
  if (document.readyState !== "loading") document.body.appendChild(root);

  function toast(text, bad) {
    var t = document.createElement("div");
    t.className = "cul-fb-toast" + (bad ? " cul-fb-bad" : "");
    t.textContent = text;
    root.appendChild(t);
    setTimeout(function () { t.parentNode && t.parentNode.removeChild(t); }, 3600);
  }

  // ---- picking -----------------------------------------------------------
  function startPicking() {
    picking = true;
    document.body.classList.add("cul-fb-picking");
    hint.classList.add("cul-fb-on");
    closePanel();
  }

  function stopPicking() {
    picking = false;
    document.body.classList.remove("cul-fb-picking");
    hint.classList.remove("cul-fb-on");
    halo.classList.remove("cul-fb-on");
  }

  function ours(el) { return !!(el && el.closest && el.closest("#cul-fb-root")); }

  document.addEventListener("mousemove", function (e) {
    if (!picking) return;
    var el = e.target;
    if (ours(el)) { halo.classList.remove("cul-fb-on"); return; }
    var r = el.getBoundingClientRect();
    halo.style.top = (r.top + window.scrollY) + "px";
    halo.style.left = (r.left + window.scrollX) + "px";
    halo.style.width = r.width + "px";
    halo.style.height = r.height + "px";
    halo.classList.add("cul-fb-on");
  }, true);

  // Capture phase, and it stops the event: on a link or a button the click
  // would otherwise navigate away from the very thing being reported.
  document.addEventListener("click", function (e) {
    if (!picking || ours(e.target)) return;
    e.preventDefault();
    e.stopPropagation();
    target = e.target;
    wholePage = false;
    stopPicking();
    openPanel();
  }, true);

  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    if (picking) { stopPicking(); return; }
    if (panel.classList.contains("cul-fb-on")) closePanel();
  });

  // ---- the form ----------------------------------------------------------
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text) n.textContent = text;
    return n;
  }

  function button(cls, text) {
    var b = el("button", cls, text);
    b.type = "button";
    return b;
  }

  // Built in the order the client needs it: who they are (first time only),
  // what they clicked, what kind of problem, the new picture when a picture
  // is what they clicked, then their words and Send.
  function openPanel() {
    var img = wholePage ? null : pictureIn(target);
    category = img ? "Image" : "";
    picture = null;
    panel.innerHTML = "";

    var head = el("div", "cul-fb-head");
    head.appendChild(el("strong", "", "What is wrong here?"));
    var close = button("cul-fb-x", "✕");
    close.setAttribute("aria-label", "Close");
    close.addEventListener("click", closePanel);
    head.appendChild(close);
    panel.appendChild(head);

    // ---- who: asked once, then a one line reminder with a way to change it.
    // Staff never see either: WordPress already knows who they are.
    var nameBox = null;
    var who = null;
    var whoLast = false;
    if (CFG.askName) {
      who = el("div", "cul-fb-who");
      var askForName = function (value) {
        who.innerHTML = "";
        var label = el("label", "cul-fb-label", "Your name");
        label.setAttribute("for", "cul-fb-name");
        nameBox = el("input", "cul-fb-name");
        nameBox.id = "cul-fb-name";
        nameBox.type = "text";
        nameBox.placeholder = "So we know who to ask";
        nameBox.autocomplete = "name";
        nameBox.value = value;
        who.appendChild(label);
        who.appendChild(nameBox);
      };
      var known = remembered();
      if (known) {
        // Reads as a line of text, so it sits lower, next to Send.
        who.className = "cul-fb-from";
        who.appendChild(document.createTextNode("From " + known + " · "));
        var change = button("cul-fb-link", "change");
        change.addEventListener("click", function () {
          who.className = "cul-fb-who";
          whoLast = false;
          askForName(known);
          panel.insertBefore(who, what);
          nameBox.focus();
          nameBox.select();
        });
        who.appendChild(change);
        nameBox = { value: known };
        whoLast = true;
      } else {
        askForName("");
        panel.appendChild(who);
      }
    }

    // ---- what they clicked, with a thumbnail when it is a picture
    var what = el("div", "cul-fb-what");
    if (img && (img.currentSrc || img.src)) {
      var thumb = el("img", "cul-fb-thumb");
      thumb.alt = "";
      thumb.src = img.currentSrc || img.src;
      what.appendChild(thumb);
      what.className += " cul-fb-what-pic";
    }
    what.appendChild(el("span", "", wholePage ? "The whole page" : describe(target)));
    panel.appendChild(what);

    // ---- kind of problem: optional, and a second press takes it off again
    var chips = el("div", "cul-fb-chips");
    CATEGORIES.forEach(function (c) {
      var b = button("cul-fb-chip" + (c === category ? " cul-fb-chip-on" : ""), c);
      b.addEventListener("click", function () {
        var off = category === c;
        category = off ? "" : c;
        Array.prototype.forEach.call(chips.children, function (x) { x.classList.remove("cul-fb-chip-on"); });
        if (!off) b.classList.add("cul-fb-chip-on");
      });
      chips.appendChild(b);
    });
    panel.appendChild(chips);

    // ---- the new picture. A big button when they clicked a picture, since
    // swapping it is the likely reason; a quiet link everywhere else.
    var pic = el("div", "cul-fb-pic");
    var file = el("input", "cul-fb-file");
    file.type = "file";
    file.accept = "image/jpeg,image/png,image/gif,image/webp";
    var addPic;
    if (img) {
      addPic = button("cul-fb-addpic");
      addPic.appendChild(el("b", "", "+"));
      var words = el("span", "", "Add the new picture");
      words.appendChild(el("small", "", "JPG, PNG or WebP"));
      addPic.appendChild(words);
    } else {
      addPic = button("cul-fb-link cul-fb-attach", "Attach a picture");
    }
    var chosen = el("div", "cul-fb-chosen");
    addPic.addEventListener("click", function () { file.click(); });
    file.addEventListener("change", function () {
      var f = file.files && file.files[0];
      file.value = "";
      if (!f) return;
      if (!/^image\/(jpeg|png|gif|webp)$/.test(f.type)) { toast("That needs to be a JPG, PNG, GIF or WebP picture.", true); return; }
      addPic.disabled = true;
      chosen.textContent = "Getting it ready…";
      fitPicture(f).then(function (ready) {
        picture = ready;
        showChosen();
      }).catch(function (err) {
        toast(err && err.message ? err.message : "That picture could not be used.", true);
        showAdd();
      });
    });
    function showAdd() {
      picture = null;
      chosen.innerHTML = "";
      addPic.disabled = false;
      addPic.style.display = "";
    }
    function showChosen() {
      addPic.style.display = "none";
      chosen.innerHTML = "";
      var t = el("img");
      t.alt = "";
      t.src = URL.createObjectURL(picture);
      var remove = button("cul-fb-x", "✕");
      remove.setAttribute("aria-label", "Remove the picture");
      remove.addEventListener("click", showAdd);
      chosen.appendChild(t);
      chosen.appendChild(el("span", "", picture.name));
      chosen.appendChild(remove);
    }
    pic.appendChild(file);
    pic.appendChild(addPic);
    pic.appendChild(chosen);

    // ---- their words. Two lines to start, growing as they type.
    var box = el("textarea", "cul-fb-box");
    box.rows = 2;
    box.placeholder = img ? "What should change about this picture?"
      : wholePage ? "What is missing or wrong on this page?"
      : "What should it say or do instead?";
    function grow() {
      box.style.height = "auto";
      box.style.height = Math.min(box.scrollHeight + 2, 220) + "px";
    }

    if (img) { panel.appendChild(pic); panel.appendChild(box); }
    else { panel.appendChild(box); panel.appendChild(pic); }
    if (whoLast) panel.appendChild(who);

    // ---- footer: the promise on the left, Send on the right, asleep until
    // there is something to send.
    var foot = el("div", "cul-fb-foot");
    foot.appendChild(el("span", "cul-fb-note", CFG.strings.wait));
    var send = button("cul-fb-send", "Send");
    send.disabled = true;
    foot.appendChild(send);
    panel.appendChild(foot);

    function go() {
      if (send.disabled) return;
      submit(box.value, nameBox ? nameBox.value : "", send);
    }
    send.addEventListener("click", go);
    box.addEventListener("input", function () { send.disabled = !box.value.trim(); grow(); });
    box.addEventListener("keydown", function (e) {
      if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); go(); }
    });

    panel.classList.add("cul-fb-on");
    // A new face types their name first; everyone else starts on the words.
    (nameBox && nameBox.focus && !nameBox.value ? nameBox : box).focus();
  }

  function closePanel() {
    panel.classList.remove("cul-fb-on");
    halo.classList.remove("cul-fb-on");
    panel.innerHTML = "";
  }

  // ---- names and pictures -----------------------------------------------
  var NAME = "culFbName";
  function remembered() { try { return localStorage.getItem(NAME) || ""; } catch (e) { return ""; } }
  function remember(n) { try { localStorage.setItem(NAME, n); } catch (e) { /* private window */ } }

  // Under the limit it goes as it is, because a replacement picture should
  // arrive untouched. Over it, redrawn as a JPEG, starting at 3000px (still
  // more than any website needs) and stepping down until it fits. GIFs are
  // left alone: redrawing one keeps only its first frame.
  var STEPS = [[3000, 0.88], [2400, 0.82], [1800, 0.78], [1200, 0.75]];
  function fitPicture(f) {
    if (f.size <= MAX_BYTES) return Promise.resolve(f);
    if (f.type === "image/gif") return Promise.reject(new Error("That picture is over 5MB. Please email it to us instead."));
    return new Promise(function (resolve, reject) {
      var img = new Image();
      img.onload = function () {
        URL.revokeObjectURL(img.src);
        var name = f.name.replace(/\.[^.]+$/, "") + ".jpg";
        (function attempt(i) {
          if (i >= STEPS.length) { reject(new Error("That picture is too big to send. Please email it to us instead.")); return; }
          var scale = Math.min(1, STEPS[i][0] / Math.max(img.naturalWidth, img.naturalHeight));
          var c = document.createElement("canvas");
          c.width = Math.round(img.naturalWidth * scale);
          c.height = Math.round(img.naturalHeight * scale);
          c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
          c.toBlob(function (blob) {
            if (!blob || blob.size > MAX_BYTES) { attempt(i + 1); return; }
            resolve(new File([blob], name, { type: "image/jpeg" }));
          }, "image/jpeg", STEPS[i][1]);
        })(0);
      };
      img.onerror = function () { reject(new Error("That picture could not be opened.")); };
      img.src = URL.createObjectURL(f);
    });
  }

  function submit(message, name, sendBtn) {
    if (!message.trim()) return;
    name = name.trim();
    if (CFG.askName && name) remember(name);
    sendBtn.disabled = true;
    sendBtn.textContent = picture ? "Sending the picture…" : "Sending…";

    var headers = {};
    if (CFG.nonce) headers["X-WP-Nonce"] = CFG.nonce;

    // FormData rather than JSON, so a picture can travel with the words.
    var body = new FormData();
    body.append("message", message);
    body.append("category", category);
    body.append("name", name);
    body.append("url", location.href);
    body.append("page", document.title);
    body.append("scope", wholePage ? "page" : "element");
    body.append("selector", target ? selectorFor(target) : "");
    body.append("snippet", target ? textOf(target) : "");
    body.append("viewport", window.innerWidth + "x" + window.innerHeight);
    if (picture) body.append("image", picture, picture.name);

    fetch(CFG.endpoint, {
      method: "POST",
      credentials: "same-origin",
      headers: headers,
      body: body
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) { return { ok: r.ok, j: j }; });
    }).then(function (res) {
      if (!res.ok) throw new Error(res.j && res.j.error ? res.j.error : "failed");
      closePanel();
      toast(CFG.strings.sent, false);
    }).catch(function () {
      sendBtn.disabled = false;
      sendBtn.textContent = "Send";
      toast(CFG.strings.failed, true);
    });
  }

  // ---- what this is, once ------------------------------------------------
  // Shown the first time someone lands in review mode and never again, because
  // a bubble with no explanation is a bubble nobody presses, and an
  // explanation you have already read is noise. Kept to three sentences.
  var SEEN = "culFbIntroSeen";
  function seen() { try { return localStorage.getItem(SEEN) === "1"; } catch (e) { return false; } }
  function markSeen() { try { localStorage.setItem(SEEN, "1"); } catch (e) { /* private window */ } }

  function showIntro() {
    var card = document.createElement("div");
    card.id = "cul-fb-intro";
    var h = document.createElement("strong");
    h.textContent = "Something look wrong? Tell us here.";
    var p1 = document.createElement("p");
    p1.textContent = "Press the question mark, then click whatever is wrong on the page. Write one line about it and send. You can add a new picture too.";
    var p2 = document.createElement("p");
    p2.textContent = "We get the page and the exact spot with it, so you never have to explain where it was. Changes can take up to 72 business hours.";
    var ok = document.createElement("button");
    ok.type = "button";
    ok.className = "cul-fb-send";
    ok.textContent = "Got it";
    ok.addEventListener("click", function () { markSeen(); card.parentNode && card.parentNode.removeChild(card); });
    card.appendChild(h);
    card.appendChild(p1);
    card.appendChild(p2);
    card.appendChild(ok);
    root.appendChild(card);
  }

  if (!seen()) setTimeout(function () { if (!seen()) showIntro(); }, 900);

  bubble.addEventListener("click", function () {
    markSeen();
    var intro = document.getElementById("cul-fb-intro");
    if (intro && intro.parentNode) intro.parentNode.removeChild(intro);
    if (picking) { stopPicking(); return; }
    if (panel.classList.contains("cul-fb-on")) { closePanel(); return; }
    startPicking();
  });
})();
