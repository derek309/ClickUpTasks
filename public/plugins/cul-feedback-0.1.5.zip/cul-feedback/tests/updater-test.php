<?php
// Exercises CUL_Updater against the REAL live manifest for a given slug.
// Everything here is real except WordPress itself: the HTTP call goes out, the
// manifest is the one installed sites read, and the zip is the one core would
// download. What it does NOT cover is core's own unzip-and-swap, which is
// WordPress's code rather than ours.
//
//   php tests/updater-test.php cul-feedback
//   php tests/updater-test.php cul-review        (same class, other plugin)
//
// The scenarios run in separate processes because CUL_Updater's registry is
// static, so one process is one installed-version scenario. Re-runs itself.
// The class guards on ABSPATH, so without this it exits silently and the
// whole test file prints nothing at all.
define( 'ABSPATH', true );
define( 'HOUR_IN_SECONDS', 3600 );
define( 'MINUTE_IN_SECONDS', 60 );

$GLOBALS['transients'] = [];
$GLOBALS['http_calls'] = 0;

function get_transient( $k ) { return $GLOBALS['transients'][ $k ] ?? false; }
function set_transient( $k, $v, $t ) { $GLOBALS['transients'][ $k ] = $v; return true; }
function delete_transient( $k ) { unset( $GLOBALS['transients'][ $k ] ); return true; }
function plugin_basename( $f ) { return basename( dirname( $f ) ) . '/' . basename( $f ); }
function is_wp_error( $t ) { return $t instanceof WP_Error; }
class WP_Error { public $msg; function __construct( $m = '' ) { $this->msg = $m; } }
function add_filter( ...$a ) {}
function add_action( ...$a ) {}

function wp_remote_get( $url, $args = [] ) {
    $GLOBALS['http_calls']++;
    // curl, not file_get_contents: this CLI PHP has no CA bundle configured,
    // which is a quirk of Local's binary and not something the plugin sees.
    $ch = curl_init( $url );
    curl_setopt_array( $ch, [ CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15, CURLOPT_FOLLOWLOCATION => true ] );
    $body = curl_exec( $ch );
    $code = curl_getinfo( $ch, CURLINFO_HTTP_CODE );
    curl_close( $ch );
    if ( $body === false ) return new WP_Error( 'down' );
    return [ 'code' => $code, 'body' => $body ];
}
function wp_remote_retrieve_response_code( $r ) { return $r['code'] ?? 0; }
function wp_remote_retrieve_body( $r ) { return $r['body'] ?? ''; }

require dirname( __DIR__ ) . '/includes/class-cul-updater.php';

$slug     = $argv[1] ?? 'cul-feedback';
$scenario = $argv[2] ?? null;
$manifest = "https://clickuptasks.vercel.app/plugins/$slug.json";

$pass = 0; $fail = 0;
function check( $label, $cond ) {
    global $pass, $fail;
    if ( $cond ) { $pass++; echo "  ok    $label
"; }
    else         { $fail++; echo "  FAIL  $label
"; }
}

// No scenario given: run each in its own process and total them up.
if ( $scenario === null ) {
    $all = 0;
    foreach ( [ 'behind', 'uptodate', 'down', 'notobject' ] as $s ) {
        passthru( sprintf( '%s %s %s %s', escapeshellarg( PHP_BINARY ), escapeshellarg( __FILE__ ), escapeshellarg( $slug ), escapeshellarg( $s ) ), $code );
        $all = $all || $code;
    }
    echo $all ? "
SOMETHING FAILED
" : "
all scenarios passed
";
    exit( $all ? 1 : 0 );
}

// The live version, so this test does not need editing at every release.
$live = json_decode( wp_remote_retrieve_body( wp_remote_get( $manifest ) ), true );
if ( ! is_array( $live ) || empty( $live['version'] ) ) { echo "could not read $manifest
"; exit( 1 ); }
$behind = '0.0.1';

if ( $scenario === 'behind' ) {
    echo "
[$slug] an install behind the manifest:
";
    CUL_Updater::boot( [ 'slug' => $slug, 'file' => "/x/$slug/$slug.php", 'version' => $behind, 'manifest' => $manifest ] );
    $t = CUL_Updater::check( (object) [ 'response' => [], 'no_update' => [] ] );
    $e = $t->response[ "$slug/$slug.php" ] ?? null;
    check( 'offered an update', $e !== null );
    check( 'new_version matches the manifest', $e && $e->new_version === $live['version'] );
    check( 'package is https', $e && strpos( $e->package, 'https://' ) === 0 );
    check( 'slug matches the plugin folder', $e && $e->slug === $slug );
    $zip = $e ? wp_remote_get( $e->package ) : null;
    check( 'the zip URL resolves', $zip && ! is_wp_error( $zip ) && wp_remote_retrieve_response_code( $zip ) === 200 );
    check( 'and is really a zip', $zip && substr( wp_remote_retrieve_body( $zip ), 0, 2 ) === 'PK' );

    $d = CUL_Updater::details( false, 'plugin_information', (object) [ 'slug' => $slug ] );
    check( 'View details is answered', is_object( $d ) && ! empty( $d->name ) && ! empty( $d->download_link ) );
    check( 'another plugin slug is ignored', CUL_Updater::details( false, 'plugin_information', (object) [ 'slug' => 'akismet' ] ) === false );
    $calls = $GLOBALS['http_calls'];
    CUL_Updater::check( (object) [ 'response' => [], 'no_update' => [] ] );
    check( 'the manifest is cached, not re-fetched', $GLOBALS['http_calls'] === $calls );
    CUL_Updater::forget();
    CUL_Updater::check( (object) [ 'response' => [], 'no_update' => [] ] );
    check( 'forget() makes it fetch again', $GLOBALS['http_calls'] > $calls );
}

if ( $scenario === 'uptodate' ) {
    // Must land in no_update, NOT response. Report only the updates and the
    // Plugins screen shows "unknown" with no View details link at all.
    echo "
[$slug] an install already up to date:
";
    CUL_Updater::boot( [ 'slug' => $slug, 'file' => "/x/$slug/$slug.php", 'version' => $live['version'], 'manifest' => $manifest ] );
    $t = CUL_Updater::check( (object) [ 'response' => [], 'no_update' => [] ] );
    check( 'not offered an update', ! isset( $t->response[ "$slug/$slug.php" ] ) );
    check( 'still reported, in no_update', isset( $t->no_update[ "$slug/$slug.php" ] ) );
}

if ( $scenario === 'down' ) {
    // The guarantee that matters on a client site: wp-admin keeps working.
    echo "
[$slug] when the update server is unreachable:
";
    CUL_Updater::boot( [ 'slug' => 'cul-nope', 'file' => '/x/cul-nope/cul-nope.php', 'version' => '1.0.0',
        'manifest' => 'https://clickuptasks.vercel.app/plugins/does-not-exist.json' ] );
    $out = CUL_Updater::check( (object) [ 'response' => [], 'no_update' => [] ] );
    check( 'the transient comes back intact', is_object( $out ) );
    check( 'no bogus update offered', ! isset( $out->response['cul-nope/cul-nope.php'] ) );
    check( 'the failure is cached', ! empty( $GLOBALS['transients'] ) );
    $calls = $GLOBALS['http_calls'];
    CUL_Updater::check( (object) [ 'response' => [], 'no_update' => [] ] );
    check( 'a dead host is not re-hit every page load', $GLOBALS['http_calls'] === $calls );
    check( 'details() declines rather than erroring',
        CUL_Updater::details( false, 'plugin_information', (object) [ 'slug' => 'cul-nope' ] ) === false );
}

if ( $scenario === 'notobject' ) {
    // Core calls this filter before the transient exists in some flows.
    echo "
[$slug] when core passes a non-object:
";
    CUL_Updater::boot( [ 'slug' => $slug, 'file' => "/x/$slug/$slug.php", 'version' => $behind, 'manifest' => $manifest ] );
    check( 'false is handed straight back', CUL_Updater::check( false ) === false );
    check( 'null is handed straight back', CUL_Updater::check( null ) === null );
}

echo "  ($pass passed, $fail failed)
";
exit( $fail === 0 ? 0 : 1 );
