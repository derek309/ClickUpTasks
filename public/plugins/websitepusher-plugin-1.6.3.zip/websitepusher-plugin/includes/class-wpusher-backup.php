<?php
/**
 * WPusher_Backup
 *
 * Creates, restores, and manages server-side backups.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPusher_Backup {

	/**
	 * Get the backup directory path.
	 *
	 * @return string
	 */
	public static function get_backup_dir() {
		$upload_dir = wp_upload_dir();
		return trailingslashit( $upload_dir['basedir'] ) . 'websitepusher-backups';
	}

	/**
	 * Ensure the backup directory exists and is protected.
	 */
	public static function ensure_backup_directory() {
		$dir = self::get_backup_dir();

		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		// Prevent direct web access, on Apache 2.4 (Require) and 2.2 (Deny).
		$htaccess = trailingslashit( $dir ) . '.htaccess';
		$rules    = "<IfModule mod_authz_core.c>\n\tRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\n\tDeny from all\n</IfModule>\n";
		if ( ! file_exists( $htaccess ) || ! str_contains( (string) file_get_contents( $htaccess ), 'Require all denied' ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			file_put_contents( $htaccess, $rules ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		$index = trailingslashit( $dir ) . 'index.php';
		if ( ! file_exists( $index ) ) {
			file_put_contents( $index, "<?php // Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}
	}

	/**
	 * Create a ZIP backup of a directory.
	 *
	 * @param  string $source_dir  Directory to back up.
	 * @param  string $label       Label for the backup filename.
	 * @return string|WP_Error     Path to the created backup ZIP.
	 */
	public static function create_backup( $source_dir, $label ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'no_zip', 'ZipArchive PHP extension is required.' );
		}

		if ( ! is_dir( $source_dir ) ) {
			return new WP_Error( 'not_found', "Source directory not found: {$source_dir}" );
		}

		self::ensure_backup_directory();

		// A random part, so a backup's name can't be guessed (1.6.3).
		$filename    = sanitize_file_name( "backup_{$label}_" . gmdate( 'Y-m-d_His' ) . '_' . wp_generate_password( 10, false, false ) . '.zip' );
		$backup_path = trailingslashit( self::get_backup_dir() ) . $filename;

		$zip    = new ZipArchive();
		$opened = $zip->open( $backup_path, ZipArchive::CREATE | ZipArchive::OVERWRITE );

		if ( true !== $opened ) {
			return new WP_Error( 'zip_create', "Could not create backup ZIP (code: {$opened})." );
		}

		$source_dir = trailingslashit( realpath( $source_dir ) );
		$iterator   = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $source_dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::LEAVES_ONLY
		);

		foreach ( $iterator as $file ) {
			if ( $file->isFile() ) {
				$relative = substr( $file->getRealPath(), strlen( $source_dir ) );
				$zip->addFile( $file->getRealPath(), $relative );
			}
		}

		$zip->close();

		if ( ! file_exists( $backup_path ) ) {
			return new WP_Error( 'zip_missing', 'Backup ZIP was not created.' );
		}

		return $backup_path;
	}

	/**
	 * Restore a backup ZIP to a target directory.
	 *
	 * @param  string $backup_path Path to the backup ZIP.
	 * @param  string $target_dir  Directory to restore into.
	 * @return true|WP_Error
	 */
	public static function restore_backup( $backup_path, $target_dir ) {
		if ( ! class_exists( 'ZipArchive' ) ) {
			return new WP_Error( 'no_zip', 'ZipArchive PHP extension is required.' );
		}

		if ( ! file_exists( $backup_path ) ) {
			return new WP_Error( 'not_found', "Backup not found: {$backup_path}" );
		}

		// Only one of our own backups (not a held release upload or anything
		// else in the folder), and only over one theme or plugin folder (1.6.3).
		$real = realpath( $backup_path );
		$home = realpath( self::get_backup_dir() );
		if ( ! $real || ! $home || dirname( $real ) !== $home || ! preg_match( '/^backup_.+\.zip$/', basename( $real ) ) ) {
			return new WP_Error( 'invalid_path', 'Invalid backup path.', array( 'status' => 400 ) );
		}
		$safe = WPusher_Security::validate_restore_target( $target_dir );
		if ( is_wp_error( $safe ) ) {
			return $safe;
		}

		$zip    = new ZipArchive();
		$opened = $zip->open( $real );

		if ( true !== $opened ) {
			return new WP_Error( 'zip_open', "Could not open backup ZIP (code: {$opened})." );
		}

		// Every entry checked before anything is cleared: no absolute paths,
		// no "..", nowhere outside the folder.
		$entries = array();
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$name = str_replace( '\\', '/', (string) $zip->getNameIndex( $i ) );
			if ( str_ends_with( $name, '/' ) ) {
				continue;
			}
			if ( '' === $name || str_contains( $name, "\0" ) || str_starts_with( $name, '/' ) || preg_match( '#^[A-Za-z]:#', $name ) || preg_match( '#(^|/)\.\.(/|$)#', $name ) ) {
				$zip->close();
				return new WP_Error( 'unsafe_backup', "Refused: the backup has an unsafe path: {$name}" );
			}
			$entries[ $i ] = $name;
		}

		self::clear_directory( $target_dir );

		$base = untrailingslashit( $target_dir );
		foreach ( $entries as $i => $name ) {
			$dest = $base . '/' . $name;
			wp_mkdir_p( dirname( $dest ) );
			if ( false === file_put_contents( $dest, $zip->getFromIndex( $i ) ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
				$zip->close();
				return new WP_Error( 'extract_failed', "Could not restore {$name}." );
			}
		}
		$zip->close();

		return true;
	}

	/**
	 * Remove old backups beyond the retention count.
	 *
	 * @param int $keep Number of backups to keep.
	 */
	public static function cleanup_old_backups( $keep = 10 ) {
		$dir   = self::get_backup_dir();
		$files = glob( trailingslashit( $dir ) . '*.zip' );

		if ( ! $files || count( $files ) <= $keep ) {
			return;
		}

		// Sort oldest first.
		usort( $files, function( $a, $b ) {
			return filemtime( $a ) - filemtime( $b );
		} );

		$to_delete = array_slice( $files, 0, count( $files ) - $keep );

		foreach ( $to_delete as $file ) {
			if ( file_exists( $file ) ) {
				unlink( $file );
			}
		}
	}

	/**
	 * Clear all files from a directory without removing the directory itself.
	 *
	 * @param string $dir Directory to clear.
	 */
	private static function clear_directory( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}

		$iterator = new RecursiveIteratorIterator(
			new RecursiveDirectoryIterator( $dir, RecursiveDirectoryIterator::SKIP_DOTS ),
			RecursiveIteratorIterator::CHILD_FIRST
		);

		foreach ( $iterator as $item ) {
			if ( $item->isDir() ) {
				rmdir( $item->getRealPath() );
			} else {
				if ( file_exists( $item->getRealPath() ) ) {
					unlink( $item->getRealPath() );
				}
			}
		}
	}
}
