<?php
/**
 * WPusher_Release
 *
 * Changes held for the site owner's review (1.6.0, Derek 2026-10-12: "do we
 * have a site owner and they have to review things before they go out if
 * someone else is working on it").
 *
 * When someone who isn't the site's owner finishes, the app sends live the
 * same requests it would for a push (theme, plugin and image files through
 * /deploy, pages through /content/push) with `hold` set to a release id. Each
 * is stored here instead of applied: its upload and its settings, one step per
 * request. The owner then approves from their own computer, and /release/apply
 * replays every step through the very same code a push runs, so backups, undo,
 * the health check and the page-conflict check all work as they always do. Or
 * they send it back, and the stored uploads are deleted.
 *
 *   GET  /release?id=      what's held: who, when, the note, each step
 *   POST /release/apply    { id, force }  apply it; force overwrites pages edited on live since
 *   POST /release/discard  { id, reason } send it back
 *
 * Pages are applied first: they're the part that can be refused (edited on
 * live since), and that refusal writes nothing, so nothing is half-applied.
 *
 * Kept in uploads/websitepusher-backups/held/<id>/ (no web access, never
 * pulled). Releases nobody acted on are removed after 30 days.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPusher_Release {

	const KEEP_DAYS = 30;
	const MAX_STEPS = 40;

	/**
	 * The stored upload for the step being replayed. Read by the upload
	 * handlers of /deploy and /content/push in place of a real upload; never
	 * set from a request.
	 *
	 * @var string|null
	 */
	public static $replay_zip = null;

	/**
	 * True while a release is being applied: the lock was checked once, for
	 * the whole release, so the steps don't check it again.
	 *
	 * @var bool
	 */
	public static $replaying = false;

	public static function register_routes( $ns, $auth ) {
		register_rest_route( $ns, '/release',         array( 'methods' => 'GET',  'callback' => array( __CLASS__, 'get' ),     'permission_callback' => $auth ) );
		register_rest_route( $ns, '/release/apply',   array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'apply' ),   'permission_callback' => $auth ) );
		register_rest_route( $ns, '/release/discard', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'discard' ), 'permission_callback' => $auth ) );
	}

	/**
	 * Whether a request asks for its changes to be held. Any non-empty `hold`
	 * counts, valid or not: one that isn't a proper id is refused by hold(),
	 * never treated as a normal push that goes straight live.
	 *
	 * @param WP_REST_Request $request The request.
	 * @return bool
	 */
	public static function wants_hold( WP_REST_Request $request ) {
		return ! self::$replaying && '' !== (string) $request->get_param( 'hold' );
	}

	/**
	 * Store a /deploy or /content/push request as the next step of a release.
	 *
	 * @param WP_REST_Request $request The request.
	 * @param string          $kind    'deploy' or 'content'.
	 * @return WP_REST_Response
	 */
	public static function hold( WP_REST_Request $request, $kind ) {
		$id = (string) $request->get_param( 'hold' );
		if ( ! preg_match( '/^[A-Za-z0-9_-]{8,64}$/', $id ) ) {
			return new WP_REST_Response( array( 'message' => 'That isn\'t a valid release id, so nothing was held or put live.' ), 400 );
		}
		$dir = self::dir( $id );
		self::cleanup();
		wp_mkdir_p( $dir );

		$meta = self::meta( $id );
		if ( ! $meta ) {
			$meta = array(
				'id'      => $id,
				'status'  => 'held',
				'by'      => WPusher_Team::actor( $request ),
				'created' => gmdate( 'c' ),
				'note'    => '',
				'steps'   => array(),
			);
		}
		if ( 'held' !== $meta['status'] ) {
			return new WP_REST_Response( array( 'message' => 'That release has already been ' . self::said( $meta['status'] ) . '.' ), 409 );
		}
		if ( count( $meta['steps'] ) >= self::MAX_STEPS ) {
			return new WP_REST_Response( array( 'message' => 'Too many parts in one release.' ), 400 );
		}

		$n    = count( $meta['steps'] ) + 1;
		$zip  = null;
		$list = array();
		$file = $request->get_file_params()['zip_file'] ?? null;
		if ( $file && empty( $file['error'] ) ) {
			$zip = $n . '.zip';
			if ( ! move_uploaded_file( $file['tmp_name'], $dir . '/' . $zip ) ) {
				return new WP_REST_Response( array( 'message' => 'Could not store the upload for review.' ), 500 );
			}
			$list = self::zip_names( $dir . '/' . $zip );
		}

		$params = array();
		foreach ( array( 'type', 'plugin_slug', 'note', 'via', 'payload' ) as $k ) {
			$v = $request->get_param( $k );
			if ( null !== $v && '' !== $v ) {
				$params[ $k ] = is_scalar( $v ) ? (string) $v : $v;
			}
		}
		$params['deletions'] = array_values( array_map( 'strval', (array) ( $request->get_param( 'deletions' ) ?? array() ) ) );

		// What this step is, in words, for the owner's review.
		$summary = array( 'kind' => $kind );
		if ( 'content' === $kind ) {
			$payload            = json_decode( (string) ( $params['payload'] ?? '' ), true );
			$summary['titles']  = array();
			foreach ( (array) ( $payload['items'] ?? array() ) as $it ) {
				$summary['titles'][] = array(
					'title' => (string) ( $it['label'] ?? $it['post']['post_title'] ?? '' ),
					'type'  => (string) ( $it['post']['post_type'] ?? '' ),
					'new'   => empty( $it['live_id'] ),
				);
			}
			$summary['removed'] = count( (array) ( $payload['deletes'] ?? array() ) );
			$summary['images']  = count( $list );
			if ( '' === $meta['note'] && ! empty( $payload['note'] ) ) {
				$meta['note'] = sanitize_text_field( (string) $payload['note'] );
			}
		} else {
			$summary['type']      = sanitize_key( $params['type'] ?? 'theme' );
			$summary['slug']      = sanitize_key( $params['plugin_slug'] ?? '' );
			$summary['files']     = array_slice( $list, 0, 500 );
			$summary['deletions'] = array_slice( $params['deletions'], 0, 500 );
			if ( '' === $meta['note'] && ! empty( $params['note'] ) ) {
				$meta['note'] = sanitize_text_field( (string) $params['note'] );
			}
		}

		$meta['steps'][] = array(
			'n'       => $n,
			'kind'    => $kind,
			'zip'     => $zip,
			'params'  => $params,
			'summary' => $summary,
		);
		self::save( $meta );

		// Shaped like the push's own answer, so the app reads it the same way.
		return new WP_REST_Response(
			array(
				'status'         => 'success',
				'held'           => true,
				'release'        => $id,
				'step'           => $n,
				'files_deployed' => 'deploy' === $kind ? $list : array(),
				'files_deleted'  => 'deploy' === $kind ? $params['deletions'] : array(),
				'pushed'         => 'content' === $kind ? wp_list_pluck( $summary['titles'], 'title' ) : array(),
			),
			200
		);
	}

	/**
	 * GET /release?id=
	 */
	public static function get( WP_REST_Request $request ) {
		$meta = self::meta( (string) $request->get_param( 'id' ) );
		if ( ! $meta ) {
			return new WP_REST_Response( array( 'message' => 'No such release on this website.' ), 404 );
		}
		return new WP_REST_Response( self::public_view( $meta ), 200 );
	}

	/**
	 * POST /release/apply — put a held release live.
	 */
	public static function apply( WP_REST_Request $request ) {
		@set_time_limit( 600 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		$id   = (string) $request->get_param( 'id' );
		$meta = self::meta( $id );
		if ( ! $meta ) {
			return new WP_REST_Response( array( 'message' => 'No such release on this website.' ), 404 );
		}
		if ( 'held' !== $meta['status'] ) {
			return new WP_REST_Response( array( 'message' => 'That release has already been ' . self::said( $meta['status'] ) . '.', 'release' => self::public_view( $meta ) ), 409 );
		}

		// Locked by a third person: they're mid-work, so wait for them. The
		// person whose work this is may hold it again already; that's fine.
		$c   = WPusher_Team::get_checkout();
		$who = WPusher_Team::actor( $request );
		if ( $c && strcasecmp( $c['who'], $who ) && strcasecmp( $c['who'], (string) $meta['by'] ) ) {
			return new WP_REST_Response(
				array(
					'code'     => 'locked',
					'message'  => sprintf( 'Locked by %s, who is working on this website now. Approve it once they unlock it.', $c['who'] ),
					'checkout' => $c,
				),
				423
			);
		}

		$force = (bool) $request->get_param( 'force' );
		$steps = $meta['steps'];
		usort( $steps, function ( $a, $b ) {
			return ( 'content' === $b['kind'] ) <=> ( 'content' === $a['kind'] ) ?: $a['n'] <=> $b['n'];
		} );

		$dir     = self::dir( $id );
		$results = array();
		$applied = 0;
		$note    = sprintf( 'Approved by %s: %s', $who ?: 'the owner', $meta['note'] ?: 'changes from ' . $meta['by'] );

		self::$replaying = true;
		try {
			foreach ( $steps as $s ) {
				$r = new WP_REST_Request( 'POST', '/websitepusher/v1/' . ( 'content' === $s['kind'] ? 'content/push' : 'deploy' ) );
				$r->set_header( 'X-WPusher-Actor', $who );
				$params = $s['params'];
				if ( 'content' === $s['kind'] ) {
					$payload = json_decode( (string) ( $params['payload'] ?? '' ), true );
					if ( ! is_array( $payload ) ) {
						$payload = array();
					}
					$payload['note'] = $note;
					if ( $force ) {
						$payload['force'] = true;
					}
					$params['payload'] = wp_json_encode( $payload );
				} else {
					$params['note'] = $note;
				}
				foreach ( $params as $k => $v ) {
					$r->set_param( $k, $v );
				}

				// A copy: the push handlers delete the upload when they're done.
				self::$replay_zip = null;
				if ( $s['zip'] && file_exists( $dir . '/' . $s['zip'] ) ) {
					self::$replay_zip = get_temp_dir() . 'wpusher_release_' . uniqid() . '.zip';
					copy( $dir . '/' . $s['zip'], self::$replay_zip );
				}

				$res = 'content' === $s['kind'] ? WPusher_Content::push( $r ) : WPusher_API::get_instance()->deploy( $r );
				if ( self::$replay_zip && file_exists( self::$replay_zip ) ) {
					unlink( self::$replay_zip );
				}
				self::$replay_zip = null;

				$status = $res instanceof WP_REST_Response ? $res->get_status() : 500;
				$data   = $res instanceof WP_REST_Response ? $res->get_data() : array( 'message' => 'Unexpected answer.' );
				$results[] = array( 'n' => $s['n'], 'kind' => $s['kind'], 'status' => $status, 'data' => $data );

				if ( 200 !== $status ) {
					// Pages edited on live since, before anything was written:
					// the owner decides, and can apply again with force.
					if ( 409 === $status && ! $applied && ! empty( $data['conflicts'] ) ) {
						return new WP_REST_Response(
							array(
								'error'     => 'conflict',
								'message'   => 'Some of these pages were edited on the live website since.',
								'conflicts' => $data['conflicts'],
							),
							409
						);
					}
					$meta['status']  = $applied ? 'partial' : 'held';
					$meta['results'] = $results;
					self::save( $meta );
					return new WP_REST_Response(
						array(
							'message' => ( $applied ? 'Part of it went live, then this failed: ' : 'Nothing went live: ' ) . ( $data['message'] ?? 'HTTP ' . $status ),
							'release' => self::public_view( $meta ),
						),
						422
					);
				}
				++$applied;
			}
		} finally {
			self::$replaying  = false;
			self::$replay_zip = null;
		}

		$meta['status']     = 'applied';
		$meta['applied_by'] = $who;
		$meta['applied_at'] = gmdate( 'c' );
		$meta['results']    = $results;
		self::save( $meta );
		self::drop_uploads( $id );

		return new WP_REST_Response( array( 'ok' => true, 'release' => self::public_view( $meta ) ), 200 );
	}

	/**
	 * POST /release/discard — sent back; the held uploads go.
	 */
	public static function discard( WP_REST_Request $request ) {
		$id   = (string) $request->get_param( 'id' );
		$meta = self::meta( $id );
		if ( ! $meta ) {
			return new WP_REST_Response( array( 'message' => 'No such release on this website.' ), 404 );
		}
		if ( 'held' !== $meta['status'] ) {
			return new WP_REST_Response( array( 'message' => 'That release has already been ' . self::said( $meta['status'] ) . '.' ), 409 );
		}
		$meta['status']  = 'sent_back';
		$meta['sent_by'] = WPusher_Team::actor( $request );
		$meta['sent_at'] = gmdate( 'c' );
		$meta['reason']  = sanitize_textarea_field( (string) $request->get_param( 'reason' ) );
		self::save( $meta );
		self::drop_uploads( $id );
		return new WP_REST_Response( array( 'ok' => true, 'release' => self::public_view( $meta ) ), 200 );
	}

	// ── Storage ─────────────────────────────────────────────────────────────

	private static function root() {
		WPusher_Backup::ensure_backup_directory();
		return WPusher_Backup::get_backup_dir() . '/held';
	}

	private static function dir( $id ) {
		return self::root() . '/' . $id;
	}

	private static function meta( $id ) {
		if ( ! preg_match( '/^[A-Za-z0-9_-]{8,64}$/', $id ) ) {
			return null;
		}
		$f = self::dir( $id ) . '/release.json';
		if ( ! file_exists( $f ) ) {
			return null;
		}
		$m = json_decode( (string) file_get_contents( $f ), true ); // phpcs:ignore
		return is_array( $m ) ? $m : null;
	}

	private static function save( array $meta ) {
		$dir = self::dir( $meta['id'] );
		wp_mkdir_p( $dir );
		if ( ! file_exists( $dir . '/index.php' ) ) {
			file_put_contents( $dir . '/index.php', "<?php // Silence is golden.\n" ); // phpcs:ignore
		}
		file_put_contents( $dir . '/release.json', wp_json_encode( $meta ) ); // phpcs:ignore
	}

	private static function drop_uploads( $id ) {
		foreach ( (array) glob( self::dir( $id ) . '/*.zip' ) as $z ) {
			unlink( $z );
		}
	}

	/** Releases left untouched for KEEP_DAYS, uploads and all. */
	private static function cleanup() {
		$cut = time() - self::KEEP_DAYS * DAY_IN_SECONDS;
		foreach ( (array) glob( self::root() . '/*', GLOB_ONLYDIR ) as $d ) {
			if ( filemtime( $d . '/release.json' ) < $cut ) {
				foreach ( (array) glob( $d . '/*' ) as $f ) {
					unlink( $f );
				}
				rmdir( $d );
			}
		}
	}

	private static function zip_names( $path ) {
		$out = array();
		$zip = new ZipArchive();
		if ( true === $zip->open( $path ) ) {
			for ( $i = 0; $i < $zip->numFiles; $i++ ) {
				$name = $zip->getNameIndex( $i );
				if ( ! str_ends_with( $name, '/' ) ) {
					$out[] = $name;
				}
			}
			$zip->close();
		}
		return $out;
	}

	/** The release as the app sees it: no stored payloads. */
	private static function public_view( array $meta ) {
		$view          = $meta;
		$view['steps'] = array_map(
			function ( $s ) {
				return array( 'n' => $s['n'], 'kind' => $s['kind'], 'summary' => $s['summary'] );
			},
			$meta['steps']
		);
		return $view;
	}

	private static function said( $status ) {
		return array( 'applied' => 'approved and put live', 'sent_back' => 'sent back', 'partial' => 'partly applied' )[ $status ] ?? $status;
	}
}
