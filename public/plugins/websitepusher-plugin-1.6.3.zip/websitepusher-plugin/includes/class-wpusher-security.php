<?php
/**
 * WPusher_Security
 *
 * All security decisions in one place:
 * - Allowed/blocked file extensions
 * - Path traversal prevention
 * - API key verification (timing-safe)
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPusher_Security {

	const ALLOWED_EXTENSIONS = array(
		'php', 'css', 'js', 'json', 'html', 'htm',
		'txt', 'md', 'svg', 'png', 'jpg', 'jpeg',
		'webp', 'gif', 'ico', 'woff', 'woff2', 'ttf',
		'eot', 'otf', 'scss', 'map', 'xml', 'mo', 'po',
		'pot', 'lock', 'gitignore', 'env.example',
	);

	const BLOCKED_EXTENSIONS = array(
		'exe', 'sh', 'bash', 'bat', 'cmd', 'ps1',
		'phar', 'py', 'rb', 'pl', 'cgi', 'perl',
		'asp', 'aspx', 'jsp', 'so', 'dll', 'bin',
	);

	/**
	 * Verify API key using timing-safe comparison.
	 *
	 * @param WP_REST_Request $request The REST request.
	 * @return bool
	 */
	public static function verify_api_key( WP_REST_Request $request ) {
		$supplied = $request->get_header( 'X-WPusher-API-Key' );
		// Backwards compatibility with older app versions.
		if ( empty( $supplied ) ) {
			$supplied = $request->get_header( 'X-TP-API-Key' );
		}

		$stored = self::get_api_key();

		if ( empty( $supplied ) || empty( $stored ) ) {
			return false;
		}

		return hash_equals( $stored, $supplied );
	}

	/**
	 * Resolve the active connection code.
	 *
	 * A WPUSHER_API_KEY constant (defined in wp-config.php) always wins over the
	 * stored option. The constant lives outside the database, so it is immune to
	 * full-site copies (local → staging → live) that carry wp_options along and
	 * would otherwise overwrite each environment's key. Define the SAME constant
	 * in every environment's wp-config.php and one connection code works everywhere.
	 *
	 * @return string
	 */
	public static function get_api_key() {
		if ( defined( 'WPUSHER_API_KEY' ) && WPUSHER_API_KEY ) {
			return (string) WPUSHER_API_KEY;
		}
		return (string) get_option( 'wpusher_api_key', '' );
	}

	/**
	 * Whether the connection code is pinned by a wp-config constant.
	 *
	 * @return bool
	 */
	public static function is_api_key_locked() {
		return defined( 'WPUSHER_API_KEY' ) && WPUSHER_API_KEY;
	}

	/**
	 * Validate a path from a ZIP file.
	 * Blocks traversal, null bytes, absolute paths, and dangerous extensions.
	 *
	 * @param  string $zip_path   Path as it appears in the ZIP.
	 * @param  string $target_dir Absolute path to the target directory.
	 * @return true|WP_Error
	 */
	public static function validate_zip_path( $zip_path, $target_dir ) {
		$zip_path = str_replace( '\\', '/', $zip_path );

		// Our own backups and held releases live in uploads; a media push must
		// never write over them (1.6.3).
		$uploads = realpath( wp_get_upload_dir()['basedir'] );
		if ( $uploads && realpath( $target_dir ) === $uploads && preg_match( '#^/*websitepusher-backups(/|$)#i', $zip_path ) ) {
			return new WP_Error( 'reserved', "Blocked: WebsitePusher's own backups folder: {$zip_path}" );
		}

		if ( str_starts_with( $zip_path, '/' ) ) {
			return new WP_Error( 'absolute_path', "Blocked absolute path: {$zip_path}" );
		}

		if ( str_contains( $zip_path, '../' ) || str_contains( $zip_path, "..\\" ) ) {
			return new WP_Error( 'traversal', "Blocked path traversal: {$zip_path}" );
		}

		if ( str_contains( $zip_path, "\0" ) ) {
			return new WP_Error( 'null_byte', "Null byte in path: {$zip_path}" );
		}

		// Skip directory entries.
		if ( str_ends_with( $zip_path, '/' ) ) {
			return true;
		}

		$ext = strtolower( pathinfo( $zip_path, PATHINFO_EXTENSION ) );

		// Extensionless files are allowed.
		if ( empty( $ext ) ) {
			return true;
		}

		if ( in_array( $ext, self::BLOCKED_EXTENSIONS, true ) ) {
			return new WP_Error( 'blocked_ext', "Blocked file type (.{$ext}): {$zip_path}" );
		}

		if ( ! in_array( $ext, self::ALLOWED_EXTENSIONS, true ) ) {
			return new WP_Error( 'unknown_ext', "File type not allowed (.{$ext}): {$zip_path}" );
		}

		// Final real-path check — confirm destination stays inside target dir.
		$real_target = realpath( $target_dir );
		if ( $real_target ) {
			$dest = self::normalize_path( $real_target . DIRECTORY_SEPARATOR . $zip_path );
			if ( ! str_starts_with( $dest, $real_target . DIRECTORY_SEPARATOR ) ) {
				return new WP_Error( 'outside_target', "Path escapes target directory: {$zip_path}" );
			}
		}

		return true;
	}

	/**
	 * Normalize a path without requiring it to exist on disk.
	 *
	 * @param string $path The path to normalize.
	 * @return string
	 */
	public static function normalize_path( $path ) {
		$sep    = DIRECTORY_SEPARATOR;
		$parts  = explode( $sep, str_replace( '/', $sep, $path ) );
		$result = array();

		foreach ( $parts as $part ) {
			if ( '' === $part || '.' === $part ) {
				continue;
			}
			if ( '..' === $part ) {
				array_pop( $result );
				continue;
			}
			$result[] = $part;
		}

		return ( str_starts_with( $path, '/' ) ? '/' : '' ) . implode( $sep, $result );
	}

	/**
	 * Regenerate and save the API key.
	 *
	 * @return string The new API key.
	 */
	public static function regenerate_api_key() {
		$key = wp_generate_password( 48, false );
		update_option( 'wpusher_api_key', $key );
		return $key;
	}

	/**
	 * Whether a file to delete is really inside the folder it's deleted from
	 * (1.6.3). Deletions were only checked with file_exists(), so
	 * "../../../wp-config.php" would have deleted wp-config.php.
	 *
	 * @param string $rel        Path relative to the target, as sent.
	 * @param string $target_dir The folder deletions apply to.
	 * @return true|WP_Error
	 */
	public static function validate_deletion( $rel, $target_dir ) {
		$rel = str_replace( '\\', '/', (string) $rel );
		if ( '' === $rel || str_contains( $rel, "\0" ) ) {
			return new WP_Error( 'traversal', "Blocked deletion: {$rel}" );
		}
		if ( str_starts_with( $rel, '/' ) || preg_match( '#^[A-Za-z]:#', $rel ) || preg_match( '#(^|/)\.\.(/|$)#', $rel ) ) {
			return new WP_Error( 'traversal', "Blocked deletion outside the folder: {$rel}" );
		}
		$real_target = realpath( $target_dir );
		if ( ! $real_target ) {
			return new WP_Error( 'traversal', 'The folder to delete from does not exist.' );
		}
		$real_target = untrailingslashit( str_replace( '\\', '/', $real_target ) );
		$full        = $real_target . '/' . $rel;
		$dir         = realpath( dirname( $full ) );
		if ( ! $dir ) {
			return new WP_Error( 'not_found', "Not there to delete: {$rel}" );
		}
		$dir = untrailingslashit( str_replace( '\\', '/', $dir ) );
		if ( $dir !== $real_target && ! str_starts_with( $dir . '/', $real_target . '/' ) ) {
			return new WP_Error( 'traversal', "Blocked deletion outside the folder: {$rel}" );
		}
		return true;
	}

	/**
	 * Whether a folder may be restored over (emptied, then refilled from a
	 * backup): exactly one theme or one plugin folder, never uploads,
	 * wp-content, the plugins or themes folder itself, or the site (1.6.3).
	 * The folder itself may be a link (a theme linked into a Git checkout);
	 * where it sits is what's checked.
	 *
	 * @param string $dir Folder.
	 * @return true|WP_Error
	 */
	public static function validate_restore_target( $dir ) {
		$dir  = untrailingslashit( str_replace( '\\', '/', (string) $dir ) );
		$name = basename( $dir );
		$in   = realpath( dirname( $dir ) );
		$in   = $in ? untrailingslashit( str_replace( '\\', '/', $in ) ) : '';
		$ok   = array();
		foreach ( array( get_theme_root(), WP_PLUGIN_DIR ) as $root ) {
			$r = realpath( $root );
			if ( $r ) {
				$ok[] = untrailingslashit( str_replace( '\\', '/', $r ) );
			}
		}
		if ( '' === $name || '.' === $name || '..' === $name || ! $in || ! in_array( $in, $ok, true ) || ! is_dir( $dir ) ) {
			return new WP_Error( 'unsafe_target', 'Refused: a backup can only be restored over a single theme or plugin folder.', array( 'status' => 400 ) );
		}
		return true;
	}
}
