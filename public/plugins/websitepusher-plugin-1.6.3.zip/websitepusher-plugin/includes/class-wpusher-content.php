<?php
/**
 * WPusher_Content
 *
 * Content push: the pages, posts, Elementor templates, blocks, menus and new
 * images someone changed on their local copy, and nothing else (Derek,
 * 2026-10-10). A live site keeps collecting form entries, orders, users and
 * the client's own edits while a teammate works, so the database is never
 * pushed whole: only the items the app lists, each one checked against what
 * was live when the site was pulled.
 *
 *   POST /content/state     { ids: [..] }  → { id: post_modified_gmt | null }
 *   POST /content/push      multipart: payload (JSON), zip_file (new images)
 *   POST /content/rollback  { backup_id }   → puts back what a push changed
 *
 * The payload:
 *   from      local origins to swap for this site's address ("http://x.local")
 *   items     [{ local_id, live_id|null, expect_modified, post{...}, meta{key:[raw]},
 *               terms[{taxonomy,slug,name}] }]   attachments first
 *   deletes   [live_id]   nav_menu_item only: an item taken out of a menu
 *   id_map    { local_id: live_id }  for posts pushed earlier under a new ID
 *   force     overwrite items that changed on live since the pull
 *
 * Meta values arrive exactly as the local database holds them (serialized
 * strings included) and are written back the same way, never re-serialized.
 * Content is written with kses switched off: the request has no logged-in
 * user, and WordPress would otherwise strip every script and iframe an
 * administrator put on the page.
 *
 * Every push writes a backup first (uploads/websitepusher-backups/content-*.json)
 * and a history record; /content/rollback puts every changed item back,
 * deletes what the push created and restores what it deleted.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPusher_Content {

	/** Meta that is cache or bookkeeping, never pushed: Elementor rebuilds its CSS. */
	const SKIP_META = '/^(_edit_lock|_edit_last|_elementor_css|_elementor_element_cache|_elementor_page_assets|_oembed_|_transient)/';

	/** What a pushed image file may be. */
	const MEDIA_EXT = array( 'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'svg', 'ico', 'pdf', 'mp4', 'mov', 'webm', 'mp3', 'm4a', 'wav' );

	/** Post fields the app sends and this writes. */
	const POST_FIELDS = array(
		'post_title', 'post_content', 'post_excerpt', 'post_status', 'post_name', 'post_type', 'post_parent',
		'menu_order', 'post_date', 'post_date_gmt', 'comment_status', 'ping_status', 'post_password',
		'post_mime_type', 'post_content_filtered',
	);

	public static function register_routes( $ns, $auth ) {
		register_rest_route( $ns, '/content/state',    array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'state' ),    'permission_callback' => $auth ) );
		register_rest_route( $ns, '/content/push',     array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'push' ),     'permission_callback' => $auth ) );
		register_rest_route( $ns, '/content/rollback', array( 'methods' => 'POST', 'callback' => array( __CLASS__, 'rollback' ), 'permission_callback' => $auth ) );
	}

	// ── State ───────────────────────────────────────────────────────────────

	/**
	 * When each post last changed here, so the app can say which ones the
	 * client (or anyone) edited on live since the pull. Null for a post gone.
	 */
	public static function state( WP_REST_Request $request ) {
		global $wpdb;
		$ids = array_values( array_filter( array_map( 'intval', (array) $request->get_param( 'ids' ) ) ) );
		$out = array();
		foreach ( array_chunk( $ids, 500 ) as $chunk ) {
			$rows = $wpdb->get_results( 'SELECT ID, post_modified_gmt FROM ' . $wpdb->posts . ' WHERE ID IN (' . implode( ',', $chunk ) . ')', ARRAY_A ); // phpcs:ignore
			foreach ( $chunk as $id ) {
				$out[ $id ] = null;
			}
			foreach ( $rows as $r ) {
				$out[ (int) $r['ID'] ] = $r['post_modified_gmt'];
			}
		}
		return new WP_REST_Response( $out, 200 );
	}

	// ── Push ────────────────────────────────────────────────────────────────

	public static function push( WP_REST_Request $request ) {
		global $wpdb;
		@set_time_limit( 300 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		$locked = WPusher_Team::lock_refusal( $request, 'push' );
		if ( $locked ) {
			return $locked;
		}

		$payload = json_decode( (string) $request->get_param( 'payload' ), true );
		if ( ! is_array( $payload ) || empty( $payload['items'] ) && empty( $payload['deletes'] ) ) {
			return new WP_REST_Response( array( 'message' => 'Nothing to push.' ), 400 );
		}

		// For the owner's review (1.6.0): stored, not applied. See WPusher_Release.
		if ( WPusher_Release::wants_hold( $request ) ) {
			return WPusher_Release::hold( $request, 'content' );
		}
		$items   = (array) ( $payload['items'] ?? array() );
		$deletes = array_values( array_filter( array_map( 'intval', (array) ( $payload['deletes'] ?? array() ) ) ) );
		$id_map  = array();
		foreach ( (array) ( $payload['id_map'] ?? array() ) as $l => $v ) {
			$id_map[ (int) $l ] = (int) $v;
		}
		$force = ! empty( $payload['force'] );

		// 1. Anything that changed here since the pull is held back, unless the
		//    person chose to overwrite it. Nothing is written if so.
		if ( ! $force ) {
			$conflicts = array();
			foreach ( $items as $it ) {
				$live = (int) ( $it['live_id'] ?? 0 );
				if ( ! $live ) {
					continue;
				}
				$now = $wpdb->get_var( $wpdb->prepare( "SELECT post_modified_gmt FROM {$wpdb->posts} WHERE ID = %d", $live ) );
				if ( null === $now || ( ! empty( $it['expect_modified'] ) && $now !== $it['expect_modified'] ) ) {
					$conflicts[] = array(
						'local_id' => (int) $it['local_id'],
						'live_id'  => $live,
						'title'    => $it['post']['post_title'] ?? '',
						'modified' => $now,
						'gone'     => null === $now,
					);
				}
			}
			if ( $conflicts ) {
				return new WP_REST_Response(
					array(
						'error'     => 'conflict',
						'message'   => 'Some of this changed on the live website since you pulled it.',
						'conflicts' => $conflicts,
					),
					409
				);
			}
		}

		// 2. Back up everything this push will change or delete.
		$backup = array( 'at' => gmdate( 'c' ), 'updated' => array(), 'created' => array(), 'deleted' => array(), 'files' => array() );
		foreach ( $items as $it ) {
			$live = (int) ( $it['live_id'] ?? 0 );
			if ( $live && get_post( $live ) ) {
				$backup['updated'][] = self::snapshot( $live );
			}
		}
		foreach ( $deletes as $d ) {
			if ( get_post( $d ) ) {
				$backup['deleted'][] = self::snapshot( $d );
			}
		}

		// 3. New image files, into uploads at the same paths they have locally.
		$zip = self::uploaded_zip( $request );
		if ( is_wp_error( $zip ) ) {
			return new WP_REST_Response( array( 'message' => $zip->get_error_message() ), 400 );
		}
		if ( $zip ) {
			$written = self::unzip_media( $zip );
			unlink( $zip );
			if ( is_wp_error( $written ) ) {
				return new WP_REST_Response( array( 'message' => $written->get_error_message() ), 400 );
			}
			$backup['files'] = $written;
		}

		$backup_id = 'content-' . gmdate( 'Ymd-His' ) . '-' . wp_generate_password( 6, false );
		WPusher_Backup::ensure_backup_directory();
		file_put_contents( self::backup_file( $backup_id ), wp_json_encode( $backup ) ); // phpcs:ignore

		// From here, content is written as given.
		kses_remove_filters();
		$pairs = self::pairs_to_here( (array) ( $payload['from'] ?? array() ) );

		// 4. New posts first, so everything else can point at their real IDs.
		foreach ( $items as $it ) {
			if ( ! empty( $it['live_id'] ) ) {
				continue;
			}
			$p     = (array) $it['post'];
			$newid = wp_insert_post(
				wp_slash(
					array(
						'post_title'  => (string) ( $p['post_title'] ?? '' ),
						'post_type'   => (string) ( $p['post_type'] ?? 'page' ),
						'post_status' => 'draft',
					)
				),
				true
			);
			if ( is_wp_error( $newid ) ) {
				return self::fail( $backup_id, $backup, 'Couldn\'t create "' . ( $p['post_title'] ?? '' ) . '": ' . $newid->get_error_message() );
			}
			$id_map[ (int) $it['local_id'] ] = (int) $newid;
			$backup['created'][]             = (int) $newid;
		}
		file_put_contents( self::backup_file( $backup_id ), wp_json_encode( $backup ) ); // phpcs:ignore

		// 5. Write every item: fields, meta, terms, with addresses and IDs fixed.
		$titles = array();
		foreach ( $items as $it ) {
			$id = (int) ( $it['live_id'] ?: $id_map[ (int) $it['local_id'] ] );
			$p  = (array) $it['post'];

			$fields = array();
			foreach ( self::POST_FIELDS as $f ) {
				if ( array_key_exists( $f, $p ) ) {
					$fields[ $f ] = self::fix( (string) $p[ $f ], $pairs, $id_map );
				}
			}
			if ( isset( $p['post_parent'] ) ) {
				$parent                = (int) $p['post_parent'];
				$fields['post_parent'] = $id_map[ $parent ] ?? $parent;
			}
			if ( 'attachment' === ( $p['post_type'] ?? '' ) && ! empty( $p['guid'] ) ) {
				$fields['guid'] = self::fix( (string) $p['guid'], $pairs, $id_map );
			}
			$fields['post_modified']     = current_time( 'mysql' );
			$fields['post_modified_gmt'] = current_time( 'mysql', true );
			$wpdb->update( $wpdb->posts, $fields, array( 'ID' => $id ) );

			// Meta: replace what's there (apart from caches) with what was sent.
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE post_id = %d", $id ) );
			foreach ( (array) ( $it['meta'] ?? array() ) as $key => $values ) {
				if ( preg_match( self::SKIP_META, (string) $key ) ) {
					continue;
				}
				foreach ( (array) $values as $v ) {
					$v = self::fix( (string) $v, $pairs, $id_map );
					if ( in_array( $key, array( '_thumbnail_id', '_menu_item_object_id', '_menu_item_menu_item_parent' ), true ) && isset( $id_map[ (int) $v ] ) ) {
						$v = (string) $id_map[ (int) $v ];
					}
					$wpdb->insert( $wpdb->postmeta, array( 'post_id' => $id, 'meta_key' => $key, 'meta_value' => $v ) ); // phpcs:ignore
				}
			}

			self::set_terms( $id, (array) ( $it['terms'] ?? array() ) );
			clean_post_cache( $id );
			$titles[] = self::label( $p, (string) ( $it['label'] ?? '' ) );
		}

		// 6. Menu items taken out of a menu locally.
		foreach ( $deletes as $d ) {
			if ( 'nav_menu_item' === get_post_type( $d ) ) {
				wp_delete_post( $d, true );
				$titles[] = 'Removed menu item';
			}
		}
		file_put_contents( self::backup_file( $backup_id ), wp_json_encode( $backup ) ); // phpcs:ignore

		self::clear_caches();

		$modified = array();
		foreach ( $items as $it ) {
			$id                         = (int) ( $it['live_id'] ?: $id_map[ (int) $it['local_id'] ] );
			$modified[ $it['local_id'] ] = array(
				'live_id'  => $id,
				'modified' => $wpdb->get_var( $wpdb->prepare( "SELECT post_modified_gmt FROM {$wpdb->posts} WHERE ID = %d", $id ) ),
			);
		}

		$record = WPusher_History::add(
			array(
				'type'         => 'content',
				'target'       => 'content',
				'files'        => $titles,
				'note'         => sanitize_text_field( (string) ( $payload['note'] ?? '' ) ),
				'backup_path'  => $backup_id,
				'can_rollback' => false, // undone with /content/rollback, never the file undo
				'actor'        => WPusher_Team::actor( $request ),
				'via'          => sanitize_key( (string) ( $payload['via'] ?? 'app' ) ),
			)
		);

		return new WP_REST_Response(
			array(
				'ok'        => true,
				'items'     => $modified,
				'deleted'   => $deletes,
				'backup_id' => $backup_id,
				'record_id' => $record,
				'pushed'    => $titles,
			),
			200
		);
	}

	// ── Rollback ────────────────────────────────────────────────────────────

	public static function rollback( WP_REST_Request $request ) {
		global $wpdb;
		$locked = WPusher_Team::lock_refusal( $request, 'undo' );
		if ( $locked ) {
			return $locked;
		}
		$id   = preg_replace( '/[^A-Za-z0-9-]/', '', (string) $request->get_param( 'backup_id' ) );
		$file = self::backup_file( $id );
		if ( '' === $id || ! is_file( $file ) ) {
			return new WP_REST_Response( array( 'message' => 'That content backup isn\'t on this website.' ), 404 );
		}
		$b = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore

		kses_remove_filters();
		foreach ( (array) $b['created'] as $cid ) {
			wp_delete_post( (int) $cid, true );
		}
		foreach ( array_merge( (array) $b['updated'], (array) $b['deleted'] ) as $snap ) {
			self::restore( $snap );
		}
		self::clear_caches();
		rename( $file, $file . '.undone' );

		WPusher_History::add(
			array(
				'type'    => 'content',
				'target'  => 'content',
				'status'  => 'rolled_back',
				'files'   => array( 'Undid content push ' . $id ),
				'actor'   => WPusher_Team::actor( $request ),
				'message' => 'Content push undone.',
			)
		);
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	// ── Helpers ─────────────────────────────────────────────────────────────

	/** A post as it is now: row, every meta row, terms. */
	private static function snapshot( $id ) {
		global $wpdb;
		return array(
			'post'  => $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->posts} WHERE ID = %d", $id ), ARRAY_A ),
			'meta'  => $wpdb->get_results( $wpdb->prepare( "SELECT meta_key, meta_value FROM {$wpdb->postmeta} WHERE post_id = %d ORDER BY meta_id", $id ), ARRAY_A ),
			'terms' => self::terms_of( $id ),
		);
	}

	private static function restore( $snap ) {
		global $wpdb;
		$row = (array) $snap['post'];
		$id  = (int) $row['ID'];
		if ( $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE ID = %d", $id ) ) ) {
			$wpdb->update( $wpdb->posts, $row, array( 'ID' => $id ) );
		} else {
			$wpdb->insert( $wpdb->posts, $row );
		}
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE post_id = %d", $id ) );
		foreach ( (array) $snap['meta'] as $m ) {
			$wpdb->insert( $wpdb->postmeta, array( 'post_id' => $id, 'meta_key' => $m['meta_key'], 'meta_value' => $m['meta_value'] ) ); // phpcs:ignore
		}
		self::set_terms( $id, (array) $snap['terms'], true );
		clean_post_cache( $id );
	}

	private static function terms_of( $id ) {
		$out = array();
		foreach ( get_object_taxonomies( get_post_type( $id ) ) as $tax ) {
			$terms = wp_get_object_terms( $id, $tax );
			if ( is_wp_error( $terms ) ) {
				continue;
			}
			foreach ( $terms as $t ) {
				$out[] = array( 'taxonomy' => $tax, 'slug' => $t->slug, 'name' => $t->name );
			}
		}
		return $out;
	}

	/**
	 * Put a post in exactly these terms, by slug, creating any that don't
	 * exist here yet. With $all, taxonomies with no terms listed are cleared.
	 */
	private static function set_terms( $id, array $terms, $all = false ) {
		$by_tax = array();
		foreach ( $terms as $t ) {
			if ( empty( $t['taxonomy'] ) || ! taxonomy_exists( $t['taxonomy'] ) ) {
				continue;
			}
			$found = get_term_by( 'slug', $t['slug'], $t['taxonomy'] );
			if ( ! $found ) {
				$made = wp_insert_term( $t['name'] ?: $t['slug'], $t['taxonomy'], array( 'slug' => $t['slug'] ) );
				if ( is_wp_error( $made ) ) {
					continue;
				}
				$tid = (int) $made['term_id'];
			} else {
				$tid = (int) $found->term_id;
			}
			$by_tax[ $t['taxonomy'] ][] = $tid;
		}
		$type = get_post_type( $id );
		foreach ( get_object_taxonomies( $type ) as $tax ) {
			if ( isset( $by_tax[ $tax ] ) ) {
				wp_set_object_terms( $id, $by_tax[ $tax ], $tax );
			} elseif ( $all || in_array( $tax, array( 'category', 'post_tag', 'nav_menu' ), true ) ) {
				wp_set_object_terms( $id, array(), $tax );
			}
		}
	}

	/** Local addresses → this site's, in every form a URL takes in content. */
	private static function pairs_to_here( array $from ) {
		$home = untrailingslashit( get_option( 'home' ) );
		$host = (string) wp_parse_url( $home, PHP_URL_HOST );
		$f    = array();
		$t    = array();
		foreach ( $from as $origin ) {
			$origin = untrailingslashit( (string) $origin );
			$lh     = (string) wp_parse_url( $origin, PHP_URL_HOST );
			if ( '' === $lh || $lh === $host ) {
				continue;
			}
			foreach ( array( 'https', 'http' ) as $scheme ) {
				$f[] = $scheme . '://' . $lh;
				$t[] = preg_replace( '#/$#', '', preg_replace( '#^(https?://[^/]+).*#', '$1', $home ) );
			}
			$f[] = '//' . $lh;
			$t[] = '//' . $host;
		}
		return WPusher_SitePull::replace_pairs( $f, $t );
	}

	/**
	 * Addresses swapped, and IDs of posts that are new here pointed at their
	 * new IDs wherever content refers to them by number: image blocks and
	 * Elementor widgets ("id":123, "id":"123"), the wp-image-123 class.
	 */
	private static function fix( $value, array $pairs, array $id_map ) {
		if ( $pairs ) {
			$value = WPusher_SitePull::replace_value( $value, $pairs );
		}
		if ( $id_map && ( false !== strpos( $value, '"id"' ) || false !== strpos( $value, 'wp-image-' ) ) ) {
			$value = preg_replace_callback(
				'/("id"\s*:\s*"?)(\d+)("?)|(wp-image-)(\d+)/',
				function ( $m ) use ( $id_map ) {
					if ( ! empty( $m[4] ) ) {
						return $m[4] . ( $id_map[ (int) $m[5] ] ?? $m[5] );
					}
					return $m[1] . ( $id_map[ (int) $m[2] ] ?? $m[2] ) . $m[3];
				},
				$value
			);
		}
		return $value;
	}

	private static function label( array $p, $hint = '' ) {
		$kinds = array(
			'page'             => 'Page',
			'post'             => 'Post',
			'elementor_library' => 'Template',
			'wp_block'         => 'Block',
			'nav_menu_item'    => 'Menu item',
			'attachment'       => 'Image',
		);
		$k = $kinds[ $p['post_type'] ?? '' ] ?? ucfirst( (string) ( $p['post_type'] ?? 'Item' ) );
		// The app's name for it wins: a menu item usually has no title of its own.
		$name = '' !== $hint ? $hint : (string) ( $p['post_title'] ?? '' );
		return $k . ': ' . ( '' !== $name ? $name : '(no title)' );
	}

	private static function clear_caches() {
		wp_cache_flush();
		if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
			\Elementor\Plugin::$instance->files_manager->clear_cache();
		}
	}

	private static function backup_file( $id ) {
		return trailingslashit( WPusher_Backup::get_backup_dir() ) . $id . '.json';
	}

	/** Undo what a failed push already did, then say why it failed. */
	private static function fail( $backup_id, array $backup, $message ) {
		foreach ( $backup['created'] as $cid ) {
			wp_delete_post( (int) $cid, true );
		}
		@unlink( self::backup_file( $backup_id ) ); // phpcs:ignore
		return new WP_REST_Response( array( 'message' => $message ), 500 );
	}

	private static function uploaded_zip( WP_REST_Request $request ) {
		// A held release being applied: its stored upload stands in.
		if ( WPusher_Release::$replay_zip ) {
			return WPusher_Release::$replay_zip;
		}
		$files = $request->get_file_params();
		if ( empty( $files['zip_file'] ) ) {
			return null;
		}
		$f = $files['zip_file'];
		if ( ! empty( $f['error'] ) ) {
			return new WP_Error( 'upload', 'The images didn\'t upload (code ' . $f['error'] . ').' );
		}
		$tmp = get_temp_dir() . 'wpusher_content_' . uniqid() . '.zip';
		if ( ! move_uploaded_file( $f['tmp_name'], $tmp ) ) {
			return new WP_Error( 'upload', 'Couldn\'t read the uploaded images.' );
		}
		return $tmp;
	}

	/**
	 * Unzip images into uploads at their own relative paths. Only media types;
	 * a path that escapes uploads, or anything else, refuses the whole batch.
	 */
	private static function unzip_media( $zip_path ) {
		$up   = wp_get_upload_dir();
		$base = untrailingslashit( $up['basedir'] );
		$zip  = new ZipArchive();
		if ( true !== $zip->open( $zip_path ) ) {
			return new WP_Error( 'zip', 'The images couldn\'t be opened.' );
		}
		$written = array();
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$name = str_replace( '\\', '/', $zip->getNameIndex( $i ) );
			if ( str_ends_with( $name, '/' ) ) {
				continue;
			}
			$ext = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
			if ( str_starts_with( $name, '/' ) || str_contains( $name, '..' ) || ! in_array( $ext, self::MEDIA_EXT, true ) ) {
				$zip->close();
				return new WP_Error( 'zip', 'Refused a file that isn\'t an image in uploads: ' . $name );
			}
		}
		for ( $i = 0; $i < $zip->numFiles; $i++ ) {
			$name = str_replace( '\\', '/', $zip->getNameIndex( $i ) );
			if ( str_ends_with( $name, '/' ) ) {
				continue;
			}
			$dest = $base . '/' . $name;
			wp_mkdir_p( dirname( $dest ) );
			if ( ! file_exists( $dest ) ) {
				file_put_contents( $dest, $zip->getFromIndex( $i ) ); // phpcs:ignore
				$written[] = $name;
			}
		}
		$zip->close();
		return $written;
	}
}
