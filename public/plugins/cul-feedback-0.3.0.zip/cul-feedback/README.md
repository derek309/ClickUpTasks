# ClickUpLocal Feedback

A question mark bubble on a client's own WordPress site. They click whatever
looks wrong, say what is wrong in a sentence, and it arrives in ClickUpTasks as
a task in that client's list, with the page URL and the exact element attached.

It exists because "the phone number is wrong on one of the pages" costs a round
of emails to locate. Reported where they are standing, it costs one sentence
and arrives already located.

## Install

1. Zip the plugin folder (`./build.sh` writes a versioned zip beside it).
2. WordPress admin, Plugins, Add New, Upload Plugin, and activate.
3. Settings, CUL Feedback.

## Set up

- **ClickUpTasks URL** defaults to the production app.
- **API token** comes from ClickUpTasks, Settings, API tokens. It starts with
  `cut_`. It is stored in this site's options and only ever read on the server,
  never printed into a page.
- **Client** and **List** are real dropdowns, filled from the API through this
  site's own admin so the token stays server side. Every report from this site
  lands in that one list.
- **The link to send** turns review mode on for thirty days on whoever opens
  it. Send it once, at the start of a build.

Logged in editors always see the bubble. Everyone else needs the link, unless
"Show it to every visitor" is deliberately turned on.

## The button

"Review this site", bottom left by default (most client sites keep a chat
widget bottom right). Anyone can drag it; let go and it tucks against the
nearest side, and the browser remembers where. A press that moves more than a
few pixels is a drag and never opens anything. Sites set up before 0.3.0 had
"right" saved only because it was the old default, so they move left until
the settings page is saved again.

With a **Client link** set (Settings, CUL Feedback, pasted from the Client
link button in ClickUpTasks) the button opens a small menu: Report something,
or See all your changes, and the button shows how many tasks are still open
in the site's list. That count comes from the existing
`GET /api/extension/tasks` (open tasks, up to 30, so 30 shows as "30+") and is
cached for two minutes per site. The confirmation after sending links there
too. Without a client link the button goes straight to picking.

## What arrives

Title is their sentence, prefixed with the category if they picked one
(Copy, Image, Layout, Link, Other). The description carries the whole message,
who sent it, the page title, the URL, a CSS path to the element and its text
(or "the whole page"), the screen size and the browser.

**Words edited in place.** Clicking text (up to 400 characters) shows "It says
now" crossed out and "It should say" starting as the same words. The task then
leads with `Now:` and `Should say:` lines, ready to copy, and is titled
`Copy: Change "..."` when they wrote no note.

**Show me.** Every report on an element carries a link back to the page with
`#cul-fb-show=<path, text, ask>`. Opening it scrolls to the element, outlines it
and shows what was asked. It works for anyone, reviewer or not, and falls back
to finding the same words when the path has gone stale. It is also sent as the
task's link. The server only accepts one pointing at this site.

**Who sent it.** Logged in staff are named by WordPress. Anyone on the review
link is asked for their name at the top of their first report. After that it shows
as "From Brian · change" above Send.

**The whole page.** While picking, "Or report the whole page" files a report
with nothing clicked, for things that are missing rather than wrong.

**A new picture.** "Add a new picture" attaches a JPG, PNG, GIF or WebP. It is
uploaded to ClickUpTasks (`/api/extension/upload`) and arrives on the task as
an image attachment named "Replacement picture: <file>". The ClickUpTasks limit
is 5MB, so bigger photos are shrunk in the browser first (JPEG, stepping down
from 3000px). GIFs over 5MB are refused, because redrawing one keeps only its
first frame. The server checks the bytes really are a picture. If the upload
fails the report still files and says the picture did not make it.

## Page caches

The script loads for every visitor once the plugin is set up, and stays silent
unless PHP said this visitor may report, or the readable `cul_feedback_on`
cookie is there. The review link sets that cookie next to the httponly one, so
a cached page still shows the bubble to a reviewer. The stylesheet is only
fetched when the bubble shows. Pages built for a reviewer set `DONOTCACHEPAGE`
so they are not stored for everyone else.

## Limits

Twenty reports an hour per address, so a frustrated pass through a broken page
cannot open forty tasks.

## Testing

`tests/harness.php` and `tests/updater-test.php` run with Local's PHP.
`tests/browser/index.html` (and `cached.html`, the page cache case) run the
bubble against a fake send; serve the plugin folder and open them.

## Deliberately not here

Automatic screenshots. In browser capture needs a heavy library and renders the
page wrong often enough to mislead. The URL plus the element path plus their
sentence gets you to the spot faster. A picture the client chooses is a
different thing and is supported.
