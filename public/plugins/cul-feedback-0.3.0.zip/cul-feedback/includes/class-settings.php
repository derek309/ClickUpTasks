<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Reading and writing the one option row, plus the calls out to ClickUpTasks.
 *  Every request to ClickUpTasks goes through here, so the API token is only
 *  ever read on the server: a token in page JavaScript is a token anyone who
 *  views source can use to create tasks on any of your clients. */
class CUL_Feedback_Settings {

	public static function defaults() {
		return [
			'api_base'     => 'https://clickuptasks.vercel.app',
			'api_token'    => '',
			'client_id'    => '',
			'client_name'  => '',
			'project_id'   => '',
			'project_name' => '',
			// The link you send the client. Generated on first save so it is
			// never a value anyone had to think of.
			'review_token' => '',
			// Off by default. A public bubble invites feedback from people who
			// are not your client.
			'public_mode'  => 0,
			// Left since 0.3.0: most client sites keep a chat widget in the
			// bottom right corner.
			'bubble_side'  => 'left',
			// The client's ClickUpTasks page, shown as "See all your changes".
			'client_link'  => '',
			'side_v2'      => 1,
		];
	}

	public static function get() {
		$saved = get_option( CUL_FEEDBACK_OPTION, [] );
		$saved = is_array( $saved ) ? $saved : [];
		// Sites set up before 0.3.0 saved "right" because it was the only
		// default there was, not a choice. They move left with everyone else
		// until someone saves the settings page again.
		if ( ! empty( $saved ) && empty( $saved['side_v2'] ) ) $saved['bubble_side'] = 'left';
		return wp_parse_args( $saved, self::defaults() );
	}

	public static function save( array $values ) {
		update_option( CUL_FEEDBACK_OPTION, wp_parse_args( $values, self::get() ) );
	}

	/** True once it can actually file a task. The bubble stays hidden until
	 *  then rather than collecting reports that go nowhere. */
	public static function configured() {
		$s = self::get();
		return $s['api_token'] !== '' && $s['client_id'] !== '';
	}

	public static function review_token() {
		$s = self::get();
		if ( $s['review_token'] === '' ) {
			$s['review_token'] = wp_generate_password( 24, false, false );
			self::save( $s );
		}
		return $s['review_token'];
	}

	/** GET against the ClickUpTasks extension API. Returns [ok, data|error]. */
	public static function api_get( $path ) {
		return self::api_call( 'GET', $path, null );
	}

	public static function api_post( $path, array $body ) {
		return self::api_call( 'POST', $path, $body );
	}

	/** Multipart POST, for the one thing JSON cannot carry: a file.
	 *  wp_remote_request has no multipart helper, so the body is built by
	 *  hand. */
	public static function api_upload( $path, array $fields, $file_path, $file_name, $mime ) {
		$bytes = @file_get_contents( $file_path );
		if ( $bytes === false ) return [ false, 'could not read the file' ];

		$boundary = 'culfb' . wp_generate_password( 24, false, false );
		$body     = '';
		foreach ( $fields as $k => $v ) {
			$body .= "--{$boundary}\r\nContent-Disposition: form-data; name=\"{$k}\"\r\n\r\n{$v}\r\n";
		}
		$safe  = str_replace( [ '"', "\r", "\n" ], '', $file_name );
		$body .= "--{$boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{$safe}\"\r\nContent-Type: {$mime}\r\n\r\n{$bytes}\r\n--{$boundary}--\r\n";

		return self::api_call( 'POST', $path, $body, 'multipart/form-data; boundary=' . $boundary, 30 );
	}

	private static function api_call( $method, $path, $body, $type = 'application/json', $timeout = 15 ) {
		$s = self::get();
		if ( $s['api_token'] === '' ) return [ false, 'No API token saved yet.' ];

		$args = [
			'method'  => $method,
			'timeout' => $timeout,
			'headers' => [
				'Authorization' => 'Bearer ' . $s['api_token'],
				'Content-Type'  => $type,
			],
		];
		if ( $body !== null ) $args['body'] = is_string( $body ) ? $body : wp_json_encode( $body );

		$res = wp_remote_request( rtrim( $s['api_base'], '/' ) . $path, $args );
		if ( is_wp_error( $res ) ) return [ false, $res->get_error_message() ];

		$code = wp_remote_retrieve_response_code( $res );
		$json = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( $code < 200 || $code >= 300 ) {
			// The API's own message when it has one: "Unauthorized" tells you
			// the token is wrong, which a bare 401 does not.
			$msg = is_array( $json ) && ! empty( $json['error'] ) ? $json['error'] : 'HTTP ' . $code;
			return [ false, $msg ];
		}
		return [ true, $json ];
	}
}
