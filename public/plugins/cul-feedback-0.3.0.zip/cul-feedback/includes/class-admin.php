<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Settings > ClickUpLocal Feedback. Paste a token, pick the client and the
 *  list from real dropdowns, copy the review link. */
class CUL_Feedback_Admin {

	public static function menu() {
		add_options_page( 'ClickUpLocal Feedback', 'CUL Feedback', 'manage_options', 'cul-feedback', [ __CLASS__, 'page' ] );
	}

	public static function register() {
		register_setting( 'cul_feedback', CUL_FEEDBACK_OPTION, [ __CLASS__, 'sanitize' ] );
	}

	public static function sanitize( $input ) {
		$old = CUL_Feedback_Settings::get();
		$in  = is_array( $input ) ? $input : [];
		return [
			'api_base'     => esc_url_raw( trim( $in['api_base'] ?? $old['api_base'] ) ),
			'api_token'    => trim( $in['api_token'] ?? $old['api_token'] ),
			'client_id'    => sanitize_text_field( $in['client_id'] ?? '' ),
			'client_name'  => sanitize_text_field( $in['client_name'] ?? '' ),
			'project_id'   => sanitize_text_field( $in['project_id'] ?? '' ),
			'project_name' => sanitize_text_field( $in['project_name'] ?? '' ),
			'review_token' => $old['review_token'],
			'public_mode'  => empty( $in['public_mode'] ) ? 0 : 1,
			'bubble_side'  => ( ( $in['bubble_side'] ?? '' ) === 'right' ) ? 'right' : 'left',
			'client_link'  => self::https_or_empty( $in['client_link'] ?? '' ),
			'side_v2'      => 1,
		];
	}

	private static function https_or_empty( $url ) {
		$url = esc_url_raw( trim( (string) $url ) );
		return strpos( $url, 'https://' ) === 0 ? $url : '';
	}

	/** The dropdowns' data. Proxied rather than fetched from the browser so
	 *  the token stays on the server even inside wp-admin. */
	public static function ajax_lookup() {
		check_ajax_referer( 'cul_feedback_lookup' );
		if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Not allowed', 403 );

		$what      = sanitize_text_field( wp_unslash( $_POST['what'] ?? '' ) );
		$client_id = sanitize_text_field( wp_unslash( $_POST['client_id'] ?? '' ) );

		if ( $what === 'clients' ) {
			list( $ok, $data ) = CUL_Feedback_Settings::api_get( '/api/extension/clients' );
		} elseif ( $what === 'projects' && $client_id !== '' ) {
			list( $ok, $data ) = CUL_Feedback_Settings::api_get( '/api/extension/projects?client_id=' . rawurlencode( $client_id ) );
		} else {
			wp_send_json_error( 'Nothing to look up', 400 );
		}

		if ( ! $ok ) wp_send_json_error( $data, 200 );
		wp_send_json_success( $data );
	}

	public static function page() {
		$s    = CUL_Feedback_Settings::get();
		$link = add_query_arg( 'review', CUL_Feedback_Settings::review_token(), home_url( '/' ) );
		?>
		<div class="wrap">
			<h1>ClickUpLocal Feedback</h1>
			<p>Puts a question mark bubble on this site. The client clicks whatever looks wrong, says what is wrong, and it arrives as a task in ClickUpTasks with the page and the element attached.</p>

			<form method="post" action="options.php">
				<?php settings_fields( 'cul_feedback' ); ?>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="cul_api_base">ClickUpTasks URL</label></th>
						<td><input id="cul_api_base" name="<?php echo esc_attr( CUL_FEEDBACK_OPTION ); ?>[api_base]" type="url" class="regular-text" value="<?php echo esc_attr( $s['api_base'] ); ?>"></td>
					</tr>
					<tr>
						<th scope="row"><label for="cul_api_token">API token</label></th>
						<td>
							<input id="cul_api_token" name="<?php echo esc_attr( CUL_FEEDBACK_OPTION ); ?>[api_token]" type="password" class="regular-text" value="<?php echo esc_attr( $s['api_token'] ); ?>" autocomplete="off">
							<p class="description">ClickUpTasks &rarr; Settings &rarr; API tokens. Starts with <code>cut_</code>.</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="cul_client">Client</label></th>
						<td>
							<select id="cul_client" style="min-width:280px"><option value="">Save a token first, then pick</option></select>
							<input type="hidden" id="cul_client_id" name="<?php echo esc_attr( CUL_FEEDBACK_OPTION ); ?>[client_id]" value="<?php echo esc_attr( $s['client_id'] ); ?>">
							<input type="hidden" id="cul_client_name" name="<?php echo esc_attr( CUL_FEEDBACK_OPTION ); ?>[client_name]" value="<?php echo esc_attr( $s['client_name'] ); ?>">
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="cul_project">List</label></th>
						<td>
							<select id="cul_project" style="min-width:280px"><option value="">Pick a client first</option></select>
							<input type="hidden" id="cul_project_id" name="<?php echo esc_attr( CUL_FEEDBACK_OPTION ); ?>[project_id]" value="<?php echo esc_attr( $s['project_id'] ); ?>">
							<input type="hidden" id="cul_project_name" name="<?php echo esc_attr( CUL_FEEDBACK_OPTION ); ?>[project_name]" value="<?php echo esc_attr( $s['project_name'] ); ?>">
							<p class="description">Every report from this site lands here.</p>
						</td>
					</tr>
					<tr>
						<th scope="row"><label for="cul_client_link">Client link</label></th>
						<td>
							<input id="cul_client_link" name="<?php echo esc_attr( CUL_FEEDBACK_OPTION ); ?>[client_link]" type="url" class="large-text" value="<?php echo esc_attr( $s['client_link'] ); ?>" placeholder="https://clickuptasks.vercel.app/waiting/...">
							<p class="description">In ClickUpTasks, open the client and press <strong>Client link</strong>, then paste it here. The client sees it as "See all your changes". Leave it empty to hide that.</p>
						</td>
					</tr>
					<tr>
						<th scope="row">Button starts</th>
						<td>
							<label><input type="radio" name="<?php echo esc_attr( CUL_FEEDBACK_OPTION ); ?>[bubble_side]" value="left" <?php checked( $s['bubble_side'], 'left' ); ?>> Bottom left</label>
							&nbsp;&nbsp;
							<label><input type="radio" name="<?php echo esc_attr( CUL_FEEDBACK_OPTION ); ?>[bubble_side]" value="right" <?php checked( $s['bubble_side'], 'right' ); ?>> Bottom right</label>
							<p class="description">Anyone can drag it somewhere else, and their browser remembers where.</p>
						</td>
					</tr>
					<tr>
						<th scope="row">Who sees it</th>
						<td>
							<label><input type="checkbox" name="<?php echo esc_attr( CUL_FEEDBACK_OPTION ); ?>[public_mode]" value="1" <?php checked( $s['public_mode'], 1 ); ?>> Show it to every visitor</label>
							<p class="description">Leave this off. With it off the bubble shows for logged in editors, and for anyone who opened the review link below.</p>
						</td>
					</tr>
				</table>
				<?php submit_button(); ?>
			</form>

			<h2>The link to send</h2>
			<p>Opening this once turns review mode on for thirty days on that person's browser.</p>
			<p><input type="text" class="large-text code" readonly onfocus="this.select()" value="<?php echo esc_attr( $link ); ?>"></p>

			<h2>What to send with it</h2>
			<p>The link on its own explains nothing. Something like this does.</p>
			<textarea class="large-text code" rows="7" readonly onfocus="this.select()">Hi <?php echo esc_textarea( $s['client_name'] !== '' ? $s['client_name'] : 'there' ); ?>,

While we work on the site, you can tell us about anything that looks wrong without writing an email.

Open this link once: <?php echo esc_textarea( $link ); ?>

A "Review this site" button appears in the corner of the site. Press it, click whatever is wrong on the page, and change the words right there or attach a new picture. We get the page and the exact spot with it, so you never have to explain where it was. If the button is in the way, drag it somewhere else.

Changes can take up to 72 business hours.</textarea>

			<h2>Check it works</h2>
			<p><button class="button" id="cul_test">Test the connection</button> <span id="cul_test_out"></span></p>
		</div>
		<script>
		window.CUL_FEEDBACK_ADMIN = {
			ajax: <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>,
			nonce: <?php echo wp_json_encode( wp_create_nonce( 'cul_feedback_lookup' ) ); ?>,
			client: <?php echo wp_json_encode( [ 'id' => $s['client_id'], 'name' => $s['client_name'] ] ); ?>,
			project: <?php echo wp_json_encode( [ 'id' => $s['project_id'], 'name' => $s['project_name'] ] ); ?>
		};
		</script>
		<?php
		wp_enqueue_script( 'cul-feedback-admin', CUL_FEEDBACK_URL . 'assets/admin.js', [], CUL_FEEDBACK_VERSION, true );
	}
}
