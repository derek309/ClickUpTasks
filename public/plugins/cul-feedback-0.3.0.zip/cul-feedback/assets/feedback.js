// The Review this site button, the crosshair, the little form, and Show me.
// No framework and no build step: this runs on client sites we do not
// control, so it ships as one file that touches nothing outside its own ids.
(function () {
  var CFG = window.CUL_FEEDBACK;
  if (!CFG) return;

  // PHP says yes when it built this page for a reviewer. The flag cookie says
  // yes when a cache handed over a page PHP built for someone else.
  function flagged() {
    return document.cookie.split(/;\s*/).some(function (c) { return c === CFG.flag + "=1"; });
  }
  var reviewer = !!CFG.show || flagged();

  // A Show me link from a task: #cul-fb-show=<what to find>. It works for
  // whoever opens it, reviewer or not, because the person opening it is
  // usually us, on a site we are not logged in to.
  var SHOW = "#cul-fb-show=";
  var showReq = null;
  if (location.hash.indexOf(SHOW) === 0) {
    try { showReq = JSON.parse(decodeURIComponent(location.hash.slice(SHOW.length))); } catch (e) { showReq = null; }
  }
  if (!reviewer && !showReq) return;

  // The stylesheet is fetched only now, so ordinary visitors never load it.
  if (CFG.css && !document.getElementById("cul-fb-css")) {
    var css = document.createElement("link");
    css.id = "cul-fb-css";
    css.rel = "stylesheet";
    css.href = CFG.css;
    document.head.appendChild(css);
  }

  var CATEGORIES = ["Copy", "Image", "Layout", "Link", "Other"];
  // The ClickUpTasks upload limit. Bigger photos are shrunk in the browser
  // first, because a phone photo is routinely 6MB and should not bounce.
  var MAX_BYTES = 5 * 1024 * 1024;
  // Longer than this and what they clicked is a section, not a sentence:
  // editing it in a box would be a wall of text, so they describe it instead.
  var EDITABLE_MAX = 400;
  var picking = false;
  var target = null;
  var wholePage = false;
  var category = "";
  var picture = null;

  // ---- the element you clicked, described well enough to find again -------
  function selectorFor(el) {
    var parts = [];
    var node = el;
    // Walks up until the path points at exactly one thing on the page, so
    // Show me lands on this element and not the first of its lookalikes.
    for (var depth = 0; node && node.nodeType === 1 && node !== document.body && depth < 10; depth++) {
      if (node.id && /^[A-Za-z][\w-]*$/.test(node.id)) { parts.unshift("#" + node.id); break; }
      var name = node.nodeName.toLowerCase();
      if (node.className && typeof node.className === "string") {
        var cls = node.className.trim().split(/\s+/).filter(function (c) { return c && c.indexOf("cul-fb") !== 0 && /^[A-Za-z][\w-]*$/.test(c); })[0];
        if (cls) name += "." + cls;
      }
      var parent = node.parentNode;
      if (parent && parent.children && parent.children.length > 1) {
        var same = Array.prototype.filter.call(parent.children, function (c) { return c.nodeName === node.nodeName; });
        if (same.length > 1) name += ":nth-of-type(" + (Array.prototype.indexOf.call(same, node) + 1) + ")";
      }
      parts.unshift(name);
      try { if (document.querySelectorAll(parts.join(" > ")).length === 1) break; } catch (e) { /* odd class names */ }
      node = parent;
    }
    return parts.join(" > ");
  }

  function textOf(el) {
    var t = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
    return t.length > 120 ? t.slice(0, 119) + "…" : t;
  }

  // The picture they meant: the image itself, or the only image inside
  // what they clicked when that has no words of its own (a linked logo, a
  // wrapper div a page builder put around a photo).
  function pictureIn(node) {
    if (!node) return null;
    if (node.nodeName === "IMG") return node;
    if (textOf(node) || !node.querySelectorAll) return null;
    var imgs = node.querySelectorAll("img");
    return imgs.length === 1 ? imgs[0] : null;
  }

  // What they clicked, in words they would use. "img" means nothing to a
  // client, so a picture is named by its description when it has one.
  function describe(node) {
    var img = pictureIn(node);
    if (img) return img.alt || "A picture";
    return textOf(node) || node.nodeName.toLowerCase();
  }

  // The words of what they clicked, whole, for editing in place.
  function fullText(node) {
    return (node.innerText || node.textContent || "").replace(/[ \t]+/g, " ").replace(/\n\s*\n+/g, "\n").trim();
  }

  function editableText(node) {
    if (!node || wholePage || pictureIn(node)) return "";
    if (/^(INPUT|TEXTAREA|SELECT|IFRAME|VIDEO|SVG|CANVAS)$/i.test(node.nodeName)) return "";
    var t = fullText(node);
    return t.length && t.length <= EDITABLE_MAX ? t : "";
  }

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text) n.textContent = text;
    return n;
  }

  function button(cls, text) {
    var b = el("button", cls, text);
    b.type = "button";
    return b;
  }

  function store(key, value) { try { localStorage.setItem(key, value); } catch (e) { /* private window */ } }
  function stored(key) { try { return localStorage.getItem(key) || ""; } catch (e) { return ""; } }

  // ---- chrome ------------------------------------------------------------
  var root = el("div");
  root.id = "cul-fb-root";
  function mount() { if (!root.parentNode) document.body.appendChild(root); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mount);
  else mount();

  // ---- Show me -----------------------------------------------------------
  // Finds the element again, scrolls to it and outlines it, with a card
  // saying what was asked. Page builders render late, so it keeps looking
  // for a few seconds before saying it cannot find the spot.
  function runShowMe(req) {
    var found = null;
    var tries = 0;
    var want = (req.t || "").replace(/…$/, "").slice(0, 60);

    function find() {
      var list = [];
      if (req.s) { try { list = Array.prototype.slice.call(document.querySelectorAll(req.s)); } catch (e) { list = []; } }
      if (list.length === 1 && (!want || fullText(list[0]).indexOf(want) > -1)) return list[0];
      var byText = list.filter(function (n) { return want && fullText(n).indexOf(want) > -1; });
      if (byText.length) return byText[0];
      if (want) {
        // The path went stale (the page was edited): fall back to the
        // smallest element that still carries the same words.
        var best = null;
        Array.prototype.forEach.call(document.body.querySelectorAll("body *:not(script):not(style)"), function (n) {
          if (n.closest("#cul-fb-root")) return;
          if (fullText(n).indexOf(want) > -1 && (!best || best.contains(n))) best = n;
        });
        if (best) return best;
      }
      return list[0] || null;
    }

    var halo = el("div", "cul-fb-show-halo");
    var card = el("div", "cul-fb-show-card");

    function follow() {
      if (!found) return;
      var r = found.getBoundingClientRect();
      halo.style.top = (r.top - 4) + "px";
      halo.style.left = (r.left - 4) + "px";
      halo.style.width = (r.width + 8) + "px";
      halo.style.height = (r.height + 8) + "px";
      var below = r.bottom + 12;
      var fitsBelow = below + card.offsetHeight < window.innerHeight - 12;
      card.style.top = (fitsBelow ? below : Math.max(12, r.top - card.offsetHeight - 12)) + "px";
      card.style.left = Math.max(12, Math.min(r.left, window.innerWidth - card.offsetWidth - 12)) + "px";
    }

    function close() {
      window.removeEventListener("scroll", follow, true);
      window.removeEventListener("resize", follow);
      halo.remove();
      card.remove();
      if (history.replaceState) history.replaceState(null, "", location.pathname + location.search);
    }

    function fill(foundIt) {
      card.innerHTML = "";
      var head = el("div", "cul-fb-head");
      head.appendChild(el("strong", "", foundIt ? "Reported here" : "Could not find that spot"));
      var x = button("cul-fb-x", "✕");
      x.setAttribute("aria-label", "Close");
      x.addEventListener("click", close);
      head.appendChild(x);
      card.appendChild(head);
      if (req.a) card.appendChild(el("div", "cul-fb-show-ask", req.a));
      if (!foundIt && req.t) card.appendChild(el("div", "cul-fb-show-was", "It was: " + req.t));
    }

    (function look() {
      mount();
      found = find();
      if (!found && ++tries < 12) { setTimeout(look, 400); return; }
      fill(!!found);
      root.appendChild(card);
      if (!found) { card.classList.add("cul-fb-show-lost"); return; }
      root.appendChild(halo);
      found.scrollIntoView({ block: "center" });
      follow();
      window.addEventListener("scroll", follow, true);
      window.addEventListener("resize", follow);
      // Fonts, images and page builders keep moving things for a moment
      // after load without any scroll to hear about, so it keeps re-aligning
      // for a few seconds.
      var settle = 0;
      var settling = setInterval(function () {
        if (!halo.parentNode || ++settle > 20) { clearInterval(settling); return; }
        follow();
      }, 250);
    })();
  }

  if (showReq) runShowMe(showReq);
  if (!reviewer) return;

  // ---- who is logged in, and how many changes are open -------------------
  // Asked of WordPress directly. The page cannot be trusted to know: a
  // cached copy was built for a logged out visitor, so it would ask staff
  // for their name and carry no working REST nonce. admin-ajax runs on
  // cookies alone; logged out it simply answers no.
  var whoKnown = Promise.resolve();
  if (CFG.ajax) {
    var ask = new FormData();
    ask.append("action", "cul_feedback_me");
    whoKnown = fetch(CFG.ajax, { method: "POST", credentials: "same-origin", body: ask })
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (j) {
        if (!j || !j.success || !j.data) return;
        CFG.me = j.data.name || "";
        CFG.nonce = j.data.nonce || CFG.nonce;
        if (CFG.me) CFG.askName = 0;
      })
      .catch(function () { /* logged out, or blocked: the name box stays */ });
  }

  var openCount = null;
  function refreshCount() {
    if (!CFG.portal || !CFG.status) return;
    whoKnown.then(function () {
      var headers = {};
      if (CFG.nonce) headers["X-WP-Nonce"] = CFG.nonce;
      return fetch(CFG.status, { credentials: "same-origin", headers: headers });
    }).then(function (r) { return r && r.ok ? r.json() : null; })
      .then(function (j) {
        if (!j || typeof j.open !== "number") return;
        openCount = j.open;
        badge.textContent = j.open > 29 ? "30+" : String(j.open);
        badge.style.display = j.open > 0 ? "" : "none";
      })
      .catch(function () { /* no count is fine */ });
  }

  // ---- the button --------------------------------------------------------
  // "Review this site" says what it is, where a bare ? did not. It starts on
  // the side set in wp-admin (left by default, away from chat widgets) and
  // can be dragged anywhere; let go and it tucks against the nearest side.
  var POS = "culFbPos";
  var bubble = button("");
  bubble.id = "cul-fb-bubble";
  var grip = el("span", "cul-fb-grip");
  for (var g = 0; g < 6; g++) grip.appendChild(el("i"));
  var pen = el("span", "cul-fb-pen", "✎");
  var label = el("span", "cul-fb-label-text", CFG.strings.open);
  var badge = el("span", "cul-fb-badge");
  badge.style.display = "none";
  bubble.appendChild(grip);
  bubble.appendChild(pen);
  bubble.appendChild(label);
  bubble.appendChild(badge);

  var side = CFG.side === "right" ? "right" : "left";
  var lift = 22;
  (function restore() {
    var saved = stored(POS).split(":");
    if (saved[0] === "left" || saved[0] === "right") side = saved[0];
    var y = parseInt(saved[1], 10);
    if (!isNaN(y)) lift = y;
  })();

  function applyPosition() {
    var max = Math.max(12, window.innerHeight - bubble.offsetHeight - 12);
    lift = Math.max(12, Math.min(lift, max));
    root.setAttribute("data-side", side);
    bubble.style.bottom = lift + "px";
    bubble.style.left = bubble.style.right = bubble.style.top = "";
    placeAll();
  }
  window.addEventListener("resize", applyPosition);

  // A press that moves more than a few pixels is a drag and never opens
  // anything; a press that stays put is a click.
  var drag = null;
  var justDragged = false;
  bubble.addEventListener("pointerdown", function (e) {
    if (e.button !== 0) return;
    var r = bubble.getBoundingClientRect();
    drag = { id: e.pointerId, x: e.clientX, y: e.clientY, dx: e.clientX - r.left, dy: e.clientY - r.top, moving: false };
  });
  window.addEventListener("pointermove", function (e) {
    if (!drag || e.pointerId !== drag.id) return;
    if (!drag.moving && Math.abs(e.clientX - drag.x) + Math.abs(e.clientY - drag.y) < 6) return;
    if (!drag.moving) {
      drag.moving = true;
      try { bubble.setPointerCapture(drag.id); } catch (err) { /* older browsers */ }
      bubble.classList.add("cul-fb-dragging");
      closeMenu();
    }
    e.preventDefault();
    bubble.style.bottom = "auto";
    bubble.style.right = "auto";
    bubble.style.left = Math.max(0, Math.min(e.clientX - drag.dx, window.innerWidth - bubble.offsetWidth)) + "px";
    bubble.style.top = Math.max(0, Math.min(e.clientY - drag.dy, window.innerHeight - bubble.offsetHeight)) + "px";
    placeAll();
  });
  function endDrag(e) {
    if (!drag || e.pointerId !== drag.id) return;
    var moved = drag.moving;
    drag = null;
    if (!moved) return;
    justDragged = true;
    setTimeout(function () { justDragged = false; }, 0);
    bubble.classList.remove("cul-fb-dragging");
    var r = bubble.getBoundingClientRect();
    side = r.left + r.width / 2 < window.innerWidth / 2 ? "left" : "right";
    lift = Math.round(window.innerHeight - r.bottom);
    applyPosition();
    store(POS, side + ":" + lift);
  }
  window.addEventListener("pointerup", endDrag);
  window.addEventListener("pointercancel", endDrag);

  // Everything that pops out of the button opens toward the middle of the
  // screen: above it when it sits low, below it when it has been dragged up.
  function place(node) {
    if (!node.classList.contains("cul-fb-on") && node.id !== "cul-fb-intro") return;
    var r = bubble.getBoundingClientRect();
    var low = r.top + r.height / 2 > window.innerHeight / 2;
    node.style.top = node.style.bottom = "";
    if (low) {
      node.style.bottom = (window.innerHeight - r.top + 10) + "px";
      node.style.maxHeight = (r.top - 22) + "px";
    } else {
      node.style.top = (r.bottom + 10) + "px";
      node.style.maxHeight = (window.innerHeight - r.bottom - 22) + "px";
    }
  }
  function placeAll() {
    [hint, panel, menu, document.getElementById("cul-fb-intro")].forEach(function (n) { if (n) place(n); });
  }

  // ---- the menu, when there is somewhere to see all changes --------------
  var menu = el("div");
  menu.id = "cul-fb-menu";
  var report = button("cul-fb-menu-item");
  report.appendChild(el("span", "cul-fb-menu-ico", "◎"));
  var reportWords = el("span", "", "Report something");
  reportWords.appendChild(el("small", "", "Click what looks wrong"));
  report.appendChild(reportWords);
  report.addEventListener("click", function () { closeMenu(); startPicking(); });
  menu.appendChild(report);
  var seeAll = null;
  var seeAllCount = null;
  if (CFG.portal) {
    seeAll = el("a", "cul-fb-menu-item");
    seeAll.href = CFG.portal;
    seeAll.target = "_blank";
    seeAll.rel = "noopener";
    seeAll.appendChild(el("span", "cul-fb-menu-ico", "↗"));
    var seeWords = el("span", "", "See all your changes");
    seeAllCount = el("small", "", "Everything you have sent, and where it is");
    seeWords.appendChild(seeAllCount);
    seeAll.appendChild(seeWords);
    seeAll.addEventListener("click", closeMenu);
    menu.appendChild(seeAll);
  }

  function openMenu() {
    if (seeAllCount && openCount !== null) seeAllCount.textContent = openCount === 0 ? "Nothing open right now" : (openCount > 29 ? "30+" : openCount) + " still open";
    menu.classList.add("cul-fb-on");
    place(menu);
  }
  function closeMenu() { menu.classList.remove("cul-fb-on"); }

  // ---- picking caption ---------------------------------------------------
  var hint = el("div");
  hint.id = "cul-fb-hint";
  hint.appendChild(el("span", "cul-fb-hint-main", CFG.strings.picking));
  var hintOr = el("span", "cul-fb-hint-or", "or ");
  // For what cannot be clicked: a missing section, the page as a whole.
  var pageBtn = button("cul-fb-link", "report the whole page");
  pageBtn.addEventListener("click", function () {
    target = null;
    wholePage = true;
    stopPicking();
    openPanel();
  });
  hintOr.appendChild(pageBtn);
  hint.appendChild(hintOr);

  var halo = el("div");
  halo.id = "cul-fb-halo";

  var panel = el("div");
  panel.id = "cul-fb-panel";

  root.appendChild(bubble);
  root.appendChild(menu);
  root.appendChild(hint);
  root.appendChild(halo);
  root.appendChild(panel);
  applyPosition();
  refreshCount();

  // A toast can carry a link, so the confirmation can point at every change.
  function toast(text, bad, link) {
    var t = el("div", "cul-fb-toast" + (bad ? " cul-fb-bad" : ""), text);
    if (link) {
      t.appendChild(document.createTextNode(" "));
      var a = el("a", "", link.text);
      a.href = link.href;
      a.target = "_blank";
      a.rel = "noopener";
      t.appendChild(a);
    }
    root.appendChild(t);
    setTimeout(function () { t.parentNode && t.parentNode.removeChild(t); }, link ? 7000 : 3600);
  }

  // ---- picking -----------------------------------------------------------
  // While picking, the button becomes the way out.
  function startPicking() {
    picking = true;
    closeMenu();
    closePanel();
    bubble.classList.add("cul-fb-cancel");
    pen.textContent = "✕";
    label.textContent = "Stop picking";
    document.body.classList.add("cul-fb-picking");
    hint.classList.add("cul-fb-on");
    place(hint);
  }

  function stopPicking() {
    picking = false;
    bubble.classList.remove("cul-fb-cancel");
    pen.textContent = "✎";
    label.textContent = CFG.strings.open;
    document.body.classList.remove("cul-fb-picking");
    hint.classList.remove("cul-fb-on");
    halo.classList.remove("cul-fb-on");
  }

  function ours(node) { return !!(node && node.closest && node.closest("#cul-fb-root")); }

  document.addEventListener("mousemove", function (e) {
    if (!picking) return;
    var node = e.target;
    if (ours(node)) { halo.classList.remove("cul-fb-on"); return; }
    // Screen coordinates: the outline lives inside #cul-fb-root, which is
    // pinned to the screen.
    var r = node.getBoundingClientRect();
    halo.style.top = r.top + "px";
    halo.style.left = r.left + "px";
    halo.style.width = r.width + "px";
    halo.style.height = r.height + "px";
    halo.classList.add("cul-fb-on");
  }, true);

  // The page moves under a pinned outline, so it goes until the mouse moves.
  window.addEventListener("scroll", function () {
    if (picking) halo.classList.remove("cul-fb-on");
  }, true);

  // Capture phase, and it stops the event: on a link or a button the click
  // would otherwise navigate away from the very thing being reported.
  document.addEventListener("click", function (e) {
    if (menu.classList.contains("cul-fb-on") && !ours(e.target)) closeMenu();
    if (!picking || ours(e.target)) return;
    e.preventDefault();
    e.stopPropagation();
    target = e.target;
    wholePage = false;
    stopPicking();
    openPanel();
  }, true);

  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    if (picking) { stopPicking(); return; }
    if (menu.classList.contains("cul-fb-on")) { closeMenu(); return; }
    if (panel.classList.contains("cul-fb-on")) closePanel();
  });

  // ---- the form ----------------------------------------------------------
  // Built in the order the client needs it: who they are, what they clicked,
  // what kind of problem, then either the words to change (text), the new
  // picture (a picture) or a description (anything else), and Send.
  function openPanel() {
    var img = wholePage ? null : pictureIn(target);
    var original = editableText(target);
    category = img ? "Image" : original ? "Copy" : "";
    picture = null;
    panel.innerHTML = "";
    panel.scrollTop = 0;

    var head = el("div", "cul-fb-head");
    head.appendChild(el("strong", "", "What is wrong here?"));
    var close = button("cul-fb-x", "✕");
    close.setAttribute("aria-label", "Close");
    close.addEventListener("click", closePanel);
    head.appendChild(close);
    panel.appendChild(head);

    // ---- who. Logged in: WordPress's name, nothing to type. On the review
    // link: a name box the first time, then "Reporting as Brian · change".
    var nameBox = null;
    if (CFG.me) {
      var me = el("div", "cul-fb-as", "Reporting as ");
      me.appendChild(el("strong", "", CFG.me));
      panel.appendChild(me);
    } else if (CFG.askName) {
      var who = el("div", "cul-fb-who");
      var askForName = function (value) {
        who.className = "cul-fb-who";
        who.innerHTML = "";
        var lbl = el("label", "cul-fb-label", "Your name");
        lbl.setAttribute("for", "cul-fb-name");
        nameBox = el("input", "cul-fb-name");
        nameBox.id = "cul-fb-name";
        nameBox.type = "text";
        nameBox.placeholder = "So we know who to ask";
        nameBox.autocomplete = "name";
        nameBox.value = value;
        who.appendChild(lbl);
        who.appendChild(nameBox);
      };
      var known = remembered();
      if (known) {
        who.className = "cul-fb-as";
        who.appendChild(document.createTextNode("Reporting as "));
        who.appendChild(el("strong", "", known));
        who.appendChild(document.createTextNode(" · "));
        var change = button("cul-fb-link", "change");
        change.addEventListener("click", function () {
          askForName(known);
          nameBox.focus();
          nameBox.select();
        });
        who.appendChild(change);
        nameBox = { value: known };
      } else {
        askForName("");
      }
      panel.appendChild(who);
    }

    // ---- what they clicked. Text gets its own crossed out copy below, so
    // the quote box is only for pictures, sections and the whole page.
    if (!original) {
      var what = el("div", "cul-fb-what");
      if (img && (img.currentSrc || img.src)) {
        var thumb = el("img", "cul-fb-thumb");
        thumb.alt = "";
        thumb.src = img.currentSrc || img.src;
        what.appendChild(thumb);
        what.className += " cul-fb-what-pic";
      }
      what.appendChild(el("span", "", wholePage ? "The whole page" : describe(target)));
      panel.appendChild(what);
    }

    // ---- kind of problem: optional, and a second press takes it off again
    var chips = el("div", "cul-fb-chips");
    CATEGORIES.forEach(function (c) {
      var b = button("cul-fb-chip" + (c === category ? " cul-fb-chip-on" : ""), c);
      b.addEventListener("click", function () {
        var off = category === c;
        category = off ? "" : c;
        Array.prototype.forEach.call(chips.children, function (x) { x.classList.remove("cul-fb-chip-on"); });
        if (!off) b.classList.add("cul-fb-chip-on");
      });
      chips.appendChild(b);
    });
    panel.appendChild(chips);

    function grower(box, min) {
      return function () {
        box.style.height = "auto";
        box.style.height = Math.max(min, Math.min(box.scrollHeight + 2, 220)) + "px";
      };
    }

    // ---- the words, edited in place. It says now, crossed out; it should
    // say, starting as the same words so they change only what is wrong.
    var edit = null;
    if (original) {
      panel.appendChild(el("div", "cul-fb-label", "It says now"));
      panel.appendChild(el("div", "cul-fb-was", original));
      var shouldRow = el("div", "cul-fb-label cul-fb-label-row");
      shouldRow.appendChild(el("span", "", "It should say"));
      var undo = button("cul-fb-link", "undo");
      shouldRow.appendChild(undo);
      panel.appendChild(shouldRow);
      edit = el("textarea", "cul-fb-edit");
      edit.value = original;
      edit.rows = 2;
      edit.setAttribute("aria-label", "It should say");
      panel.appendChild(edit);
      var growEdit = grower(edit, 66);
      undo.addEventListener("click", function () { edit.value = original; growEdit(); changed(); edit.focus(); });
      edit.addEventListener("input", function () { growEdit(); changed(); });
      setTimeout(growEdit, 0);
    }

    // ---- the new picture. A big button when they clicked a picture, since
    // swapping it is the likely reason; a quiet link everywhere else.
    var pic = el("div", "cul-fb-pic");
    var file = el("input", "cul-fb-file");
    file.type = "file";
    file.accept = "image/jpeg,image/png,image/gif,image/webp";
    var addPic;
    if (img) {
      addPic = button("cul-fb-addpic");
      addPic.appendChild(el("b", "", "+"));
      var words = el("span", "", "Add the new picture");
      words.appendChild(el("small", "", "JPG, PNG or WebP"));
      addPic.appendChild(words);
    } else {
      addPic = button("cul-fb-link cul-fb-attach", "Attach a picture");
    }
    var chosen = el("div", "cul-fb-chosen");
    addPic.addEventListener("click", function () { file.click(); });
    file.addEventListener("change", function () {
      var f = file.files && file.files[0];
      file.value = "";
      if (!f) return;
      if (!/^image\/(jpeg|png|gif|webp)$/.test(f.type)) { toast("That needs to be a JPG, PNG, GIF or WebP picture.", true); return; }
      addPic.disabled = true;
      chosen.textContent = "Getting it ready…";
      fitPicture(f).then(function (ready) {
        picture = ready;
        showChosen();
        changed();
      }).catch(function (err) {
        toast(err && err.message ? err.message : "That picture could not be used.", true);
        showAdd();
      });
    });
    function showAdd() {
      picture = null;
      chosen.innerHTML = "";
      addPic.disabled = false;
      addPic.style.display = "";
      changed();
    }
    function showChosen() {
      addPic.style.display = "none";
      chosen.innerHTML = "";
      var t = el("img");
      t.alt = "";
      t.src = URL.createObjectURL(picture);
      var remove = button("cul-fb-x", "✕");
      remove.setAttribute("aria-label", "Remove the picture");
      remove.addEventListener("click", showAdd);
      chosen.appendChild(t);
      chosen.appendChild(el("span", "", picture.name));
      chosen.appendChild(remove);
    }
    pic.appendChild(file);
    pic.appendChild(addPic);
    pic.appendChild(chosen);

    // ---- their words. Optional beside an edit, the whole report otherwise.
    var box = el("textarea", "cul-fb-box");
    box.rows = original ? 1 : 2;
    box.placeholder = original ? "Anything else? (optional)"
      : img ? "What should change about this picture?"
      : wholePage ? "What is missing or wrong on this page?"
      : "What should it say or do instead?";
    var growBox = grower(box, original ? 44 : 66);

    if (img) { panel.appendChild(pic); panel.appendChild(box); }
    else { panel.appendChild(box); panel.appendChild(pic); }

    // ---- footer: the promise on the left, Send on the right, asleep until
    // there is something to send.
    var foot = el("div", "cul-fb-foot");
    foot.appendChild(el("span", "cul-fb-note", CFG.strings.wait));
    var send = button("cul-fb-send", "Send");
    send.disabled = true;
    foot.appendChild(send);
    panel.appendChild(foot);

    function edited() { return !!edit && edit.value.trim() !== original; }
    function changed() {
      send.disabled = !(box.value.trim() || edited() || (picture && original));
    }

    function go() {
      if (send.disabled) return;
      submit({
        // A picture and nothing else still needs a sentence on the task.
        message: box.value.trim() || (picture && !edited() ? "Use the attached picture here" : box.value),
        before: edited() ? original : "",
        after: edited() ? edit.value.trim() : "",
        name: nameBox ? nameBox.value : ""
      }, send);
    }
    send.addEventListener("click", go);
    box.addEventListener("input", function () { growBox(); changed(); });
    [box, edit].forEach(function (b) {
      if (b) b.addEventListener("keydown", function (e) {
        if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); go(); }
      });
    });

    panel.classList.add("cul-fb-on");
    place(panel);
    // A new face types their name first; everyone else starts on the words.
    var first = nameBox && nameBox.focus && !nameBox.value ? nameBox : (edit || box);
    first.focus();
    if (first === edit) edit.setSelectionRange(edit.value.length, edit.value.length);
  }

  function closePanel() {
    panel.classList.remove("cul-fb-on");
    halo.classList.remove("cul-fb-on");
    panel.innerHTML = "";
  }

  // ---- names and pictures -----------------------------------------------
  var NAME = "culFbName";
  function remembered() { return stored(NAME); }
  function remember(n) { store(NAME, n); }

  // Under the limit it goes as it is, because a replacement picture should
  // arrive untouched. Over it, redrawn as a JPEG, starting at 3000px (still
  // more than any website needs) and stepping down until it fits. GIFs are
  // left alone: redrawing one keeps only its first frame.
  var STEPS = [[3000, 0.88], [2400, 0.82], [1800, 0.78], [1200, 0.75]];
  function fitPicture(f) {
    if (f.size <= MAX_BYTES) return Promise.resolve(f);
    if (f.type === "image/gif") return Promise.reject(new Error("That picture is over 5MB. Please email it to us instead."));
    return new Promise(function (resolve, reject) {
      var img = new Image();
      img.onload = function () {
        URL.revokeObjectURL(img.src);
        var name = f.name.replace(/\.[^.]+$/, "") + ".jpg";
        (function attempt(i) {
          if (i >= STEPS.length) { reject(new Error("That picture is too big to send. Please email it to us instead.")); return; }
          var scale = Math.min(1, STEPS[i][0] / Math.max(img.naturalWidth, img.naturalHeight));
          var c = document.createElement("canvas");
          c.width = Math.round(img.naturalWidth * scale);
          c.height = Math.round(img.naturalHeight * scale);
          c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
          c.toBlob(function (blob) {
            if (!blob || blob.size > MAX_BYTES) { attempt(i + 1); return; }
            resolve(new File([blob], name, { type: "image/jpeg" }));
          }, "image/jpeg", STEPS[i][1]);
        })(0);
      };
      img.onerror = function () { reject(new Error("That picture could not be opened.")); };
      img.src = URL.createObjectURL(f);
    });
  }

  // The link that opens this page with this element outlined. A hash, not a
  // query string, so no page cache ever sees it and WordPress never has to.
  function showMeUrl(ask) {
    var req = { s: target ? selectorFor(target) : "", t: target ? textOf(target).slice(0, 80) : "", a: ask.slice(0, 160) };
    return location.origin + location.pathname + location.search + SHOW + encodeURIComponent(JSON.stringify(req));
  }

  function submit(r, sendBtn) {
    var name = r.name.trim();
    if (CFG.askName && name) remember(name);
    sendBtn.disabled = true;
    sendBtn.textContent = picture ? "Sending the picture…" : "Sending…";

    var headers = {};
    if (CFG.nonce) headers["X-WP-Nonce"] = CFG.nonce;

    var ask = r.after ? "Should say: " + r.after : r.message.trim();

    // FormData rather than JSON, so a picture can travel with the words.
    var body = new FormData();
    body.append("message", r.message);
    body.append("before", r.before);
    body.append("after", r.after);
    body.append("category", category);
    body.append("name", name);
    body.append("url", location.href.split("#")[0]);
    body.append("page", document.title);
    body.append("scope", wholePage ? "page" : "element");
    body.append("selector", target ? selectorFor(target) : "");
    body.append("snippet", target ? textOf(target) : "");
    body.append("show_url", wholePage ? "" : showMeUrl(ask));
    body.append("viewport", window.innerWidth + "x" + window.innerHeight);
    if (picture) body.append("image", picture, picture.name);

    whoKnown.then(function () {
      if (CFG.nonce) headers["X-WP-Nonce"] = CFG.nonce;
      return fetch(CFG.endpoint, { method: "POST", credentials: "same-origin", headers: headers, body: body });
    }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (j) { return { ok: res.ok, j: j }; });
    }).then(function (res) {
      if (!res.ok) throw new Error(res.j && res.j.error ? res.j.error : "failed");
      closePanel();
      toast(CFG.strings.sent, false, CFG.portal ? { text: "See all your changes", href: CFG.portal } : null);
      refreshCount();
    }).catch(function () {
      sendBtn.disabled = false;
      sendBtn.textContent = "Send";
      toast(CFG.strings.failed, true);
    });
  }

  // ---- what this is, once ------------------------------------------------
  // Shown the first time someone lands in review mode and never again, because
  // a button with no explanation is a button nobody presses, and an
  // explanation you have already read is noise. Kept to three sentences.
  var SEEN = "culFbIntroSeen";
  function seen() { return stored(SEEN) === "1"; }
  function markSeen() { store(SEEN, "1"); }

  function showIntro() {
    var card = el("div");
    card.id = "cul-fb-intro";
    card.appendChild(el("strong", "", "Something look wrong? Tell us here."));
    card.appendChild(el("p", "", "Press Review this site, then click whatever is wrong on the page. Change the words right there, or add a new picture."));
    card.appendChild(el("p", "", "We get the page and the exact spot with it. Drag the button anywhere if it is in the way. Changes can take up to 72 business hours."));
    var ok = button("cul-fb-send", "Got it");
    ok.addEventListener("click", function () { markSeen(); card.remove(); });
    card.appendChild(ok);
    root.appendChild(card);
    place(card);
  }

  if (!seen() && !showReq) setTimeout(function () { if (!seen()) showIntro(); }, 900);

  bubble.addEventListener("click", function () {
    if (justDragged) return;
    markSeen();
    var intro = document.getElementById("cul-fb-intro");
    if (intro) intro.remove();
    if (picking) { stopPicking(); return; }
    if (panel.classList.contains("cul-fb-on")) { closePanel(); return; }
    if (menu.classList.contains("cul-fb-on")) { closeMenu(); return; }
    // With nowhere to see all changes, a menu of one would be a wasted click.
    if (seeAll) openMenu();
    else startPicking();
  });
})();
