# ClickUpLocal Feedback

A question mark bubble on a client's own WordPress site. They click whatever
looks wrong, say what is wrong in a sentence, and it arrives in ClickUpTasks as
a task in that client's list, with the page URL and the exact element attached.

It exists because "the phone number is wrong on one of the pages" costs a round
of emails to locate. Reported where they are standing, it costs one sentence
and arrives already located.

## Install

1. Zip the plugin folder (`./build.sh` writes a versioned zip beside it).
2. WordPress admin, Plugins, Add New, Upload Plugin, and activate.
3. Settings, CUL Feedback.

## Set up

- **ClickUpTasks URL** defaults to the production app.
- **API token** comes from ClickUpTasks, Settings, API tokens. It starts with
  `cut_`. It is stored in this site's options and only ever read on the server,
  never printed into a page.
- **Client** and **List** are real dropdowns, filled from the API through this
  site's own admin so the token stays server side. Every report from this site
  lands in that one list.
- **The link to send** turns review mode on for thirty days on whoever opens
  it. Send it once, at the start of a build.

Logged in editors always see the bubble. Everyone else needs the link, unless
"Show it to every visitor" is deliberately turned on.

## What arrives

Title is their sentence, prefixed with the category if they picked one
(Copy, Image, Layout, Link, Other). The description carries the whole message,
who sent it, the page title, the URL, a CSS path to the element and its text
(or "the whole page"), the screen size and the browser.

**The form adapts to what was clicked.** A picture shows a thumbnail, picks
Image, and puts "Add the new picture" above the text box as a big button.
Anything else gets a quiet "Attach a picture" link under it. The text box starts
at two lines and grows; Send stays asleep until there is something to send.

**Who sent it.** Logged in staff are named by WordPress. Anyone on the review
link is asked for their name at the top of their first report. After that it shows
as "From Brian · change" above Send.

**The whole page.** While picking, "Or report the whole page" files a report
with nothing clicked, for things that are missing rather than wrong.

**A new picture.** "Add a new picture" attaches a JPG, PNG, GIF or WebP. It is
uploaded to ClickUpTasks (`/api/extension/upload`) and arrives on the task as
an image attachment named "Replacement picture: <file>". The ClickUpTasks limit
is 5MB, so bigger photos are shrunk in the browser first (JPEG, stepping down
from 3000px). GIFs over 5MB are refused, because redrawing one keeps only its
first frame. The server checks the bytes really are a picture. If the upload
fails the report still files and says the picture did not make it.

## Page caches

The script loads for every visitor once the plugin is set up, and stays silent
unless PHP said this visitor may report, or the readable `cul_feedback_on`
cookie is there. The review link sets that cookie next to the httponly one, so
a cached page still shows the bubble to a reviewer. The stylesheet is only
fetched when the bubble shows. Pages built for a reviewer set `DONOTCACHEPAGE`
so they are not stored for everyone else.

## Limits

Twenty reports an hour per address, so a frustrated pass through a broken page
cannot open forty tasks.

## Testing

`tests/harness.php` and `tests/updater-test.php` run with Local's PHP.
`tests/browser/index.html` (and `cached.html`, the page cache case) run the
bubble against a fake send; serve the plugin folder and open them.

## Deliberately not here

Automatic screenshots. In browser capture needs a heavy library and renders the
page wrong often enough to mislead. The URL plus the element path plus their
sentence gets you to the spot faster. A picture the client chooses is a
different thing and is supported.
