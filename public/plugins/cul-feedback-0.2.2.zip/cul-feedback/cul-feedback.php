<?php
/**
 * Plugin Name: ClickUpLocal Feedback
 * Description: A question mark bubble on the client's own site. They click what is wrong, say what is wrong, and it lands as a task in ClickUpTasks with the page and the exact element attached.
 * Version: 0.2.2
 * Author: ClickUpLocal
 */

// Why this exists: a client saying "the phone number is wrong on one of the
// pages" costs a round of emails to locate. Reporting it where they are
// standing costs them one sentence and arrives with the URL and the element
// already attached.

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'CUL_FEEDBACK_VERSION', '0.2.2' );
define( 'CUL_FEEDBACK_PATH', plugin_dir_path( __FILE__ ) );
define( 'CUL_FEEDBACK_URL', plugin_dir_url( __FILE__ ) );
// One option row holds the lot. Nothing here is queried independently.
define( 'CUL_FEEDBACK_OPTION', 'cul_feedback_settings' );

require_once CUL_FEEDBACK_PATH . 'includes/class-cul-updater.php';
require_once CUL_FEEDBACK_PATH . 'includes/class-settings.php';
require_once CUL_FEEDBACK_PATH . 'includes/class-admin.php';
require_once CUL_FEEDBACK_PATH . 'includes/class-rest.php';
require_once CUL_FEEDBACK_PATH . 'includes/class-public.php';

// One-click updates from the Plugins screen, the same as a directory plugin.
// Before this, shipping a fix meant uploading a zip by hand in every client
// site's wp-admin, which in practice meant sites ran old versions for months.
CUL_Updater::boot( [
	'slug'     => 'cul-feedback',
	'file'     => __FILE__,
	'version'  => CUL_FEEDBACK_VERSION,
	'manifest' => 'https://clickuptasks.vercel.app/plugins/cul-feedback.json',
] );

add_action( 'admin_menu', [ 'CUL_Feedback_Admin', 'menu' ] );
add_action( 'admin_init', [ 'CUL_Feedback_Admin', 'register' ] );
add_action( 'wp_ajax_cul_feedback_me', [ 'CUL_Feedback_Public', 'ajax_me' ] );
add_action( 'wp_ajax_cul_feedback_lookup', [ 'CUL_Feedback_Admin', 'ajax_lookup' ] );
add_action( 'rest_api_init', [ 'CUL_Feedback_REST', 'register' ] );
add_action( 'init', [ 'CUL_Feedback_Public', 'maybe_start_review' ] );
add_action( 'template_redirect', [ 'CUL_Feedback_Public', 'no_cache_for_reviewers' ] );
add_action( 'wp_enqueue_scripts', [ 'CUL_Feedback_Public', 'enqueue' ] );
