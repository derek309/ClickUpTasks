<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Who sees the bubble, and what the page is told about itself. */
class CUL_Feedback_Public {

	const COOKIE = 'cul_feedback_review';
	// A second, readable cookie that says only "review mode is on". The real
	// one stays httponly. This one exists for cached pages: a page cache
	// serves the same HTML to everyone, so PHP never gets to decide, and the
	// bubble script has to be able to tell for itself.
	const FLAG = 'cul_feedback_on';

	/** A link you send once (?review=<token>) turns review mode on and leaves
	 *  a cookie, so the client keeps the bubble while they click around the
	 *  site instead of losing it on the second page. */
	public static function maybe_start_review() {
		if ( empty( $_GET['review'] ) ) return;
		$given = sanitize_text_field( wp_unslash( $_GET['review'] ) );
		if ( ! hash_equals( CUL_Feedback_Settings::review_token(), $given ) ) return;
		// Thirty days: long enough for a build, short enough that an old link
		// in someone's inbox stops working.
		$until = time() + 30 * DAY_IN_SECONDS;
		setcookie( self::COOKIE, $given, $until, COOKIEPATH ?: '/', COOKIE_DOMAIN, is_ssl(), true );
		setcookie( self::FLAG, '1', $until, COOKIEPATH ?: '/', COOKIE_DOMAIN, is_ssl(), false );
		$_COOKIE[ self::COOKIE ] = $given;
	}

	/** Pages built for a reviewer should not be stored for everyone else.
	 *  DONOTCACHEPAGE is the constant WP Rocket, W3 Total Cache, WP Super
	 *  Cache and most hosts' caches honour. */
	public static function no_cache_for_reviewers() {
		$s = CUL_Feedback_Settings::get();
		if ( ! empty( $s['public_mode'] ) || ! self::may_review() ) return;
		if ( ! defined( 'DONOTCACHEPAGE' ) ) define( 'DONOTCACHEPAGE', true );
		nocache_headers();
	}

	/** Three ways in: you are staff, you followed the review link, or the site
	 *  has deliberately been opened to everyone. */
	public static function may_review() {
		if ( ! CUL_Feedback_Settings::configured() ) return false;
		$s = CUL_Feedback_Settings::get();
		if ( ! empty( $s['public_mode'] ) ) return true;
		if ( is_user_logged_in() && current_user_can( 'edit_posts' ) ) return true;
		$cookie = isset( $_COOKIE[ self::COOKIE ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE ] ) ) : '';
		return $cookie !== '' && hash_equals( CUL_Feedback_Settings::review_token(), $cookie );
	}

	/** Who is logged in, for a bubble on a cached page that cannot tell.
	 *  Registered for logged in users only, so a visitor gets WordPress's
	 *  plain refusal and keeps the name box. The nonce comes too, because the
	 *  one baked into a cached page belongs to nobody. */
	public static function ajax_me() {
		wp_send_json_success( [
			'name'  => wp_get_current_user()->display_name,
			'nonce' => wp_create_nonce( 'wp_rest' ),
		] );
	}

	/** The script loads for every visitor once the plugin is set up, and is
	 *  small and silent until it decides to show. That decision is made in
	 *  two places on purpose: here, when PHP renders the page, and in the
	 *  browser from the flag cookie, when a cache served HTML that PHP built
	 *  for somebody else. The stylesheet is only fetched once it shows. */
	public static function enqueue() {
		if ( is_admin() || ! CUL_Feedback_Settings::configured() ) return;
		$s = CUL_Feedback_Settings::get();

		wp_enqueue_script( 'cul-feedback', CUL_FEEDBACK_URL . 'assets/feedback.js', [], CUL_FEEDBACK_VERSION, true );

		$logged_in = is_user_logged_in();
		wp_localize_script( 'cul-feedback', 'CUL_FEEDBACK', [
			'show'     => self::may_review() ? 1 : 0,
			'flag'     => self::FLAG,
			'css'      => CUL_FEEDBACK_URL . 'assets/feedback.css?ver=' . CUL_FEEDBACK_VERSION,
			'endpoint' => esc_url_raw( rest_url( 'cul-feedback/v1/report' ) ),
			// Only a logged-in user has a usable REST nonce. A cookie reviewer
			// is authorised by the review cookie instead, checked server side.
			'nonce'    => $logged_in ? wp_create_nonce( 'wp_rest' ) : '',
			// Staff are named by WordPress. Everyone else is asked once.
			'askName'  => $logged_in ? 0 : 1,
			'me'       => $logged_in ? wp_get_current_user()->display_name : '',
			'ajax'     => admin_url( 'admin-ajax.php' ),
			'side'     => $s['bubble_side'] === 'left' ? 'left' : 'right',
			'client'   => $s['client_name'],
			'strings'  => [
				'open'    => 'Report something on this page',
				'picking' => 'Click whatever looks wrong',
				// Said on the way out and again on the way in, because a
				// promise made once at the start of a build is a promise
				// nobody remembers by the fourth report.
				'wait'    => 'Changes can take up to 72 business hours.',
				'sent'    => 'Got it. Changes can take up to 72 business hours.',
				'failed'  => 'That did not send. Please try once more.',
			],
		] );
	}
}
