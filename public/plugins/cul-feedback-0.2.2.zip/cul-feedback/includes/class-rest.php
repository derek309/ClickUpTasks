<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** The one route the bubble posts to. It takes the report, decides what the
 *  task should say, and forwards it to ClickUpTasks with the token attached
 *  here rather than in the browser. */
class CUL_Feedback_REST {

	public static function register() {
		register_rest_route( 'cul-feedback/v1', '/report', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'report' ],
			'permission_callback' => [ 'CUL_Feedback_Public', 'may_review' ],
		] );
	}

	public static function report( WP_REST_Request $req ) {
		// Twenty an hour per address. A frustrated client clicking through a
		// broken page should not be able to open forty tasks, and a bot that
		// finds the route should get nowhere.
		$key  = 'cul_fb_' . md5( self::ip() );
		$used = (int) get_transient( $key );
		if ( $used >= 20 ) {
			return new WP_REST_Response( [ 'error' => 'Too many reports from here for now. Try again later.' ], 429 );
		}
		set_transient( $key, $used + 1, HOUR_IN_SECONDS );

		$message = trim( (string) $req->get_param( 'message' ) );
		if ( $message === '' ) {
			return new WP_REST_Response( [ 'error' => 'Say what is wrong first.' ], 400 );
		}

		$category = sanitize_text_field( (string) $req->get_param( 'category' ) );
		$url      = esc_url_raw( (string) $req->get_param( 'url' ) );
		$pageName = sanitize_text_field( (string) $req->get_param( 'page' ) );
		$selector = sanitize_text_field( (string) $req->get_param( 'selector' ) );
		$snippet  = sanitize_text_field( (string) $req->get_param( 'snippet' ) );
		$viewport = sanitize_text_field( (string) $req->get_param( 'viewport' ) );
		$agent    = sanitize_text_field( (string) $req->get_header( 'user_agent' ) );
		$message  = sanitize_textarea_field( $message );
		// "The whole page" is a report with nothing clicked: a missing section
		// has no element to point at.
		$wholePage = $req->get_param( 'scope' ) === 'page';
		$who       = self::reporter( (string) $req->get_param( 'name' ) );

		$s = CUL_Feedback_Settings::get();

		// A replacement picture, when they attached one. Uploaded before the
		// task so it can ride in on the create; if the upload fails the report
		// still files, and says the picture did not make it, rather than
		// losing the sentence they wrote over a file.
		$files      = [];
		$imageNote  = '';
		$uploaded   = $req->get_file_params();
		if ( ! empty( $uploaded['image'] ) && ( $uploaded['image']['error'] ?? UPLOAD_ERR_NO_FILE ) !== UPLOAD_ERR_NO_FILE ) {
			list( $okImg, $img ) = self::forward_image( $uploaded['image'], $s['client_id'] );
			if ( $okImg ) {
				$files[]   = $img;
				$imageNote = 'Picture attached: ' . $img['name'];
			} else {
				error_log( '[cul-feedback] picture did not upload: ' . (string) $img );
				$imageNote = 'They attached a picture but it did not upload (' . (string) $img . '). Ask them to email it.';
			}
		}

		// The title is their sentence, trimmed to a name. The whole of it is
		// in the description regardless, so nothing they typed is lost to the
		// trim.
		$title = self::title_from( $message, $category );

		$lines = [
			$message,
			'',
			'---',
			$who !== '' ? 'Reported by: ' . $who : '',
			'Reported from the website' . ( $pageName !== '' ? ' page "' . $pageName . '"' : '' ),
			$url !== '' ? 'URL: ' . $url : '',
			$wholePage ? 'About: the whole page' : '',
			! $wholePage && $selector !== '' ? 'Element: ' . $selector : '',
			! $wholePage && $snippet !== '' ? 'Element text: ' . $snippet : '',
			$imageNote,
			$viewport !== '' ? 'Screen: ' . $viewport : '',
			$agent !== '' ? 'Browser: ' . $agent : '',
		];
		$description = implode( "\n", array_filter( $lines, static function ( $l ) { return $l !== ''; } ) );

		$body = [
			'client_id'    => $s['client_id'],
			'project_id'   => $s['project_id'],
			'title'        => $title,
			'description'  => $description,
			// Dated on arrival, both ends. Due in three working days, which is
			// the 72 business hours the client is promised on the way out, and
			// followed up today so it is looked at rather than found later.
			'due'          => self::business_days_from_today( 3 ),
			'follow_up_at' => self::today(),
		];
		if ( $files ) $body['files'] = $files;

		list( $ok, $data ) = CUL_Feedback_Settings::api_post( '/api/extension/tasks', $body );

		if ( ! $ok ) {
			// Logged, not shown. The client cannot act on "Unauthorized" and
			// should not be told the plumbing is broken.
			error_log( '[cul-feedback] could not file report: ' . (string) $data );
			return new WP_REST_Response( [ 'error' => 'Could not send that just now.' ], 502 );
		}

		return new WP_REST_Response( [ 'ok' => true, 'task_id' => is_array( $data ) ? ( $data['id'] ?? '' ) : '' ], 200 );
	}

	/** Site local, not UTC: a report filed at 6pm in California should not be
	 *  due a day early because the server thinks it is already tomorrow. */
	private static function today() {
		return wp_date( 'Y-m-d' );
	}

	/** Weekends do not count. Three working days from a Thursday is the
	 *  following Tuesday, which is what "72 business hours" means to the person
	 *  who has to do the work. */
	private static function business_days_from_today( $days ) {
		$ts = current_time( 'timestamp' );
		while ( $days > 0 ) {
			$ts += DAY_IN_SECONDS;
			$dow = (int) wp_date( 'N', $ts );
			if ( $dow < 6 ) $days--;
		}
		return wp_date( 'Y-m-d', $ts );
	}

	/** "Copy · The phone number here is the old one" — the category first so a
	 *  list of these reads as a list of kinds of problem. */
	private static function title_from( $message, $category ) {
		$first = trim( explode( "\n", $message )[0] );
		if ( function_exists( 'mb_strlen' ) && mb_strlen( $first ) > 70 ) {
			$first = rtrim( mb_substr( $first, 0, 69 ) ) . '…';
		} elseif ( strlen( $first ) > 70 ) {
			$first = rtrim( substr( $first, 0, 69 ) ) . '…';
		}
		return ( $category !== '' ? $category . ': ' : '' ) . $first;
	}

	/** A logged in user is who WordPress says they are; anyone on the review
	 *  link is who they typed, because there is nothing else to go on. */
	private static function reporter( $typed ) {
		if ( is_user_logged_in() ) {
			$u = wp_get_current_user();
			if ( $u && $u->display_name !== '' ) return $u->display_name;
		}
		$typed = sanitize_text_field( $typed );
		return function_exists( 'mb_substr' ) ? mb_substr( $typed, 0, 80 ) : substr( $typed, 0, 80 );
	}

	/** Checks the file really is a picture (by its bytes, not its name) and
	 *  hands it to ClickUpTasks. Returns [ok, file entry|error]. Five megabytes
	 *  is the ClickUpTasks upload limit; the bubble shrinks bigger photos
	 *  before sending, so this only catches what got past it. */
	private static function forward_image( array $file, $client_id ) {
		if ( ( $file['error'] ?? 1 ) !== UPLOAD_ERR_OK || empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
			return [ false, 'upload error' ];
		}
		if ( (int) $file['size'] > 5 * 1024 * 1024 ) return [ false, 'over 5MB' ];

		$info  = @getimagesize( $file['tmp_name'] );
		$types = [ 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp' ];
		if ( ! $info || ! isset( $types[ $info['mime'] ] ) ) return [ false, 'not a picture' ];

		$name = sanitize_file_name( (string) ( $file['name'] ?? '' ) );
		if ( $name === '' ) $name = 'picture.' . $types[ $info['mime'] ];

		list( $ok, $data ) = CUL_Feedback_Settings::api_upload( '/api/extension/upload', [ 'client_id' => $client_id ], $file['tmp_name'], $name, $info['mime'] );
		if ( ! $ok ) return [ false, (string) $data ];
		if ( ! is_array( $data ) || empty( $data['path'] ) ) return [ false, 'no path returned' ];
		return [ true, [ 'path' => $data['path'], 'name' => 'Replacement picture: ' . $name, 'kind' => 'image' ] ];
	}

	private static function ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
		return $ip;
	}
}
