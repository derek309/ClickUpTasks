#!/bin/bash
# Cut a release of this plugin and stage it in the ClickUpTasks app, which is
# what every installed copy checks for updates.
#
# Two artifacts, both under clickuptasks/public/plugins/:
#   <slug>-<version>.zip   what WordPress downloads and unzips
#   <slug>.json            the manifest the updater reads
#
# Static files on purpose. No API route, no database, nothing to break at 2am:
# Vercel serves them from its CDN and the whole update path is two GETs.
#
# The zip's top-level folder MUST be the plugin folder name. WordPress swaps
# folders by name on update, so a mismatch installs a second copy alongside
# the old one instead of replacing it. build.sh already zips from the parent
# directory for exactly this reason.
#
# After running this you still have to commit and push the ClickUpTasks repo.
# Deliberate: the release is not live until you have looked at the diff.
set -euo pipefail
cd "$(dirname "$0")"

SLUG="cul-feedback"
APP="/Users/derekfox/dev/clickuptasks"
DEST="$APP/public/plugins"

VERSION=$(grep -m1 "^ \* Version:" "$SLUG.php" | sed 's/.*Version:[[:space:]]*//')
# The header and the constant are read by different things (WordPress vs the
# updater's own boot call), and a mismatch means the Plugins screen offers an
# update the site already has. Cheaper to fail here than to debug there.
CONST=$(grep -m1 "define( 'CUL_FEEDBACK_VERSION'" "$SLUG.php" | sed "s/.*'\\([0-9.]*\\)'.*/\\1/")
if [ "$VERSION" != "$CONST" ]; then
  echo "Version mismatch: header says $VERSION, CUL_FEEDBACK_VERSION says $CONST" >&2
  exit 1
fi

[ -d "$APP" ] || { echo "ClickUpTasks not found at $APP" >&2; exit 1; }
mkdir -p "$DEST"

./build.sh >/dev/null
mv "../$SLUG-$VERSION.zip" "$DEST/$SLUG-$VERSION.zip"

# Written fresh every release rather than hand-edited, so the version in the
# manifest can never drift from the zip sitting next to it.
cat > "$DEST/$SLUG.json" <<JSON
{
  "name": "ClickUpLocal Feedback",
  "slug": "$SLUG",
  "version": "$VERSION",
  "author": "ClickUpLocal",
  "requires": "6.0",
  "tested": "6.8",
  "requires_php": "7.4",
  "last_updated": "$(date -u +%Y-%m-%d\ %H:%M:%S)",
  "download_url": "https://clickuptasks.vercel.app/plugins/$SLUG-$VERSION.zip",
  "homepage": "https://clickuptasks.vercel.app",
  "description": "A question mark bubble on the client's own site. They click what is wrong, say what is wrong, and it lands as a task in ClickUpTasks with the page and the exact element attached.",
  "changelog": "See the commit history."
}
JSON

echo "staged $SLUG $VERSION"
echo "  zip      $DEST/$SLUG-$VERSION.zip"
echo "  manifest $DEST/$SLUG.json"
echo
echo "Now, in $APP:"
echo "  git add public/plugins && git commit -m \"cul-feedback $VERSION\" && git push"
echo "Every site running $SLUG sees the update within 6 hours, or straight away on Dashboard > Updates > Check again."
