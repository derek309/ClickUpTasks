<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Reading and writing the one option row, plus the calls out to ClickUpTasks.
 *  Every request to ClickUpTasks goes through here, so the API token is only
 *  ever read on the server: a token in page JavaScript is a token anyone who
 *  views source can use to create tasks on any of your clients. */
class CUL_Feedback_Settings {

	public static function defaults() {
		return [
			'api_base'     => 'https://clickuptasks.vercel.app',
			'api_token'    => '',
			'client_id'    => '',
			'client_name'  => '',
			'project_id'   => '',
			'project_name' => '',
			// The link you send the client. Generated on first save so it is
			// never a value anyone had to think of.
			'review_token' => '',
			// Off by default. A public bubble invites feedback from people who
			// are not your client.
			'public_mode'  => 0,
			'bubble_side'  => 'right',
		];
	}

	public static function get() {
		$saved = get_option( CUL_FEEDBACK_OPTION, [] );
		return wp_parse_args( is_array( $saved ) ? $saved : [], self::defaults() );
	}

	public static function save( array $values ) {
		update_option( CUL_FEEDBACK_OPTION, wp_parse_args( $values, self::get() ) );
	}

	/** True once it can actually file a task. The bubble stays hidden until
	 *  then rather than collecting reports that go nowhere. */
	public static function configured() {
		$s = self::get();
		return $s['api_token'] !== '' && $s['client_id'] !== '';
	}

	public static function review_token() {
		$s = self::get();
		if ( $s['review_token'] === '' ) {
			$s['review_token'] = wp_generate_password( 24, false, false );
			self::save( $s );
		}
		return $s['review_token'];
	}

	/** GET against the ClickUpTasks extension API. Returns [ok, data|error]. */
	public static function api_get( $path ) {
		return self::api_call( 'GET', $path, null );
	}

	public static function api_post( $path, array $body ) {
		return self::api_call( 'POST', $path, $body );
	}

	private static function api_call( $method, $path, $body ) {
		$s = self::get();
		if ( $s['api_token'] === '' ) return [ false, 'No API token saved yet.' ];

		$args = [
			'method'  => $method,
			'timeout' => 15,
			'headers' => [
				'Authorization' => 'Bearer ' . $s['api_token'],
				'Content-Type'  => 'application/json',
			],
		];
		if ( $body !== null ) $args['body'] = wp_json_encode( $body );

		$res = wp_remote_request( rtrim( $s['api_base'], '/' ) . $path, $args );
		if ( is_wp_error( $res ) ) return [ false, $res->get_error_message() ];

		$code = wp_remote_retrieve_response_code( $res );
		$json = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( $code < 200 || $code >= 300 ) {
			// The API's own message when it has one: "Unauthorized" tells you
			// the token is wrong, which a bare 401 does not.
			$msg = is_array( $json ) && ! empty( $json['error'] ) ? $json['error'] : 'HTTP ' . $code;
			return [ false, $msg ];
		}
		return [ true, $json ];
	}
}
