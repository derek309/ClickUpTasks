<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** Who sees the bubble, and what the page is told about itself. */
class CUL_Feedback_Public {

	const COOKIE = 'cul_feedback_review';

	/** A link you send once (?review=<token>) turns review mode on and leaves
	 *  a cookie, so the client keeps the bubble while they click around the
	 *  site instead of losing it on the second page. */
	public static function maybe_start_review() {
		if ( empty( $_GET['review'] ) ) return;
		$given = sanitize_text_field( wp_unslash( $_GET['review'] ) );
		if ( ! hash_equals( CUL_Feedback_Settings::review_token(), $given ) ) return;
		// Thirty days: long enough for a build, short enough that an old link
		// in someone's inbox stops working.
		setcookie( self::COOKIE, $given, time() + 30 * DAY_IN_SECONDS, COOKIEPATH ?: '/', COOKIE_DOMAIN, is_ssl(), true );
		$_COOKIE[ self::COOKIE ] = $given;
	}

	/** Three ways in: you are staff, you followed the review link, or the site
	 *  has deliberately been opened to everyone. */
	public static function may_review() {
		if ( ! CUL_Feedback_Settings::configured() ) return false;
		$s = CUL_Feedback_Settings::get();
		if ( ! empty( $s['public_mode'] ) ) return true;
		if ( is_user_logged_in() && current_user_can( 'edit_posts' ) ) return true;
		$cookie = isset( $_COOKIE[ self::COOKIE ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE ] ) ) : '';
		return $cookie !== '' && hash_equals( CUL_Feedback_Settings::review_token(), $cookie );
	}

	public static function enqueue() {
		if ( is_admin() || ! self::may_review() ) return;
		$s = CUL_Feedback_Settings::get();

		wp_enqueue_style( 'cul-feedback', CUL_FEEDBACK_URL . 'assets/feedback.css', [], CUL_FEEDBACK_VERSION );
		wp_enqueue_script( 'cul-feedback', CUL_FEEDBACK_URL . 'assets/feedback.js', [], CUL_FEEDBACK_VERSION, true );

		wp_localize_script( 'cul-feedback', 'CUL_FEEDBACK', [
			'endpoint' => esc_url_raw( rest_url( 'cul-feedback/v1/report' ) ),
			// Only a logged-in user has a usable REST nonce. A cookie reviewer
			// is authorised by the review cookie instead, checked server side.
			'nonce'    => is_user_logged_in() ? wp_create_nonce( 'wp_rest' ) : '',
			'side'     => $s['bubble_side'] === 'left' ? 'left' : 'right',
			'client'   => $s['client_name'],
			'strings'  => [
				'open'    => 'Report something on this page',
				'picking' => 'Click whatever looks wrong',
				// Said on the way out and again on the way in, because a
				// promise made once at the start of a build is a promise
				// nobody remembers by the fourth report.
				'wait'    => 'Changes can take up to 72 business hours.',
				'sent'    => 'Got it. Changes can take up to 72 business hours.',
				'failed'  => 'That did not send. Please try once more.',
			],
		] );
	}
}
