<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/** The one route the bubble posts to. It takes the report, decides what the
 *  task should say, and forwards it to ClickUpTasks with the token attached
 *  here rather than in the browser. */
class CUL_Feedback_REST {

	public static function register() {
		register_rest_route( 'cul-feedback/v1', '/report', [
			'methods'             => 'POST',
			'callback'            => [ __CLASS__, 'report' ],
			'permission_callback' => [ 'CUL_Feedback_Public', 'may_review' ],
		] );
	}

	public static function report( WP_REST_Request $req ) {
		// Twenty an hour per address. A frustrated client clicking through a
		// broken page should not be able to open forty tasks, and a bot that
		// finds the route should get nowhere.
		$key  = 'cul_fb_' . md5( self::ip() );
		$used = (int) get_transient( $key );
		if ( $used >= 20 ) {
			return new WP_REST_Response( [ 'error' => 'Too many reports from here for now. Try again later.' ], 429 );
		}
		set_transient( $key, $used + 1, HOUR_IN_SECONDS );

		$message = trim( (string) $req->get_param( 'message' ) );
		if ( $message === '' ) {
			return new WP_REST_Response( [ 'error' => 'Say what is wrong first.' ], 400 );
		}

		$category = sanitize_text_field( (string) $req->get_param( 'category' ) );
		$url      = esc_url_raw( (string) $req->get_param( 'url' ) );
		$pageName = sanitize_text_field( (string) $req->get_param( 'page' ) );
		$selector = sanitize_text_field( (string) $req->get_param( 'selector' ) );
		$snippet  = sanitize_text_field( (string) $req->get_param( 'snippet' ) );
		$viewport = sanitize_text_field( (string) $req->get_param( 'viewport' ) );
		$agent    = sanitize_text_field( (string) $req->get_header( 'user_agent' ) );
		$message  = sanitize_textarea_field( $message );

		$s = CUL_Feedback_Settings::get();

		// The title is their sentence, trimmed to a name. The whole of it is
		// in the description regardless, so nothing they typed is lost to the
		// trim.
		$title = self::title_from( $message, $category );

		$lines = [
			$message,
			'',
			'---',
			'Reported from the website' . ( $pageName !== '' ? ' page "' . $pageName . '"' : '' ),
			$url !== '' ? 'URL: ' . $url : '',
			$selector !== '' ? 'Element: ' . $selector : '',
			$snippet !== '' ? 'Element text: ' . $snippet : '',
			$viewport !== '' ? 'Screen: ' . $viewport : '',
			$agent !== '' ? 'Browser: ' . $agent : '',
		];
		$description = implode( "\n", array_filter( $lines, static function ( $l ) { return $l !== ''; } ) );

		list( $ok, $data ) = CUL_Feedback_Settings::api_post( '/api/extension/tasks', [
			'client_id'    => $s['client_id'],
			'project_id'   => $s['project_id'],
			'title'        => $title,
			'description'  => $description,
			// Dated on arrival, both ends. Due in three working days, which is
			// the 72 business hours the client is promised on the way out, and
			// followed up today so it is looked at rather than found later.
			'due'          => self::business_days_from_today( 3 ),
			'follow_up_at' => self::today(),
		] );

		if ( ! $ok ) {
			// Logged, not shown. The client cannot act on "Unauthorized" and
			// should not be told the plumbing is broken.
			error_log( '[cul-feedback] could not file report: ' . (string) $data );
			return new WP_REST_Response( [ 'error' => 'Could not send that just now.' ], 502 );
		}

		return new WP_REST_Response( [ 'ok' => true, 'task_id' => is_array( $data ) ? ( $data['id'] ?? '' ) : '' ], 200 );
	}

	/** Site local, not UTC: a report filed at 6pm in California should not be
	 *  due a day early because the server thinks it is already tomorrow. */
	private static function today() {
		return wp_date( 'Y-m-d' );
	}

	/** Weekends do not count. Three working days from a Thursday is the
	 *  following Tuesday, which is what "72 business hours" means to the person
	 *  who has to do the work. */
	private static function business_days_from_today( $days ) {
		$ts = current_time( 'timestamp' );
		while ( $days > 0 ) {
			$ts += DAY_IN_SECONDS;
			$dow = (int) wp_date( 'N', $ts );
			if ( $dow < 6 ) $days--;
		}
		return wp_date( 'Y-m-d', $ts );
	}

	/** "Copy · The phone number here is the old one" — the category first so a
	 *  list of these reads as a list of kinds of problem. */
	private static function title_from( $message, $category ) {
		$first = trim( explode( "\n", $message )[0] );
		if ( function_exists( 'mb_strlen' ) && mb_strlen( $first ) > 70 ) {
			$first = rtrim( mb_substr( $first, 0, 69 ) ) . '…';
		} elseif ( strlen( $first ) > 70 ) {
			$first = rtrim( substr( $first, 0, 69 ) ) . '…';
		}
		return ( $category !== '' ? $category . ': ' : '' ) . $first;
	}

	private static function ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'unknown';
		return $ip;
	}
}
