<?php
/**
 * One-click updates for a ClickUpLocal plugin that is not in the WordPress
 * plugin directory.
 *
 * Without this, shipping a fix means uploading a zip by hand in every client
 * site's wp-admin, and in practice that means sites quietly run old versions
 * for months. With it, WordPress shows "Update available" on the Plugins
 * screen exactly as it does for a directory plugin, and updating is one click.
 *
 * DELIBERATELY GENERIC. Nothing here mentions Feedback: it takes a slug, a
 * version and a manifest URL, so the next plugin gets the same behaviour by
 * copying this one file and calling boot(). Keep it that way.
 *
 * How WordPress update checks actually work, since it is not obvious:
 *   - Core periodically builds a "which plugins have updates" transient and
 *     runs it through the update_plugins filter. We add our own entry.
 *   - When someone clicks "View details", core calls the plugins_api filter.
 *     Without an answer there the modal shows a wall of nothing, so we answer.
 *   - The download is a plain URL. Core fetches it, unzips it, and swaps the
 *     folder. The zip's top-level folder name MUST match the plugin folder or
 *     WordPress installs it alongside the old one instead of replacing it.
 *
 * The manifest is cached in a transient. Without that, every admin page load
 * on every site would make an outbound HTTP request, which is both slow for
 * the person clicking around and rude to the server.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'CUL_Updater' ) ) :

class CUL_Updater {

	/** How long a fetched manifest is trusted before asking again. Long
	 *  enough that browsing wp-admin costs nothing, short enough that a
	 *  release is visible the same day. "Check again" on the Updates screen
	 *  clears it, so there is always a way to force a look. */
	const CACHE_HOURS = 6;

	/** @var array<string,array> keyed by plugin basename */
	private static $plugins = [];

	/**
	 * @param array $args slug, file (the plugin's main __FILE__), version, manifest (URL).
	 */
	public static function boot( array $args ) {
		foreach ( [ 'slug', 'file', 'version', 'manifest' ] as $required ) {
			if ( empty( $args[ $required ] ) ) return; // Misconfigured: do nothing rather than half-work.
		}
		$basename = plugin_basename( $args['file'] );
		self::$plugins[ $basename ] = $args;

		// Registered once no matter how many plugins boot, so two ClickUpLocal
		// plugins on one site do not each add their own copy of these filters.
		static $hooked = false;
		if ( $hooked ) return;
		$hooked = true;
		add_filter( 'pre_set_site_transient_update_plugins', [ __CLASS__, 'check' ] );
		add_filter( 'plugins_api', [ __CLASS__, 'details' ], 10, 3 );
		add_action( 'upgrader_process_complete', [ __CLASS__, 'forget' ], 10, 0 );
	}

	/** The manifest, or null. Cached, and never allowed to throw: an update
	 *  server that is down or returning nonsense must leave the Plugins screen
	 *  working normally rather than breaking wp-admin. */
	private static function manifest( array $p ) {
		$key    = 'cul_updater_' . md5( $p['manifest'] );
		$cached = get_transient( $key );
		if ( is_array( $cached ) ) return $cached;

		$res = wp_remote_get( $p['manifest'], [ 'timeout' => 10, 'headers' => [ 'Accept' => 'application/json' ] ] );
		if ( is_wp_error( $res ) || 200 !== wp_remote_retrieve_response_code( $res ) ) {
			// Cache the failure briefly too, so a site does not retry a dead
			// host on every single admin page load.
			set_transient( $key, [ 'failed' => true ], 30 * MINUTE_IN_SECONDS );
			return null;
		}
		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( ! is_array( $data ) || empty( $data['version'] ) || empty( $data['download_url'] ) ) return null;

		// https only. Core will happily install whatever this URL returns, so
		// an http manifest would let anyone on the network hand a client site
		// a plugin of their choosing.
		if ( 0 !== strpos( $data['download_url'], 'https://' ) ) return null;

		set_transient( $key, $data, self::CACHE_HOURS * HOUR_IN_SECONDS );
		return $data;
	}

	/** Add an entry for each booted plugin that has a newer version out. */
	public static function check( $transient ) {
		// Core calls this filter before the transient object exists in some
		// flows; bail rather than building one from scratch.
		if ( ! is_object( $transient ) ) return $transient;

		foreach ( self::$plugins as $basename => $p ) {
			$m = self::manifest( $p );
			if ( ! $m || ! empty( $m['failed'] ) ) continue;

			$item = (object) [
				'id'           => $p['slug'],
				'slug'         => $p['slug'],
				'plugin'       => $basename,
				'new_version'  => $m['version'],
				'url'          => $m['homepage'] ?? '',
				'package'      => $m['download_url'],
				'tested'       => $m['tested'] ?? '',
				'requires_php' => $m['requires_php'] ?? '',
			];

			if ( version_compare( $m['version'], $p['version'], '>' ) ) {
				$transient->response[ $basename ] = $item;
			} else {
				// Up to date still has to be reported, or the Plugins screen
				// shows "unknown" and offers no "View details" link at all.
				$transient->no_update[ $basename ] = $item;
			}
		}
		return $transient;
	}

	/** Fill the "View details" modal. Without this it renders empty. */
	public static function details( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) ) return $result;

		foreach ( self::$plugins as $p ) {
			if ( $p['slug'] !== $args->slug ) continue;
			$m = self::manifest( $p );
			if ( ! $m || ! empty( $m['failed'] ) ) return $result;

			return (object) [
				'name'          => $m['name'] ?? $p['slug'],
				'slug'          => $p['slug'],
				'version'       => $m['version'],
				'author'        => $m['author'] ?? 'ClickUpLocal',
				'homepage'      => $m['homepage'] ?? '',
				'requires'      => $m['requires'] ?? '',
				'tested'        => $m['tested'] ?? '',
				'requires_php'  => $m['requires_php'] ?? '',
				'last_updated'  => $m['last_updated'] ?? '',
				'download_link' => $m['download_url'],
				'sections'      => [
					'description' => $m['description'] ?? '',
					'changelog'   => $m['changelog'] ?? '',
				],
			];
		}
		return $result;
	}

	/** After any update runs, drop the cache so the Plugins screen reflects
	 *  what was just installed instead of insisting an update is still due. */
	public static function forget() {
		foreach ( self::$plugins as $p ) {
			delete_transient( 'cul_updater_' . md5( $p['manifest'] ) );
		}
	}
}

endif;
