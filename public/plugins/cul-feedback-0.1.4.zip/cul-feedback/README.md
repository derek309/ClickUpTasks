# ClickUpLocal Feedback

A question mark bubble on a client's own WordPress site. They click whatever
looks wrong, say what is wrong in a sentence, and it arrives in ClickUpTasks as
a task in that client's list, with the page URL and the exact element attached.

It exists because "the phone number is wrong on one of the pages" costs a round
of emails to locate. Reported where they are standing, it costs one sentence
and arrives already located.

## Install

1. Zip the plugin folder (`./build.sh` writes a versioned zip beside it).
2. WordPress admin, Plugins, Add New, Upload Plugin, and activate.
3. Settings, CUL Feedback.

## Set up

- **ClickUpTasks URL** defaults to the production app.
- **API token** comes from ClickUpTasks, Settings, API tokens. It starts with
  `cut_`. It is stored in this site's options and only ever read on the server,
  never printed into a page.
- **Client** and **List** are real dropdowns, filled from the API through this
  site's own admin so the token stays server side. Every report from this site
  lands in that one list.
- **The link to send** turns review mode on for thirty days on whoever opens
  it. Send it once, at the start of a build.

Logged in editors always see the bubble. Everyone else needs the link, unless
"Show it to every visitor" is deliberately turned on.

## What arrives

Title is their sentence, prefixed with the category they picked
(Copy, Image, Layout, Link, Other). The description carries the whole message
plus the page title, the URL, a CSS path to the element, the element's own
text, the screen size and the browser.

## Limits

Twenty reports an hour per address, so a frustrated pass through a broken page
cannot open forty tasks.

## Deliberately not here

Screenshots. In browser capture needs a heavy library and renders the page
wrong often enough to mislead. The URL plus the element path plus their
sentence gets you to the spot faster.
