// The bubble, the crosshair, and the little form. No framework and no build
// step: this runs on client sites we do not control, so it ships as one file
// that touches nothing outside its own ids.
(function () {
  var CFG = window.CUL_FEEDBACK;
  if (!CFG) return;

  var CATEGORIES = ["Copy", "Image", "Layout", "Link", "Other"];
  var picking = false;
  var target = null;
  var category = "Other";

  // ---- the element you clicked, described well enough to find again -------
  // Not a unique selector for its own sake: an id when there is one, else the
  // tag and its position among siblings, four levels up. Enough to land on
  // the right thing by eye, which is what a person fixing it needs.
  function selectorFor(el) {
    var parts = [];
    var node = el;
    for (var depth = 0; node && node.nodeType === 1 && depth < 4; depth++) {
      if (node.id) { parts.unshift("#" + node.id); break; }
      var name = node.nodeName.toLowerCase();
      if (node.className && typeof node.className === "string") {
        var cls = node.className.trim().split(/\s+/).filter(function (c) { return c && c.indexOf("cul-fb") !== 0; })[0];
        if (cls) name += "." + cls;
      }
      var parent = node.parentNode;
      if (parent && parent.children && parent.children.length > 1) {
        var same = Array.prototype.filter.call(parent.children, function (c) { return c.nodeName === node.nodeName; });
        if (same.length > 1) name += ":nth-of-type(" + (Array.prototype.indexOf.call(same, node) + 1) + ")";
      }
      parts.unshift(name);
      node = parent;
    }
    return parts.join(" > ");
  }

  function textOf(el) {
    var t = (el.innerText || el.textContent || "").replace(/\s+/g, " ").trim();
    return t.length > 120 ? t.slice(0, 119) + "…" : t;
  }

  // ---- chrome ------------------------------------------------------------
  var root = document.createElement("div");
  root.id = "cul-fb-root";
  root.setAttribute("data-side", CFG.side || "right");

  var bubble = document.createElement("button");
  bubble.id = "cul-fb-bubble";
  bubble.type = "button";
  bubble.title = CFG.strings.open;
  bubble.setAttribute("aria-label", CFG.strings.open);
  bubble.textContent = "?";

  var hint = document.createElement("div");
  hint.id = "cul-fb-hint";
  hint.textContent = CFG.strings.picking;

  var halo = document.createElement("div");
  halo.id = "cul-fb-halo";

  var panel = document.createElement("div");
  panel.id = "cul-fb-panel";

  root.appendChild(bubble);
  root.appendChild(hint);
  root.appendChild(halo);
  root.appendChild(panel);
  document.addEventListener("DOMContentLoaded", function () { document.body.appendChild(root); });
  if (document.readyState !== "loading") document.body.appendChild(root);

  function toast(text, bad) {
    var t = document.createElement("div");
    t.className = "cul-fb-toast" + (bad ? " cul-fb-bad" : "");
    t.textContent = text;
    root.appendChild(t);
    setTimeout(function () { t.parentNode && t.parentNode.removeChild(t); }, 3600);
  }

  // ---- picking -----------------------------------------------------------
  function startPicking() {
    picking = true;
    document.body.classList.add("cul-fb-picking");
    hint.classList.add("cul-fb-on");
    closePanel();
  }

  function stopPicking() {
    picking = false;
    document.body.classList.remove("cul-fb-picking");
    hint.classList.remove("cul-fb-on");
    halo.classList.remove("cul-fb-on");
  }

  function ours(el) { return !!(el && el.closest && el.closest("#cul-fb-root")); }

  document.addEventListener("mousemove", function (e) {
    if (!picking) return;
    var el = e.target;
    if (ours(el)) { halo.classList.remove("cul-fb-on"); return; }
    var r = el.getBoundingClientRect();
    halo.style.top = (r.top + window.scrollY) + "px";
    halo.style.left = (r.left + window.scrollX) + "px";
    halo.style.width = r.width + "px";
    halo.style.height = r.height + "px";
    halo.classList.add("cul-fb-on");
  }, true);

  // Capture phase, and it stops the event: on a link or a button the click
  // would otherwise navigate away from the very thing being reported.
  document.addEventListener("click", function (e) {
    if (!picking || ours(e.target)) return;
    e.preventDefault();
    e.stopPropagation();
    target = e.target;
    stopPicking();
    openPanel();
  }, true);

  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    if (picking) { stopPicking(); return; }
    if (panel.classList.contains("cul-fb-on")) closePanel();
  });

  // ---- the form ----------------------------------------------------------
  function openPanel() {
    category = "Other";
    panel.innerHTML = "";

    var head = document.createElement("div");
    head.className = "cul-fb-head";
    head.innerHTML = '<strong>What is wrong here?</strong>';
    var close = document.createElement("button");
    close.type = "button";
    close.className = "cul-fb-x";
    close.setAttribute("aria-label", "Close");
    close.textContent = "✕";
    close.addEventListener("click", closePanel);
    head.appendChild(close);

    var what = document.createElement("div");
    what.className = "cul-fb-what";
    what.textContent = textOf(target) || target.nodeName.toLowerCase();

    var chips = document.createElement("div");
    chips.className = "cul-fb-chips";
    CATEGORIES.forEach(function (c) {
      var b = document.createElement("button");
      b.type = "button";
      b.className = "cul-fb-chip" + (c === category ? " cul-fb-chip-on" : "");
      b.textContent = c;
      b.addEventListener("click", function () {
        category = c;
        Array.prototype.forEach.call(chips.children, function (x) { x.classList.remove("cul-fb-chip-on"); });
        b.classList.add("cul-fb-chip-on");
      });
      chips.appendChild(b);
    });

    var box = document.createElement("textarea");
    box.className = "cul-fb-box";
    box.rows = 3;
    box.placeholder = "The phone number here is the old one";

    var send = document.createElement("button");
    send.type = "button";
    send.className = "cul-fb-send";
    send.textContent = "Send";
    send.addEventListener("click", function () { submit(box.value, send); });

    box.addEventListener("keydown", function (e) {
      if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) { e.preventDefault(); submit(box.value, send); }
    });

    var foot = document.createElement("div");
    foot.className = "cul-fb-foot";
    foot.appendChild(send);
    var note = document.createElement("span");
    note.className = "cul-fb-note";
    note.textContent = CFG.strings.wait || "We get the page and the exact spot with it.";
    foot.appendChild(note);

    panel.appendChild(head);
    panel.appendChild(what);
    panel.appendChild(chips);
    panel.appendChild(box);
    panel.appendChild(foot);
    panel.classList.add("cul-fb-on");
    box.focus();
  }

  function closePanel() {
    panel.classList.remove("cul-fb-on");
    halo.classList.remove("cul-fb-on");
    panel.innerHTML = "";
  }

  function submit(message, button) {
    if (!message.trim()) return;
    button.disabled = true;
    button.textContent = "Sending…";

    var headers = { "Content-Type": "application/json" };
    if (CFG.nonce) headers["X-WP-Nonce"] = CFG.nonce;

    fetch(CFG.endpoint, {
      method: "POST",
      credentials: "same-origin",
      headers: headers,
      body: JSON.stringify({
        message: message,
        category: category,
        url: location.href,
        page: document.title,
        selector: target ? selectorFor(target) : "",
        snippet: target ? textOf(target) : "",
        viewport: window.innerWidth + "x" + window.innerHeight
      })
    }).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) { return { ok: r.ok, j: j }; });
    }).then(function (res) {
      if (!res.ok) throw new Error(res.j && res.j.error ? res.j.error : "failed");
      closePanel();
      toast(CFG.strings.sent, false);
    }).catch(function () {
      button.disabled = false;
      button.textContent = "Send";
      toast(CFG.strings.failed, true);
    });
  }

  // ---- what this is, once ------------------------------------------------
  // Shown the first time someone lands in review mode and never again, because
  // a bubble with no explanation is a bubble nobody presses, and an
  // explanation you have already read is noise. Kept to three sentences.
  var SEEN = "culFbIntroSeen";
  function seen() { try { return localStorage.getItem(SEEN) === "1"; } catch (e) { return false; } }
  function markSeen() { try { localStorage.setItem(SEEN, "1"); } catch (e) { /* private window */ } }

  function showIntro() {
    var card = document.createElement("div");
    card.id = "cul-fb-intro";
    var h = document.createElement("strong");
    h.textContent = "Something look wrong? Tell us here.";
    var p1 = document.createElement("p");
    p1.textContent = "Press the question mark, then click whatever is wrong on the page. Write one line about it and send.";
    var p2 = document.createElement("p");
    p2.textContent = "We get the page and the exact spot with it, so you never have to explain where it was. Changes can take up to 72 business hours.";
    var ok = document.createElement("button");
    ok.type = "button";
    ok.className = "cul-fb-send";
    ok.textContent = "Got it";
    ok.addEventListener("click", function () { markSeen(); card.parentNode && card.parentNode.removeChild(card); });
    card.appendChild(h);
    card.appendChild(p1);
    card.appendChild(p2);
    card.appendChild(ok);
    root.appendChild(card);
  }

  if (!seen()) setTimeout(function () { if (!seen()) showIntro(); }, 900);

  bubble.addEventListener("click", function () {
    markSeen();
    var intro = document.getElementById("cul-fb-intro");
    if (intro && intro.parentNode) intro.parentNode.removeChild(intro);
    if (picking) { stopPicking(); return; }
    if (panel.classList.contains("cul-fb-on")) { closePanel(); return; }
    startPicking();
  });
})();
