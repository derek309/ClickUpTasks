// Client and list dropdowns on the settings page. They call WordPress, which
// calls ClickUpTasks, so the API token never reaches this file.
(function () {
  var A = window.CUL_FEEDBACK_ADMIN;
  if (!A) return;

  var clientSel = document.getElementById("cul_client");
  var projectSel = document.getElementById("cul_project");
  var out = document.getElementById("cul_test_out");

  function post(body) {
    var form = new URLSearchParams(body);
    form.set("action", "cul_feedback_lookup");
    form.set("_wpnonce", A.nonce);
    return fetch(A.ajax, { method: "POST", credentials: "same-origin", body: form })
      .then(function (r) { return r.json(); });
  }

  function fill(sel, rows, idKey, nameKey, chosenId, placeholder) {
    sel.innerHTML = "";
    var blank = document.createElement("option");
    blank.value = "";
    blank.textContent = placeholder;
    sel.appendChild(blank);
    rows.forEach(function (r) {
      var o = document.createElement("option");
      o.value = r[idKey];
      o.textContent = r[nameKey];
      if (r[idKey] === chosenId) o.selected = true;
      sel.appendChild(o);
    });
  }

  function loadClients() {
    return post({ what: "clients" }).then(function (res) {
      if (!res.success) { clientSel.innerHTML = '<option value="">' + (res.data || "Could not load") + "</option>"; return; }
      // The clients endpoint also returns the workspace's own lists as
      // task targets, marked kind "project". Those are lists, not clients, so
      // they are left out here: this dropdown answers "whose site is this".
      var rows = ((res.data && res.data.clients) || res.data || []).filter(function (c) { return c.kind !== "project"; });
      fill(clientSel, rows, "id", "name", A.client.id, "Pick a client");
    });
  }

  function loadProjects(clientId) {
    if (!clientId) { projectSel.innerHTML = '<option value="">Pick a client first</option>'; return Promise.resolve(); }
    return post({ what: "projects", client_id: clientId }).then(function (res) {
      if (!res.success) { projectSel.innerHTML = '<option value="">' + (res.data || "Could not load") + "</option>"; return; }
      var rows = (res.data && res.data.projects) || res.data || [];
      fill(projectSel, rows, "id", "name", A.project.id, "Pick a list");
    });
  }

  clientSel.addEventListener("change", function () {
    document.getElementById("cul_client_id").value = clientSel.value;
    document.getElementById("cul_client_name").value = clientSel.options[clientSel.selectedIndex].textContent;
    // A list belongs to a client, so changing the client invalidates it.
    A.project.id = "";
    document.getElementById("cul_project_id").value = "";
    document.getElementById("cul_project_name").value = "";
    loadProjects(clientSel.value);
  });

  projectSel.addEventListener("change", function () {
    document.getElementById("cul_project_id").value = projectSel.value;
    document.getElementById("cul_project_name").value = projectSel.options[projectSel.selectedIndex].textContent;
  });

  document.getElementById("cul_test").addEventListener("click", function (e) {
    e.preventDefault();
    out.textContent = "Checking…";
    post({ what: "clients" }).then(function (res) {
      out.textContent = res.success
        ? "Connected. " + (((res.data && res.data.clients) || res.data || []).length) + " clients visible to this token."
        : "No: " + (res.data || "unknown error");
    }).catch(function () { out.textContent = "No: could not reach this site's own admin."; });
  });

  loadClients().then(function () { return loadProjects(A.client.id); });
})();
