<?php
// A stub of just enough WordPress to prove the plugin loads and its classes
// parse. Not a substitute for activating it on a real site, but it catches a
// fatal at load, which is what an activation failure usually is.
define('ABSPATH', '/tmp/wp/');
define('DAY_IN_SECONDS', 86400);
define('HOUR_IN_SECONDS', 3600);
define('COOKIEPATH', '/');
define('COOKIE_DOMAIN', '');
function plugin_dir_path($f) { return dirname($f) . '/'; }
function plugin_dir_url($f) { return 'https://example.test/wp-content/plugins/cul-feedback/'; }
function add_action(...$a) {}
function add_options_page(...$a) {}
function register_setting(...$a) {}
function get_option($k, $d = false) { return $d; }
function update_option($k, $v) { return true; }
function wp_parse_args($a, $d) { return array_merge($d, is_array($a) ? $a : []); }
function wp_generate_password($n = 12, ...$r) { return str_repeat('x', $n); }
function wp_json_encode($v) { return json_encode($v); }
function wp_remote_request($u, $a) { return ['response' => ['code' => 200], 'body' => '{"clients":[]}']; }
function is_wp_error($x) { return false; }
function wp_remote_retrieve_response_code($r) { return $r['response']['code']; }
function wp_remote_retrieve_body($r) { return $r['body']; }
function sanitize_text_field($s) { return is_string($s) ? trim(strip_tags($s)) : ''; }
function sanitize_textarea_field($s) { return is_string($s) ? trim(strip_tags($s)) : ''; }
function esc_url_raw($s) { return $s; }
function esc_attr($s) { return htmlspecialchars((string) $s); }
function esc_html($s) { return htmlspecialchars((string) $s); }
function wp_unslash($s) { return $s; }
function hash_equals_polyfill($a, $b) { return hash_equals($a, $b); }
function is_ssl() { return true; }
function is_user_logged_in() { return false; }
function current_user_can($c) { return false; }
function is_admin() { return false; }
function wp_enqueue_style(...$a) {}
function wp_enqueue_script(...$a) {}
function wp_localize_script(...$a) {}
function rest_url($p) { return 'https://example.test/wp-json/' . $p; }
function wp_create_nonce($a) { return 'nonce'; }
function register_rest_route(...$a) {}
function get_transient($k) { return 0; }
function set_transient(...$a) {}
function home_url($p = '/') { return 'https://example.test' . $p; }
function add_query_arg($k, $v, $u) { return $u . '?' . $k . '=' . $v; }
function admin_url($p) { return 'https://example.test/wp-admin/' . $p; }
function settings_fields($g) {}
function submit_button() {}
function checked($a, $b) { return $a == $b ? 'checked' : ''; }
function check_ajax_referer(...$a) {}
function wp_send_json_error(...$a) {}
function wp_send_json_success(...$a) {}
class WP_REST_Request { public function get_param($k) { return ''; } public function get_header($k) { return ''; } }
class WP_REST_Response { public function __construct($d = null, $s = 200) {} }

require __DIR__ . '/../cul-feedback.php';

// Exercise the parts with real logic in them.
$r = new ReflectionMethod('CUL_Feedback_REST', 'title_from');
$r->setAccessible(true);
$cases = [
  ['The phone number here is the old one', 'Copy', 'Copy: The phone number here is the old one'],
  [str_repeat('a', 100), 'Layout', 'Layout: ' . str_repeat('a', 69) . '…'],
  ["First line only\nsecond line", '', 'First line only'],
];
foreach ($cases as [$msg, $cat, $want]) {
  $got = $r->invoke(null, $msg, $cat);
  if ($got !== $want) { echo "FAIL title_from: got [$got] want [$want]\n"; exit(1); }
}
echo "title_from ok\n";

$s = CUL_Feedback_Settings::get();
if ($s['api_base'] === '' || $s['public_mode'] !== 0) { echo "FAIL defaults\n"; exit(1); }
echo "defaults ok\n";

list($ok, $data) = CUL_Feedback_Settings::api_get('/api/extension/clients');
if ($ok !== false || $data !== 'No API token saved yet.') { echo "FAIL token guard\n"; exit(1); }
echo "token guard ok\n";

// Dates: due three working days out, follow up today, weekends skipped.
function wp_date($fmt, $ts = null) { return date($fmt, $ts ?? time()); }
function current_time($t) { return time(); }
$b = new ReflectionMethod('CUL_Feedback_REST', 'business_days_from_today');
$b->setAccessible(true);
$due = $b->invoke(null, 3);
$dow = (int) date('N', strtotime($due));
if ($dow > 5) { echo "FAIL due lands on a weekend: $due\n"; exit(1); }
if (strtotime($due) <= time()) { echo "FAIL due is not in the future: $due\n"; exit(1); }
echo "due date ok ($due, weekday $dow)\n";
