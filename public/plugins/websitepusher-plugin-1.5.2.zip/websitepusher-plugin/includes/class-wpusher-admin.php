<?php
/**
 * WPusher_Admin
 *
 * WordPress admin page — three-step setup, plain English throughout.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class WPusher_Admin {

	private static $instance = null;

	/**
	 * Get the singleton instance.
	 *
	 * @return WPusher_Admin
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		add_action( 'admin_menu',            array( $this, 'register_menu' ) );
		add_action( 'admin_head',            array( $this, 'menu_icon_css' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_post_wpusher_rollback',         array( $this, 'handle_rollback' ) );
		add_action( 'admin_post_wpusher_download_backup',  array( $this, 'handle_download_backup' ) );
		add_action( 'admin_post_wpusher_regenerate_key',   array( $this, 'handle_regenerate_key' ) );
		add_action( 'admin_post_wpusher_save_settings',    array( $this, 'handle_save_settings' ) );
		add_action( 'admin_post_wpusher_save_github',      array( $this, 'handle_save_github' ) );
	}

	/**
	 * Register the admin menu item.
	 */
	public function register_menu() {
		add_menu_page(
			'WebsitePusher',
			'WebsitePusher',
			'manage_options',
			'websitepusher',
			array( $this, 'render_page' ),
			// Drawn by menu_icon_css(). Handed an SVG here, WordPress repaints
			// it in one colour, and the arrow vanishes into the square.
			'none',
			80
		);
	}

	/**
	 * The menu icon, in its own colours, on every admin page.
	 */
	public function menu_icon_css() {
		printf(
			'<style>#adminmenu #toplevel_page_websitepusher div.wp-menu-image{background:url("%s") no-repeat center/20px 20px}'
			. '#adminmenu #toplevel_page_websitepusher div.wp-menu-image::before{content:none}</style>' . "\n",
			esc_attr( $this->get_brand_icon_uri() )
		);
	}

	/**
	 * Returns a data: URI for the brand logo SVG, used as the sidebar menu icon.
	 * Blue and green split square with a white up arrow, the desktop app's icon.
	 */
	private function get_brand_icon_uri() {
		// Uses two <path> halves instead of <clipPath> — clip-paths flicker out
		// in the WP admin sidebar after the menu re-renders.
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 28 28">'
			. '<path d="M6 0 L14 0 L14 28 L6 28 Q0 28 0 22 L0 6 Q0 0 6 0 Z" fill="#0071e3"/>'
			. '<path d="M14 0 L22 0 Q28 0 28 6 L28 22 Q28 28 22 28 L14 28 Z" fill="#15803d"/>'
			. '<rect x="11" y="15" width="6" height="9" rx="2" fill="#fff"/>'
			. '<polygon points="14,4 7,16 21,16" fill="#fff"/>'
			. '</svg>';
		return 'data:image/svg+xml;base64,' . base64_encode( $svg );
	}

	/**
	 * Enqueue admin styles — inlined to prevent WordPress overrides.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_assets( $hook ) {
		if ( 'toplevel_page_websitepusher' !== $hook ) {
			return;
		}
		add_action( 'admin_head', array( $this, 'inline_styles' ) );
	}

	/**
	 * Output inline styles.
	 */
	public function inline_styles() {
		$css_file = WPUSHER_PLUGIN_DIR . 'assets/admin.css';
		if ( file_exists( $css_file ) ) {
			echo '<style id="websitepusher-admin">' . file_get_contents( $css_file ) . '</style>'; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		}
	}

	/**
	 * The last few things that happened to the lock, newest first.
	 */
	private function render_lock_log() {
		$log = array_slice( WPusher_Team::get_log(), 0, 5 );
		if ( ! $log ) {
			return;
		}
		$say = array(
			'locked'       => '%1$s locked it',
			'unlocked'     => '%1$s unlocked it',
			'unlocked_for' => '%1$s unlocked it for %2$s',
			'took_over'    => '%1$s took it over from %2$s',
			'refused_push' => '%1$s tried to push, refused: locked by %2$s',
			'refused_undo' => '%1$s tried to undo a push, refused: locked by %2$s',
		);
		echo '<ul class="tp-lock-log">';
		foreach ( $log as $e ) {
			$at = strtotime( $e['at'] );
			printf(
				'<li>%s <span>%s ago</span></li>',
				esc_html( sprintf( $say[ $e['what'] ] ?? '%1$s: ' . $e['what'], $e['who'], $e['other'] ) ),
				esc_html( $at ? human_time_diff( $at ) : '?' )
			);
		}
		echo '</ul>';
	}

	/**
	 * Who is working on the site, and where its code is on GitHub. The app
	 * sets the check-out; the repository can be typed here, and when this
	 * site's own folder already points at one, it is offered ready to save.
	 */
	private function render_team() {
		$checkout = WPusher_Team::get_checkout();
		$repo     = WPusher_Team::get_github_repo();
		$found    = $repo ? '' : WPusher_Team::detect_local_repo();
		?>
		<div class="tp-card" id="wpusher-team">
			<div class="tp-step">
				<div class="tp-step-body">
					<div class="tp-step-title"><?php esc_html_e( 'Team', 'websitepusher' ); ?></div>
					<div class="tp-step-desc">
						<?php
						if ( $checkout ) {
							$since = strtotime( $checkout['since'] );
							printf(
								/* translators: 1: teammate, 2: how long ago */
								esc_html__( '&#128274; Locked by %1$s (for %2$s). Only they can push to this website until they unlock it.', 'websitepusher' ),
								'<strong>' . esc_html( $checkout['who'] ) . '</strong>',
								esc_html( $since ? human_time_diff( $since ) : '?' )
							);
						} else {
							esc_html_e( 'Not locked. Anyone on the team can push.', 'websitepusher' );
						}
						?>
					</div>
					<?php $this->render_lock_log(); ?>
					<div class="tp-advanced-label"><?php esc_html_e( 'Code on GitHub', 'websitepusher' ); ?></div>
					<div class="tp-advanced-desc">
						<?php
						if ( $repo ) {
							printf( '<a href="%s" target="_blank" rel="noopener noreferrer">%s</a>', esc_url( $repo ), esc_html( preg_replace( '#^https://github\.com/#', '', $repo ) ) );
						} elseif ( $found ) {
							esc_html_e( 'Found in this site\'s folder. Save it so every teammate\'s app can find it.', 'websitepusher' );
						} else {
							esc_html_e( 'Where this website\'s code lives, so every teammate\'s app can find it.', 'websitepusher' );
						}
						?>
					</div>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tp-inline-form tp-github-form">
						<input type="hidden" name="action" value="wpusher_save_github">
						<?php wp_nonce_field( 'wpusher_save_github', 'wpusher_nonce' ); ?>
						<input type="text" name="wpusher_github_repo" value="<?php echo esc_attr( preg_replace( '#^https://github\.com/#', '', $repo ? $repo : $found ) ); ?>" placeholder="owner/repository" class="tp-text-input" spellcheck="false" autocomplete="off">
						<button type="submit" class="tp-btn-save"><?php esc_html_e( 'Save', 'websitepusher' ); ?></button>
					</form>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render the admin page.
	 */
	public function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'websitepusher' ) );
		}

		$api_key    = WPusher_Security::get_api_key();
		$key_locked = WPusher_Security::is_api_key_locked();
		$site_url   = get_site_url();
		$retention = (int) get_option( 'wpusher_backup_retention', 10 );
		$rollback  = WPusher_History::get_latest_rollbackable();
		?>
		<div class="tp-page">

			<div class="tp-header">
				<div class="tp-header-logo">
					<div class="tp-logo-icon tp-brand-icon">
						<svg viewBox="0 0 28 28" xmlns="http://www.w3.org/2000/svg" width="40" height="40">
							<path d="M6 0 L14 0 L14 28 L6 28 Q0 28 0 22 L0 6 Q0 0 6 0 Z" fill="#0071e3"/>
							<path d="M14 0 L22 0 Q28 0 28 6 L28 22 Q28 28 22 28 L14 28 Z" fill="#15803d"/>
							<rect x="11" y="15" width="6" height="9" rx="2" fill="#fff"/>
							<polygon points="14,4 7,16 21,16" fill="#fff"/>
						</svg>
					</div>
					<div>
						<h1>
							WebsitePusher
							<span class="tp-version">v<?php echo esc_html( WPUSHER_VERSION ); ?></span>
						</h1>
						<p><?php esc_html_e( 'Your website is connected and ready to push.', 'websitepusher' ); ?></p>
					</div>
				</div>
				<div class="tp-connected-badge">
					<span class="tp-connected-dot"></span>
					<?php esc_html_e( 'Connected', 'websitepusher' ); ?>
				</div>
			</div>

			<?php $this->render_notices(); ?>

			<div class="tp-card">

				<div class="tp-step">
					<div class="tp-step-num">1</div>
					<div class="tp-step-body">
						<div class="tp-step-title"><?php esc_html_e( 'Get the desktop app', 'websitepusher' ); ?></div>
						<div class="tp-step-desc"><?php esc_html_e( 'Download and install WebsitePusher on your Mac to start pushing changes live.', 'websitepusher' ); ?></div>
						<a href="https://websitepusher.com/download" target="_blank" rel="noopener noreferrer" class="tp-download-btn">
							<svg viewBox="0 0 16 16" fill="none" width="14" height="14"><path d="M8 2v9M8 11l-3-3M8 11l3-3" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/><path d="M2 13h12" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>
							<?php esc_html_e( 'Download WebsitePusher for Mac', 'websitepusher' ); ?>
						</a>
					</div>
				</div>

				<div class="tp-divider"></div>

				<div class="tp-step">
					<div class="tp-step-num">2</div>
					<div class="tp-step-body">
						<div class="tp-step-title"><?php esc_html_e( 'Copy your website address', 'websitepusher' ); ?></div>
						<div class="tp-step-desc"><?php esc_html_e( 'Paste this into the WebsitePusher desktop app when asked for your website address.', 'websitepusher' ); ?></div>
						<div class="tp-copy-row">
							<code id="tp-site-url"><?php echo esc_html( $site_url ); ?></code>
							<button type="button" class="tp-copy-btn" onclick="tpCopy('tp-site-url', this)">
								<svg viewBox="0 0 16 16" fill="none" width="13" height="13"><rect x="5" y="5" width="9" height="9" rx="2" stroke="currentColor" stroke-width="1.3"/><path d="M3 11V3a2 2 0 012-2h8" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>
								<?php esc_html_e( 'Copy', 'websitepusher' ); ?>
							</button>
						</div>
					</div>
				</div>

				<div class="tp-divider"></div>

				<div class="tp-step">
					<div class="tp-step-num">3</div>
					<div class="tp-step-body">
						<div class="tp-step-title"><?php esc_html_e( 'Add this website to the app', 'websitepusher' ); ?></div>
						<div class="tp-step-desc"><?php esc_html_e( 'One click opens the WebsitePusher app with this website already filled in. You still choose the folder on your computer and press Save.', 'websitepusher' ); ?></div>
						<?php
						// Opens the desktop app with the address and connection code
						// already in its Add-website form. The app only prefills from
						// this: it never saves a website on its own, because a link
						// like this one can come from any page.
						$add_link = 'websitepusher://add-site?' . http_build_query(
							array(
								'url'  => home_url(),
								'code' => $api_key,
								'name' => get_bloginfo( 'name' ),
							),
							'',
							'&',
							PHP_QUERY_RFC3986
						);
						?>
						<p>
							<a class="tp-btn-primary" href="<?php echo esc_url( $add_link, array( 'websitepusher' ) ); ?>">
								<?php esc_html_e( 'Add to WebsitePusher', 'websitepusher' ); ?>
							</a>
						</p>
						<div class="tp-step-desc"><?php esc_html_e( 'Nothing happens when you click it? The app is not installed yet, or this is the first time. Copy the code below and paste it in by hand.', 'websitepusher' ); ?></div>
						<div class="tp-copy-row">
							<code id="tp-api-key" class="tp-key-hidden"><?php echo esc_html( $api_key ); ?></code>
							<button type="button" class="tp-show-btn" onclick="tpToggleKey(this)"><?php esc_html_e( 'Show', 'websitepusher' ); ?></button>
							<button type="button" class="tp-copy-btn" onclick="tpCopy('tp-api-key', this)">
								<svg viewBox="0 0 16 16" fill="none" width="13" height="13"><rect x="5" y="5" width="9" height="9" rx="2" stroke="currentColor" stroke-width="1.3"/><path d="M3 11V3a2 2 0 012-2h8" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"/></svg>
								<?php esc_html_e( 'Copy', 'websitepusher' ); ?>
							</button>
						</div>
					</div>
				</div>

			</div>

			<?php $this->render_team(); ?>

			<?php if ( $rollback ) : ?>
			<div class="tp-card tp-undo-card">
				<div class="tp-undo-info">
					<div class="tp-undo-title">
						<svg viewBox="0 0 16 16" fill="none" width="14" height="14"><path d="M3 8a5 5 0 105-5H5M5 3L3 5l2 2" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>
						<?php esc_html_e( 'Undo last update', 'websitepusher' ); ?>
					</div>
					<div class="tp-undo-desc">
						<?php
						printf(
							/* translators: %s: formatted date */
							esc_html__( 'Backup from %s', 'websitepusher' ),
							'<strong>' . esc_html( WPusher_History::format_date( $rollback['timestamp'] ) ) . '</strong>'
						);
						if ( ! empty( $rollback['note'] ) ) {
							echo ': <em>' . esc_html( $rollback['note'] ) . '</em>';
						}
						?>
					</div>
				</div>
				<div class="tp-undo-actions">
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="wpusher_download_backup">
						<input type="hidden" name="backup_path" value="<?php echo esc_attr( $rollback['backup_path'] ); ?>">
						<?php wp_nonce_field( 'wpusher_download_backup', 'wpusher_nonce' ); ?>
						<button type="submit" class="tp-btn-ghost"><?php esc_html_e( 'Download safety copy', 'websitepusher' ); ?></button>
					</form>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="wpusher_rollback">
						<?php wp_nonce_field( 'wpusher_rollback', 'wpusher_nonce' ); ?>
						<button type="submit" class="tp-btn-undo" onclick="return confirm('<?php esc_attr_e( "Undo the last update? Your website will go back to the previous version.", "websitepusher" ); ?>')">
							<?php esc_html_e( 'Undo last update', 'websitepusher' ); ?>
						</button>
					</form>
				</div>
			</div>
			<?php endif; ?>

			<details class="tp-advanced">
				<summary class="tp-advanced-toggle"><?php esc_html_e( 'Advanced settings', 'websitepusher' ); ?></summary>
				<div class="tp-advanced-body">

					<div class="tp-advanced-row">
						<div>
							<div class="tp-advanced-label"><?php esc_html_e( 'Safety copies to keep', 'websitepusher' ); ?></div>
							<div class="tp-advanced-desc"><?php esc_html_e( 'Older safety copies are removed automatically. Set to 0 to keep all.', 'websitepusher' ); ?></div>
						</div>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="tp-inline-form">
							<input type="hidden" name="action" value="wpusher_save_settings">
							<?php wp_nonce_field( 'wpusher_save_settings', 'wpusher_nonce' ); ?>
							<input type="number" name="wpusher_backup_retention" value="<?php echo esc_attr( $retention ); ?>" min="0" max="100" class="tp-number-input">
							<button type="submit" class="tp-btn-save"><?php esc_html_e( 'Save', 'websitepusher' ); ?></button>
						</form>
					</div>

					<div class="tp-advanced-row">
						<div>
							<div class="tp-advanced-label"><?php esc_html_e( 'Reset connection code', 'websitepusher' ); ?></div>
							<?php if ( $key_locked ) : ?>
							<div class="tp-advanced-desc"><?php esc_html_e( 'This code is set in wp-config.php (WPUSHER_API_KEY) and is the same across your environments, so a site copy can never break it. To change it, edit wp-config.php.', 'websitepusher' ); ?></div>
							<?php else : ?>
							<div class="tp-advanced-desc"><?php esc_html_e( 'Generates a new code. You\'ll need to update the desktop app afterwards.', 'websitepusher' ); ?></div>
							<?php endif; ?>
						</div>
						<?php if ( $key_locked ) : ?>
						<button type="button" class="tp-btn-danger" disabled style="opacity:.5;cursor:not-allowed"><?php esc_html_e( 'Locked', 'websitepusher' ); ?></button>
						<?php else : ?>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="wpusher_regenerate_key">
							<?php wp_nonce_field( 'wpusher_regenerate_key', 'wpusher_nonce' ); ?>
							<button type="submit" class="tp-btn-danger" onclick="return confirm('<?php esc_attr_e( "Reset your connection code? You will need to update the desktop app.", "websitepusher" ); ?>')">
								<?php esc_html_e( 'Reset code', 'websitepusher' ); ?>
							</button>
						</form>
						<?php endif; ?>
					</div>

				</div>
			</details>

			<div class="tp-disclaimer">
				<strong><?php esc_html_e( 'Use at your own risk.', 'websitepusher' ); ?></strong>
				<?php esc_html_e( 'WebsitePusher creates automatic safety copies before every update. However, you are solely responsible for your website and its content. We are not liable for any data loss, downtime, or damage that may occur. Always maintain your own backups through your hosting provider.', 'websitepusher' ); ?>
			</div>

		</div>

		<script>
		function tpCopy(id, btn) {
			var text = document.getElementById(id).textContent.trim();
			navigator.clipboard.writeText(text).then(function() {
				var orig = btn.innerHTML;
				btn.innerHTML = '&#10003; <?php esc_html_e( 'Copied!', 'websitepusher' ); ?>';
				btn.classList.add('tp-copied');
				setTimeout(function() { btn.innerHTML = orig; btn.classList.remove('tp-copied'); }, 2000);
			});
		}

		function tpToggleKey(btn) {
			var el = document.getElementById('tp-api-key');
			var hidden = el.classList.toggle('tp-key-hidden');
			btn.textContent = hidden ? '<?php esc_html_e( 'Show', 'websitepusher' ); ?>' : '<?php esc_html_e( 'Hide', 'websitepusher' ); ?>';
		}
		</script>
		<?php
	}

	/**
	 * Render admin notices based on URL params.
	 */
	private function render_notices() {
		if ( empty( $_GET['wpusher_notice'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		$notice = sanitize_text_field( wp_unslash( $_GET['wpusher_notice'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$map = array(
			'rollback_success' => array( 'success', __( '&#10003; Undone successfully. Your website is back to the previous version.', 'websitepusher' ) ),
			'rollback_failed'  => array( 'error',   __( '&#10007; Could not undo.', 'websitepusher' ) ),
			'key_regenerated'  => array( 'success', __( '&#10003; Connection code reset. Update your desktop app with the new code.', 'websitepusher' ) ),
			'settings_saved'   => array( 'success', __( '&#10003; Settings saved.', 'websitepusher' ) ),
			'github_saved'     => array( 'success', __( '&#10003; GitHub repository saved.', 'websitepusher' ) ),
			'github_bad'       => array( 'error',   __( '&#10007; That doesn\'t look like a GitHub repository. Use owner/repository, as it appears in the github.com address.', 'websitepusher' ) ),
		);

		if ( isset( $map[ $notice ] ) ) {
			list( $type, $msg ) = $map[ $notice ];
			printf(
				'<div class="notice notice-%s is-dismissible tp-notice"><p>%s</p></div>',
				esc_attr( $type ),
				wp_kses( $msg, array() )
			);
		}
	}

	/**
	 * Redirect with a notice parameter.
	 *
	 * @param string $notice Notice key.
	 */
	private function redirect( $notice ) {
		wp_safe_redirect(
			add_query_arg(
				array(
					'page'           => 'websitepusher',
					'wpusher_notice' => $notice,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Handle rollback form submission.
	 */
	public function handle_rollback() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'websitepusher' ) );
		}
		check_admin_referer( 'wpusher_rollback', 'wpusher_nonce' );

		$result = WPusher_Deployer::rollback( get_stylesheet_directory() );
		is_wp_error( $result )
			? $this->redirect( 'rollback_failed' )
			: $this->redirect( 'rollback_success' );
	}

	/**
	 * Handle backup download.
	 */
	public function handle_download_backup() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'websitepusher' ) );
		}
		check_admin_referer( 'wpusher_download_backup', 'wpusher_nonce' );

		$path = sanitize_text_field( wp_unslash( $_POST['backup_path'] ?? '' ) );

		$backup_dir = realpath( WPusher_Backup::get_backup_dir() );
		$real       = realpath( $path );

		if ( ! $real || ! $backup_dir || ! str_starts_with( $real, $backup_dir ) || ! file_exists( $real ) ) {
			wp_die( esc_html__( 'Invalid backup.', 'websitepusher' ) );
		}

		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( basename( $real ) ) . '"' );
		header( 'Content-Length: ' . filesize( $real ) );
		header( 'Cache-Control: no-cache' );
		readfile( $real ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_readfile
		exit;
	}

	/**
	 * Handle connection code regeneration.
	 */
	public function handle_regenerate_key() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'websitepusher' ) );
		}
		check_admin_referer( 'wpusher_regenerate_key', 'wpusher_nonce' );
		if ( WPusher_Security::is_api_key_locked() ) {
			wp_die( esc_html__( 'The connection code is set in wp-config.php and cannot be reset from here.', 'websitepusher' ) );
		}
		WPusher_Security::regenerate_api_key();
		$this->redirect( 'key_regenerated' );
	}

	/**
	 * Handle settings save.
	 */
	public function handle_save_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'websitepusher' ) );
		}
		check_admin_referer( 'wpusher_save_settings', 'wpusher_nonce' );

		$retention = max( 0, (int) ( $_POST['wpusher_backup_retention'] ?? 10 ) );
		update_option( 'wpusher_backup_retention', $retention );

		if ( $retention > 0 ) {
			WPusher_Backup::cleanup_old_backups( $retention );
		}

		$this->redirect( 'settings_saved' );
	}

	/**
	 * Save the site's GitHub repository from the Team card.
	 */
	public function handle_save_github() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Unauthorized.', 'websitepusher' ) );
		}
		check_admin_referer( 'wpusher_save_github', 'wpusher_nonce' );

		$saved = WPusher_Team::set_github_repo( sanitize_text_field( wp_unslash( $_POST['wpusher_github_repo'] ?? '' ) ) );
		$this->redirect( is_wp_error( $saved ) ? 'github_bad' : 'github_saved' );
	}
}
